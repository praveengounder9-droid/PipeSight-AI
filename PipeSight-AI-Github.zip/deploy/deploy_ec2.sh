#!/usr/bin/env bash
# ==============================================================================
# PipeSight AI — Automated Ubuntu EC2 Deployment & Provisioning Script
# Targets: Ubuntu 22.04 LTS / 24.04 LTS on AWS EC2 (t3.medium or t3a.medium)
# ==============================================================================

set -euo pipefail

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

log_info() { echo -e "${CYAN}[INFO]${NC} $1"; }
log_success() { echo -e "${GREEN}[SUCCESS]${NC} $1"; }
log_warn() { echo -e "${YELLOW}[WARNING]${NC} $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; exit 1; }

echo "======================================================================"
echo "    PipeSight AI — Single EC2 Instance Provisioning Script            "
echo "======================================================================"

# 1. Root / Sudo check
if [[ $EUID -ne 0 ]]; then
    log_error "This script must be run with sudo privileges: sudo bash deploy_ec2.sh"
fi

INSTALL_DIR="/var/www/pipesight"
CURRENT_USER="${SUDO_USER:-ubuntu}"

log_info "Target deployment directory: ${INSTALL_DIR}"
log_info "Deploying for system user: ${CURRENT_USER}"

# 2. System updates and required packages
log_info "Updating apt package index..."
apt-get update -y

log_info "Installing system libraries and OpenCV 5 dependencies..."
apt-get install -y --no-install-recommends \
    python3 \
    python3-pip \
    python3-venv \
    python3-dev \
    build-essential \
    ffmpeg \
    libgl1 \
    libglib2.0-0 \
    libgomp1 \
    nginx \
    certbot \
    python3-certbot-nginx \
    curl \
    git \
    unzip \
    sqlite3

# 3. Install Node.js 20 LTS for building the frontend if not already installed
if ! command -v node &> /dev/null || [[ $(node -v | cut -d'.' -f1 | tr -d 'v') -lt 18 ]]; then
    log_info "Installing Node.js 20 LTS (NodeSource)..."
    curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
    apt-get install -y nodejs
fi
log_success "Node.js $(node -v) and npm $(npm -v) verified."

# 4. Prepare application directories
log_info "Creating project directory structure..."
mkdir -p "${INSTALL_DIR}/backend/storage/jobs"
mkdir -p "${INSTALL_DIR}/backend/models"
mkdir -p "${INSTALL_DIR}/backend/trackers"
mkdir -p "${INSTALL_DIR}/frontend"

# 5. Set up Python virtual environment
log_info "Setting up Python 3 virtual environment..."
VENV_PATH="${INSTALL_DIR}/backend/venv"
if [[ ! -d "${VENV_PATH}" ]]; then
    python3 -m venv "${VENV_PATH}"
fi

log_info "Upgrading pip and installing backend dependencies..."
"${VENV_PATH}/bin/pip" install --upgrade pip setuptools wheel

if [[ -f "${INSTALL_DIR}/backend/requirements.txt" ]]; then
    "${VENV_PATH}/bin/pip" install -r "${INSTALL_DIR}/backend/requirements.txt"
    log_success "Python backend requirements installed."
else
    log_warn "No requirements.txt found in ${INSTALL_DIR}/backend yet. Copy your repo files first."
fi

# 6. Build Frontend
if [[ -f "${INSTALL_DIR}/frontend/package.json" ]]; then
    log_info "Installing frontend npm packages and building production assets..."
    cd "${INSTALL_DIR}/frontend"
    npm ci --prefer-offline || npm install
    npm run build
    log_success "Frontend static assets compiled to ${INSTALL_DIR}/frontend/dist"
fi

# 7. Create backend production .env if not exists
ENV_FILE="${INSTALL_DIR}/backend/.env"
if [[ ! -f "${ENV_FILE}" ]] && [[ -f "${INSTALL_DIR}/backend/.env.example" ]]; then
    log_info "Initializing production .env from .env.example..."
    cp "${INSTALL_DIR}/backend/.env.example" "${ENV_FILE}"
    sed -i 's/DEBUG=true/DEBUG=false/g' "${ENV_FILE}"
    sed -i 's/STORAGE_BACKEND=s3/STORAGE_BACKEND=local/g' "${ENV_FILE}"
fi

# 8. Set secure permissions
log_info "Configuring directory ownership and write permissions..."
chown -R "${CURRENT_USER}:www-data" "${INSTALL_DIR}"
chmod -R 775 "${INSTALL_DIR}/backend/storage"
chmod -R 755 "${INSTALL_DIR}/frontend/dist" 2>/dev/null || true

# 9. Configure systemd service
SERVICE_SRC="${INSTALL_DIR}/deploy/pipesight.service.example"
SERVICE_DEST="/etc/systemd/system/pipesight.service"
if [[ -f "${SERVICE_SRC}" ]]; then
    log_info "Installing systemd service unit..."
    cp "${SERVICE_SRC}" "${SERVICE_DEST}"
    systemctl daemon-reload
    systemctl enable pipesight.service
    log_success "pipesight.service registered and enabled at boot."
fi

# 10. Check model weights presence
if [[ ! -f "${INSTALL_DIR}/backend/models/best.pt" ]]; then
    echo ""
    log_warn "================================================================="
    log_warn "CRITICAL NEXT STEP: Model weights 'best.pt' are not yet on EC2."
    log_warn "From your LOCAL machine, transfer your checkpoint via scp:"
    log_warn "  scp -i <YOUR_KEY.pem> backend/models/best.pt ${CURRENT_USER}@<EC2_IP>:${INSTALL_DIR}/backend/models/best.pt"
    log_warn "================================================================="
    echo ""
fi

echo "======================================================================"
log_success "PipeSight AI server setup completed successfully!"
echo "======================================================================"
echo "Next steps:"
echo " 1. Transfer best.pt to: ${INSTALL_DIR}/backend/models/best.pt"
echo " 2. Configure Nginx:     sudo cp ${INSTALL_DIR}/deploy/nginx.conf.example /etc/nginx/sites-available/pipesight.conf"
echo "                         sudo nano /etc/nginx/sites-available/pipesight.conf  # Set server_name"
echo "                         sudo ln -s /etc/nginx/sites-available/pipesight.conf /etc/nginx/sites-enabled/"
echo "                         sudo nginx -t && sudo systemctl reload nginx"
echo " 3. Enable HTTPS:        sudo certbot --nginx -d <your-domain.com>"
echo " 4. Start backend:       sudo systemctl start pipesight.service"
echo " 5. Check logs:          sudo journalctl -u pipesight.service -f"
echo "======================================================================"

# PipeSight AI — Single EC2 Instance Production Deployment Guide

This guide walks you through deploying both the **FastAPI backend** and **React frontend** of PipeSight AI onto a single low-cost **AWS EC2 Ubuntu instance**.

---

## 1. Cost Control & Resource Sizing

### Instance Type Recommendation

| Instance Type | vCPU | RAM | Architecture | On-Demand Cost (`us-east-1`) | Recommendation |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **`t3a.medium`** (AMD) | 2 | 4.0 GB | x86_64 | **$0.0376 / hour** | **Recommended (Best Value)** |
| **`t3.medium`** (Intel) | 2 | 4.0 GB | x86_64 | $0.0416 / hour | Alternative |
| `t4g.medium` (Graviton) | 2 | 4.0 GB | arm64 | $0.0336 / hour | Supported (requires arm64 torch) |
| `t3.micro` / `t3.small` | 2 | 1–2 GB | x86_64 | $0.0104 / hour | **Do not use** (OOM during PyTorch inference) |

> **Why 4 GB RAM is Required:**
> OpenCV 5 frame decoding, PyTorch CPU inference with YOLO26s, and ByteTrack Kalman filter tracking peak at approximately 1.8 – 2.4 GB of RAM during active video analysis. A 4 GB instance ensures stable operation without crashing.

### Transparent Cost Calculation (Targeting < $20)

| Cost Component | Pricing Rate | Duration / Usage | Estimated Cost |
| :--- | :--- | :--- | :--- |
| **EC2 Compute (`t3a.medium`)** | $0.0376 / hour | 10 days (240 hours) continuous | **$9.02** |
| **EBS Storage (30 GB gp3)** | $0.08 / GB-month | 1 month allocation | **$2.40** |
| **Public IPv4 Address** | $0.005 / hour | 10 days continuous | **$1.20** |
| **Data Transfer Out** | Free up to 100 GB/month | Demonstration traffic | **$0.00** |
| **Total Estimated Demonstration Cost** | — | — | **~$12.62** |

> **Cost Disclosures & Warnings:**
> 1. Stopping an EC2 instance halts per-second compute billing, but **EBS storage charges ($2.40/month)** and **Elastic IP charges** continue until the volume and IP are deleted/released.
> 2. Zero cost for databases, GPUs, NAT gateways, or load balancers: PipeSight AI runs local SQLite and Nginx directly on the instance.

### Setting AWS Budget Alerts (Recommended)

1. Open AWS Management Console > **AWS Budgets**.
2. Click **Create budget** > Choose **Cost budget**.
3. Name: `PipeSight-Demo-Budget`. Set Period: **Monthly**, Budgeted amount: **$20.00**.
4. Set Alert Thresholds:
   - Alert 1: **75% ($15.00)** > Send email notification.
   - Alert 2: **100% ($20.00)** > Send email notification.

---

## 2. Step 1: Create EC2 Instance & Restrict SSH Access

### On Local Machine (AWS CLI or AWS Console)

1. **Launch Instance:**
   - **AMI**: Ubuntu Server 24.04 LTS (HVM), SSD Volume Type (`ami-...`).
   - **Instance Type**: `t3a.medium` (or `t3.medium`).
   - **Key Pair**: Create new or select existing (e.g., `pipesight-key.pem`).
   - **Storage**: 30 GB `gp3` (3000 IOPS, 125 MB/s).

2. **Configure Security Group Rules (Strict Access):**
   - **SSH (Port 22)**: Set Source to **`My IP`** (`<YOUR_LOCAL_IP>/32`). Never leave open to `0.0.0.0/0`.
   - **HTTP (Port 80)**: Source `0.0.0.0/0` (for Let's Encrypt challenge & redirect).
   - **HTTPS (Port 443)**: Source `0.0.0.0/0` (for secure public dashboard access).

3. Set local key permissions (Linux/macOS/Git Bash):
   ```bash
   chmod 400 ~/.ssh/pipesight-key.pem
   ```

---

## 3. Step 2: Connect to EC2 and Provision Server

### Connect from Local Machine

```bash
ssh -i ~/.ssh/pipesight-key.pem ubuntu@<EC2_PUBLIC_IP>
```

---

## 4. Step 3: Clone Repository & Run Automated Provisioning

### On EC2 Instance

```bash
# 1. Update packages and install Git
sudo apt update && sudo apt install -y git

# 2. Clone repository to /var/www/pipesight
sudo mkdir -p /var/www/pipesight
sudo chown -R ubuntu:ubuntu /var/www/pipesight
git clone <YOUR_GITHUB_REPOSITORY_URL> /var/www/pipesight

# 3. Run automated installation script
cd /var/www/pipesight/deploy
sudo bash deploy_ec2.sh
```

---

## 5. Step 4: Securely Transfer Model Weights (`best.pt`)

> **Note:** The trained model weights `best.pt` (~20 MB) are deliberately not committed to Git. Transfer them directly from your local machine.

### Run on Local Machine (Terminal / PowerShell)

```bash
# Upload best.pt to EC2 via scp
scp -i ~/.ssh/pipesight-key.pem \
    backend/models/best.pt \
    ubuntu@<EC2_PUBLIC_IP>:/var/www/pipesight/backend/models/best.pt
```

### Verify on EC2

```bash
# On EC2 instance:
ls -lh /var/www/pipesight/backend/models/best.pt
```

---

## 6. Step 5: Configure Production Environment

### On EC2 Instance

Edit `/var/www/pipesight/backend/.env`:

```bash
nano /var/www/pipesight/backend/.env
```

Ensure these settings are configured:

```env
APP_NAME="PipeSight AI - Agentic Sewer Inspection Backend"
API_PREFIX=/api/v1
DEBUG=false
HOST=127.0.0.1
PORT=8000
CORS_ORIGINS=["https://<YOUR_DOMAIN>", "http://<EC2_PUBLIC_IP>"]

MODEL_PATH=models/best.pt
TRACKER_CONFIG_PATH=trackers/bytetrack.yaml
CONFIDENCE_THRESHOLD=0.25
IOU_THRESHOLD=0.45
FRAME_STRIDE=3
MAX_PROCESSING_DIM=640
DEVICE=cpu

# Persistent disk storage settings
STORAGE_BACKEND=local
LOCAL_STORAGE_DIR=storage
RETENTION_HOURS=24
MIN_FREE_DISK_MB=500
```

---

## 7. Step 6: Start FastAPI Systemd Service

### On EC2 Instance

```bash
# Enable and start the background service
sudo systemctl daemon-reload
sudo systemctl enable pipesight.service
sudo systemctl start pipesight.service

# Verify service status
sudo systemctl status pipesight.service

# Verify local backend response
curl -s http://127.0.0.1:8000/health | jq .
```

---

## 8. Step 7: Configure Nginx & SSL Certificate

### Option A: With a Custom Domain (e.g. `pipesight.example.com`)

1. In your DNS provider (e.g., Route53, Cloudflare, Namecheap), add an **A Record** pointing `pipesight.example.com` to `<EC2_PUBLIC_IP>`.

2. Install Nginx configuration:
   ```bash
   sudo cp /var/www/pipesight/deploy/nginx.conf.example /etc/nginx/sites-available/pipesight.conf
   sudo sed -i 's/<YOUR_DOMAIN_OR_PUBLIC_IP>/pipesight.example.com/g' /etc/nginx/sites-available/pipesight.conf
   sudo sed -i 's/<YOUR_DOMAIN>/pipesight.example.com/g' /etc/nginx/sites-available/pipesight.conf

   sudo ln -sf /etc/nginx/sites-available/pipesight.conf /etc/nginx/sites-enabled/
   sudo rm -f /etc/nginx/sites-enabled/default
   ```

3. Obtain Let's Encrypt SSL certificate:
   ```bash
   sudo certbot --nginx -d pipesight.example.com
   ```

4. Test and reload Nginx:
   ```bash
   sudo nginx -t && sudo systemctl reload nginx
   ```

### Option B: Using EC2 Public IP Directly (Self-Signed SSL or Plain HTTP Testing)

If testing via Public IP before attaching a domain:

```bash
# Configure Nginx for IP access
sudo nano /etc/nginx/sites-available/pipesight.conf
# Replace server_name with <EC2_PUBLIC_IP>
sudo nginx -t && sudo systemctl reload nginx
```

---

## 9. Step 8: Verify Public Endpoints & Downloads

Test public availability from your local machine:

```bash
# 1. Health check
curl -f https://<YOUR_DOMAIN>/health

# 2. System info endpoint
curl -f https://<YOUR_DOMAIN>/api/v1/info

# 3. Test Frontend in browser
# Open https://<YOUR_DOMAIN>/ in Chrome/Firefox
```

Verify in the dashboard:
1. Upload a test sewer pipe video.
2. Confirm progress bar and frames processed counter update live.
3. Verify video playback with rendered bounding boxes.
4. Verify downloading:
   - PDF report (`/api/v1/inspect/{job_id}/report.pdf`).
   - JSON report (`/api/v1/inspect/{job_id}/report`).
   - Full package ZIP archive (`/api/v1/inspect/{job_id}/zip`).

---

## 10. Step 9: Updating Code from GitHub Without Overwriting Data

When updating application code, your inspection results in `/var/www/pipesight/backend/storage` and database `pipesight.db` are strictly preserved:

### On EC2 Instance

```bash
cd /var/www/pipesight

# 1. Pull latest code from GitHub
git pull origin main

# 2. Update backend virtual environment dependencies (if requirements changed)
/var/www/pipesight/backend/venv/bin/pip install -r backend/requirements.txt

# 3. Rebuild frontend production assets
cd /var/www/pipesight/frontend
npm ci && npm run build
cd /var/www/pipesight

# 4. Restart backend systemd service
sudo systemctl restart pipesight.service

# 5. Reload Nginx
sudo systemctl reload nginx

echo "PipeSight AI successfully updated!"
```

# PipeSight AI — Frontend Inspection Dashboard

A high-performance, responsive React + TypeScript dashboard for **PipeSight AI**, an agentic sewer and stormwater pipe inspection platform.

The frontend interfaces with the standalone Python FastAPI backend powered by **OpenCV 5**, a trained **YOLO26s** defect detection checkpoint, and **ByteTrack** multi-object persistent tracking.

---

## Architecture Overview

- **Framework**: React 19 + TypeScript + Vite.
- **Styling**: Vanilla CSS Design System with high-contrast industrial dark mode, glassmorphic HUD elements, and responsive layout for desktop and tablet.
- **API Client**: Strongly-typed client module communicating with FastAPI via JSON and `multipart/form-data`. Resolves relative storage URLs against `VITE_API_BASE_URL`.
- **Zero Simulation**: All detection counts, bounding boxes, video HUD overlays, and agent decision timelines originate from actual backend API responses.
- **Separation of Concerns**: The frontend and backend are completely decoupled and deployed independently.

---

## Features

1. **Live Backend Health & Telemetry**: Real-time `/health` diagnostics displaying OpenCV 5 version, PyTorch runtime, compute device (CPU/CUDA), model checkpoint hash, and response latency.
2. **Video-First CCTV Ingestion**:
   - Drag-and-drop & native file picker.
   - Format validation (`.mp4`, `.avi`, `.mov`, `.mkv`, `.webm`) up to 500 MB.
   - Local in-browser video preview before submission.
   - Non-cancellation disclosure (explains backend sequential execution).
3. **Real-Time Job Polling**:
   - Real-time progress bar (0% – 100%).
   - Analyzed frames counter (`current_frame / total_frames`), elapsed time, and estimated time remaining.
4. **Comprehensive Inspection Results**:
   - Distinct counts for **Raw Detections** vs **Estimated Unique Track Events** (via ByteTrack deduplication).
   - Defect breakdown tags by class.
   - Interactive Defect Table displaying track IDs, prediction scores, first/last seen timestamps, and human review tags.
   - **Clickable Timestamps**: Seeks the annotated video directly to the defect occurrence.
   - **Annotated Video Player**: Custom controls, playback speed (0.5x, 1x, 1.5x, 2x), and MP4 download.
   - **Evidence Gallery**: High-resolution snapshots with lightbox zoom modal.
   - **Agentic Vision Trace**: Full audit timeline of perception-decision-action steps (`ENHANCE_AND_RECHECK`, `REQUEST_HUMAN_REVIEW`, etc.) with Laplacian blur and brightness measurements.
   - **Formal Exports**: Download formal ReportLab PDF reports, structured JSON data, and annotated MP4 video.
5. **Local History**: Persists recent inspection job IDs in browser `localStorage` with quick search/switcher.
6. **Model Limitations & Disclosures**: Highlights prototype status, ~42.6% mAP@50 test metric, and human engineering verification requirements.

---

## Getting Started Locally

### Prerequisites

- Node.js (v18+ recommended; tested on v24.19)
- npm (v9+)
- PipeSight AI backend running (default `http://127.0.0.1:8000`)

### 1. Configure Environment

Copy `.env.example` to `.env`:

```bash
cp .env.example .env
```

Verify `VITE_API_BASE_URL`:

```env
VITE_API_BASE_URL=http://127.0.0.1:8000
VITE_POLL_INTERVAL_MS=1000
```

### 2. Install Dependencies

```bash
npm install
```

### 3. Start Development Server

```bash
npm run dev
```

Open [http://localhost:5173](http://localhost:5173) in your browser.

---

## Production Build

To type-check and generate optimized production assets:

```bash
npm run build
```

Production static assets will be output to the `dist/` folder.

To preview the production build locally:

```bash
npm run preview
```

---

## Deployment Instructions

> **Note:** The backend and frontend are built and deployed as separate services. Never bundle backend credentials or AWS access keys into frontend client code.

### Configuring the Backend HTTPS URL

Before deploying the frontend, configure the deployed backend URL in your hosting environment variables:

```env
VITE_API_BASE_URL=https://api.pipesight.yourdomain.com
```

### Static Host Deployment Options

Because the frontend is a Single Page Application (SPA), it can be deployed to any static web host:

#### Option A: Vercel

1. Connect your repository to Vercel.
2. Set Root Directory to `frontend`.
3. Framework Preset: `Vite`.
4. Add Environment Variable:
   - `VITE_API_BASE_URL`: `https://api.pipesight.yourdomain.com`
5. Deploy.

#### Option B: Netlify

1. Connect repository to Netlify.
2. Base directory: `frontend`.
3. Build command: `npm run build`.
4. Publish directory: `frontend/dist`.
5. Set `VITE_API_BASE_URL` in Site settings > Environment variables.

#### Option C: Cloudflare Pages

1. Create a project connected to your Git repository.
2. Build command: `npm run build`.
3. Build output directory: `dist`.
4. Root directory: `frontend`.
5. Add `VITE_API_BASE_URL` in Environment Variables.

#### Option D: AWS S3 + CloudFront

1. Build locally: `npm run build`
2. Sync the `dist/` directory to your S3 static website hosting bucket:
   ```bash
   aws s3 sync dist/ s3://pipesight-ai-dashboard --delete
   ```
3. Configure CloudFront distribution pointing to the S3 bucket with SPA error handling (redirect 404 to `/index.html` with HTTP 200).
4. Configure backend CORS to allow `https://pipesight.yourdomain.com`.

---

## Backend Coordination & Verification

Ensure your backend FastAPI server has CORS configured to permit requests from your frontend origin:

```python
# In backend/app/config.py:
CORS_ORIGINS = ["https://pipesight.yourdomain.com", "http://localhost:5173"]
```

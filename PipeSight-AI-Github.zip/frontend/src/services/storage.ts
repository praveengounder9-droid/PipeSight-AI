/**
 * Storage helper for persisting recent inspection jobs in localStorage
 */

import type { RecentJobRecord } from '../types/inspection';

const STORAGE_KEY = 'pipesight_recent_jobs_v1';
const MAX_SAVED = 15;

export function getRecentJobs(): RecentJobRecord[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed)) {
      return parsed;
    }
    return [];
  } catch {
    return [];
  }
}

export function saveRecentJob(job: RecentJobRecord): void {
  try {
    const existing = getRecentJobs();
    // remove existing if same jobId
    const filtered = existing.filter((item) => item.job_id !== job.job_id);
    const updated = [job, ...filtered].slice(0, MAX_SAVED);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  } catch {
    // localStorage may be disabled or full
  }
}

export function updateRecentJobStatus(
  jobId: string,
  status: RecentJobRecord['status'],
  eventsCount?: number
): void {
  try {
    const existing = getRecentJobs();
    const updated = existing.map((item) => {
      if (item.job_id === jobId) {
        return {
          ...item,
          status,
          events_count: eventsCount !== undefined ? eventsCount : item.events_count,
        };
      }
      return item;
    });
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  } catch {
    // ignore
  }
}

export function clearRecentJobs(): void {
  try {
    localStorage.removeItem(STORAGE_KEY);
  } catch {
    // ignore
  }
}

/**
 * PipeSight AI - API Client Module
 * Communicates with the FastAPI backend.
 * Resolves relative URLs against the configured backend base URL.
 */

import type {
  EvidenceListResponse,
  HealthResponse,
  InspectionReport,
  JobCreationResponse,
  JobStatusResponse,
  SystemInfoResponse,
} from '../types/inspection';

// Configurable backend base URL (from VITE_API_BASE_URL env var)
const rawBaseUrl = typeof import.meta.env.VITE_API_BASE_URL === 'string'
  ? import.meta.env.VITE_API_BASE_URL
  : 'http://127.0.0.1:8000';
export const API_BASE_URL = rawBaseUrl.replace(/\/+$/, '');

/**
 * Resolve any URL returned by backend.
 * If backend returned a relative URL (e.g. /api/v1/inspect/...), resolve it
 * against the configured API_BASE_URL.
 */
export function resolveBackendUrl(pathOrUrl?: string | null): string {
  if (!pathOrUrl) return '';
  if (/^https?:\/\//i.test(pathOrUrl)) {
    return pathOrUrl;
  }
  const cleanPath = pathOrUrl.startsWith('/') ? pathOrUrl : `/${pathOrUrl}`;
  return API_BASE_URL ? `${API_BASE_URL}${cleanPath}` : cleanPath;
}

export class ApiError extends Error {
  status?: number;
  data?: unknown;

  constructor(message: string, status?: number, data?: unknown) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.data = data;
  }
}

/**
 * Helper to process fetch responses and extract helpful error messages.
 */
async function handleResponse<T>(res: Response): Promise<T> {
  if (!res.ok) {
    let errorDetail = `HTTP ${res.status}: ${res.statusText}`;
    try {
      const errJson = await res.json();
      if (errJson && typeof errJson === 'object') {
        if ('detail' in errJson && typeof errJson.detail === 'string') {
          errorDetail = errJson.detail;
        } else if ('message' in errJson && typeof errJson.message === 'string') {
          errorDetail = errJson.message;
        } else {
          errorDetail = JSON.stringify(errJson);
        }
      }
    } catch {
      // not JSON
      try {
        const text = await res.text();
        if (text) errorDetail = text;
      } catch {
        // ignore
      }
    }
    throw new ApiError(errorDetail, res.status);
  }
  return res.json() as Promise<T>;
}

/**
 * Check backend service health (/health)
 */
export async function checkHealth(signal?: AbortSignal): Promise<HealthResponse> {
  const url = `${API_BASE_URL}/health`;
  try {
    const res = await fetch(url, {
      method: 'GET',
      headers: { Accept: 'application/json' },
      signal,
    });
    return await handleResponse<HealthResponse>(res);
  } catch (err: unknown) {
    if (err instanceof ApiError) throw err;
    const msg = err instanceof Error ? err.message : 'Network failure';
    throw new ApiError(`Unable to connect to PipeSight backend at ${API_BASE_URL}: ${msg}`);
  }
}

/**
 * Retrieve system information & model configurations (/api/v1/info)
 */
export async function getSystemInfo(signal?: AbortSignal): Promise<SystemInfoResponse> {
  const url = `${API_BASE_URL}/api/v1/info`;
  try {
    const res = await fetch(url, {
      method: 'GET',
      headers: { Accept: 'application/json' },
      signal,
    });
    return await handleResponse<SystemInfoResponse>(res);
  } catch (err: unknown) {
    if (err instanceof ApiError) throw err;
    const msg = err instanceof Error ? err.message : 'Network failure';
    throw new ApiError(`Failed to fetch system info from ${API_BASE_URL}: ${msg}`);
  }
}

/**
 * Submit video for inspection: POST /api/v1/inspect/video
 * Note: multipart/form-data. Do NOT set Content-Type header!
 */
export async function uploadInspectionVideo(
  file: File,
  signal?: AbortSignal
): Promise<JobCreationResponse> {
  const url = `${API_BASE_URL}/api/v1/inspect/video`;
  const formData = new FormData();
  formData.append('file', file, file.name);

  try {
    const res = await fetch(url, {
      method: 'POST',
      body: formData,
      signal,
      // NOTE: Do not pass Content-Type header so browser sets multipart boundary automatically
    });
    return await handleResponse<JobCreationResponse>(res);
  } catch (err: unknown) {
    if (err instanceof ApiError) throw err;
    const msg = err instanceof Error ? err.message : 'Upload failed';
    throw new ApiError(`Inspection upload failed: ${msg}`);
  }
}

/**
 * Poll job status: GET /api/v1/inspect/{job_id}
 */
export async function getJobStatus(jobId: string, signal?: AbortSignal): Promise<JobStatusResponse> {
  const cleanId = encodeURIComponent(jobId.trim());
  const url = `${API_BASE_URL}/api/v1/inspect/${cleanId}`;
  try {
    const res = await fetch(url, {
      method: 'GET',
      headers: { Accept: 'application/json' },
      signal,
    });
    return await handleResponse<JobStatusResponse>(res);
  } catch (err: unknown) {
    if (err instanceof ApiError) throw err;
    const msg = err instanceof Error ? err.message : 'Polling failed';
    throw new ApiError(`Failed to retrieve job status for '${jobId}': ${msg}`);
  }
}

/**
 * Fetch complete inspection report: GET /api/v1/inspect/{job_id}/report
 */
export async function getInspectionReport(
  jobId: string,
  signal?: AbortSignal
): Promise<InspectionReport> {
  const cleanId = encodeURIComponent(jobId.trim());
  const url = `${API_BASE_URL}/api/v1/inspect/${cleanId}/report`;
  try {
    const res = await fetch(url, {
      method: 'GET',
      headers: { Accept: 'application/json' },
      signal,
    });
    return await handleResponse<InspectionReport>(res);
  } catch (err: unknown) {
    if (err instanceof ApiError) throw err;
    const msg = err instanceof Error ? err.message : 'Report request failed';
    throw new ApiError(`Failed to fetch report for '${jobId}': ${msg}`);
  }
}

/**
 * Fetch evidence images list: GET /api/v1/inspect/{job_id}/evidence
 */
export async function getEvidenceList(
  jobId: string,
  signal?: AbortSignal
): Promise<EvidenceListResponse> {
  const cleanId = encodeURIComponent(jobId.trim());
  const url = `${API_BASE_URL}/api/v1/inspect/${cleanId}/evidence`;
  try {
    const res = await fetch(url, {
      method: 'GET',
      headers: { Accept: 'application/json' },
      signal,
    });
    return await handleResponse<EvidenceListResponse>(res);
  } catch (err: unknown) {
    if (err instanceof ApiError) throw err;
    const msg = err instanceof Error ? err.message : 'Evidence request failed';
    throw new ApiError(`Failed to fetch evidence for '${jobId}': ${msg}`);
  }
}

/**
 * Direct artifact URL helpers
 */
export function getAnnotatedVideoUrl(jobId: string): string {
  return `${API_BASE_URL}/api/v1/inspect/${encodeURIComponent(jobId)}/video`;
}

export function getPdfReportUrl(jobId: string): string {
  return `${API_BASE_URL}/api/v1/inspect/${encodeURIComponent(jobId)}/report.pdf`;
}

export function getJsonReportUrl(jobId: string): string {
  return `${API_BASE_URL}/api/v1/inspect/${encodeURIComponent(jobId)}/report`;
}

export function getZipReportUrl(jobId: string): string {
  return `${API_BASE_URL}/api/v1/inspect/${encodeURIComponent(jobId)}/zip`;
}

export function getTraceReportUrl(jobId: string): string {
  return `${API_BASE_URL}/api/v1/inspect/${encodeURIComponent(jobId)}/trace`;
}

/**
 * PipeSight AI - TypeScript Schema Definitions
 * Perfectly matched with FastAPI backend app.schemas
 */

export type JobStatus = 'queued' | 'processing' | 'completed' | 'failed';

export type AgentDecisionType =
  | 'CONTINUE'
  | 'ENHANCE_AND_RECHECK'
  | 'INSPECT_ADJACENT_FRAMES'
  | 'REQUEST_HUMAN_REVIEW'
  | 'LOG_AND_CONTINUE'
  | string;

export interface HealthResponse {
  status: string;
  opencv_version: string;
  torch_version: string;
  ultralytics_version: string;
  cool_enabled: boolean;
  cool_status: string;
  model_loaded: boolean;
  model_path?: string;
  model_hash?: string;
  device: string;
  classes_count: number;
  capabilities: string[];
}

export interface SystemInfoResponse {
  model_name: string;
  model_hash?: string;
  class_names: Record<string | number, string>;
  class_count: number;
  confidence_threshold: number;
  iou_threshold: number;
  frame_stride?: number;
  max_processing_dim?: number;
  cpu_threads?: number;
  supported_file_types: string[];
  supported_processing_modes: string[];
  storage_backend: string;
  model_metric_map50: string;
  model_limitations_notice: string;
  retention_hours?: number;
  storage_notice?: string;
}

export interface QualityMetrics {
  brightness_mean: number;
  brightness_std: number;
  blur_score: number;
  contrast_score: number;
  is_too_dark: boolean;
  is_too_bright: boolean;
  is_blurry: boolean;
  is_low_contrast: boolean;
  is_low_quality: boolean;
  quality_flags: string[];
}

export interface DetectionBox {
  class_id: number;
  class_name: string;
  confidence: number;
  bbox: [number, number, number, number];
  track_id?: number | null;
  frame_idx: number;
  timestamp_sec: number;
  enhanced: boolean;
}

export interface TrackEvent {
  track_id: number;
  class_id: number;
  class_name: string;
  advisory_label: string;
  observation_count: number;
  first_seen_sec: number;
  last_seen_sec: number;
  duration_sec: number;
  peak_confidence: number;
  avg_confidence: number;
  representative_frame_idx: number;
  representative_timestamp_sec: number;
  representative_bbox: [number, number, number, number];
  evidence_image_key?: string | null;
  evidence_image_url?: string | null;
}

export interface AgentTraceStep {
  frame: number;
  timestamp_sec: number;
  observations: {
    brightness_mean?: number;
    brightness_std?: number;
    blur_score?: number;
    contrast_score?: number;
    [key: string]: unknown;
  };
  decision: AgentDecisionType;
  action: string;
  next_action: string;
  outcome: string;
  details?: string | null;
}

export interface VideoMetadata {
  filename: string;
  duration_sec: number;
  fps: number;
  width: number;
  height: number;
  total_frames: number;
  processed_frames: number;
}

export interface InspectionSummaryData {
  raw_detections_count: number;
  estimated_unique_events_count: number;
  events_by_class: Record<string, number>;
  low_quality_frames_count: number;
  enhanced_frames_count: number;
}

export interface AgentDecisionsSummary {
  total_actions: number;
  action_counts: Record<string, number>;
  sample_traces: AgentTraceStep[];
}

export interface ReportArtifacts {
  annotated_video_url?: string | null;
  pdf_report_url?: string | null;
  evidence_images: Array<EvidenceItem | Record<string, unknown>>;
}

export interface ModelIdentity {
  model_name: string;
  checkpoint_hash?: string;
  classes: Record<string | number, string>;
  opencv_version: string;
  ultralytics_version: string;
  device: string;
}

export interface PerformanceMetrics {
  original_resolution: [number, number];
  processing_resolution: [number, number];
  fps: number;
  total_source_frames: number;
  frames_processed: number;
  frames_skipped: number;
  frame_stride: number;
  confidence_threshold: number;
  video_duration_sec: number;
  actual_processing_duration_sec: number;
  processing_fps: number;
  time_breakdown_sec: Record<string, number>;
  enhancement_retries: number;
  candidate_defect_events_count: number;
  processing_limitations: string[];
}

export interface InspectionReport {
  job_id: string;
  created_at_utc: string;
  completed_at_utc?: string | null;
  model_identity: ModelIdentity;
  video_statistics: VideoMetadata;
  summary: InspectionSummaryData;
  defect_events: TrackEvent[];
  agent_decisions_summary: AgentDecisionsSummary;
  performance_metrics?: PerformanceMetrics;
  artifacts: ReportArtifacts;
  limitations_and_disclosures: {
    prototype_status?: string;
    validation_metric?: string;
    advisory_notice?: string;
    tracking_disclaimer?: string;
    spatial_disclaimer?: string;
    recommendation?: string;
    [key: string]: unknown;
  };
}

export interface JobCreationResponse {
  job_id: string;
  status: JobStatus;
  filename: string;
  file_size_bytes: number;
  message: string;
  created_at: string;
  status_url: string;
}

export interface JobStatusResponse {
  job_id: string;
  status: JobStatus;
  progress_pct: number;
  current_frame: number;
  total_frames: number;
  frames_processed?: number;
  frames_skipped?: number;
  frame_stride?: number;
  processing_fps?: number | null;
  elapsed_sec: number;
  estimated_time_remaining_sec: number | null;
  error_message: string | null;
  report_url: string | null;
  video_url: string | null;
  pdf_url: string | null;
  zip_url?: string | null;
  updated_at: string;
}

export interface EvidenceItem {
  evidence_id: string;
  track_id?: number | null;
  class_name: string;
  confidence: number;
  frame_idx: number;
  timestamp_sec: number;
  url: string;
  key: string;
}

export interface EvidenceListResponse {
  job_id: string;
  count: number;
  evidence_items: EvidenceItem[];
}

export interface RecentJobRecord {
  job_id: string;
  filename: string;
  file_size_bytes?: number;
  created_at: string;
  status: JobStatus;
  events_count?: number;
}

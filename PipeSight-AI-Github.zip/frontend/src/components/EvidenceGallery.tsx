import { useState } from 'react';
import {
  Download,
  ImageIcon,
  Maximize2,
  X,
} from 'lucide-react';
import type { EvidenceItem, TrackEvent } from '../types/inspection';
import { resolveBackendUrl } from '../services/api';

interface Props {
  jobId: string;
  events?: TrackEvent[];
  evidenceItems?: EvidenceItem[];
  selectedEvent?: TrackEvent | null;
  onClearSelectedEvent?: () => void;
  onSeekVideo?: (seconds: number) => void;
}

export const EvidenceGallery: React.FC<Props> = ({
  jobId,
  events = [],
  evidenceItems = [],
  selectedEvent,
  onClearSelectedEvent,
  onSeekVideo,
}) => {
  const [modalItem, setModalItem] = useState<{
    url: string;
    title: string;
    trackId?: number | null;
    confidence: number;
    timestamp: number;
    frameIdx?: number;
  } | null>(null);

  // Consolidate evidence sources (from events with evidence_image_url and evidenceItems)
  const items: Array<{
    id: string;
    url: string;
    title: string;
    trackId: number;
    confidence: number;
    timestamp: number;
    frameIdx: number;
  }> = [];

  // Priority 1: defect_events
  events.forEach((ev) => {
    if (ev.evidence_image_url || ev.evidence_image_key) {
      const filename = ev.evidence_image_key
        ? ev.evidence_image_key.split('/').pop()
        : `evidence_track_${ev.track_id}.jpg`;
      const url = ev.evidence_image_url
        ? resolveBackendUrl(ev.evidence_image_url)
        : resolveBackendUrl(`/api/v1/inspect/${jobId}/evidence/${filename}`);

      items.push({
        id: `event_${ev.track_id}`,
        url,
        title: ev.advisory_label || ev.class_name,
        trackId: ev.track_id,
        confidence: ev.peak_confidence,
        timestamp: ev.representative_timestamp_sec,
        frameIdx: ev.representative_frame_idx,
      });
    }
  });

  // Priority 2: evidenceItems from /evidence endpoint if not already added
  evidenceItems.forEach((evItem) => {
    const existing = items.find((i) => i.trackId === evItem.track_id);
    if (!existing) {
      items.push({
        id: evItem.evidence_id,
        url: resolveBackendUrl(evItem.url),
        title: evItem.class_name,
        trackId: evItem.track_id ?? 0,
        confidence: evItem.confidence,
        timestamp: evItem.timestamp_sec,
        frameIdx: evItem.frame_idx,
      });
    }
  });

  if (items.length === 0) {
    return (
      <div className="glass-card">
        <div className="card-header">
          <div className="card-title-group">
            <ImageIcon size={18} color="var(--accent-cyan)" />
            <div className="card-title">Representative Defect Evidence Gallery</div>
          </div>
        </div>
        <div
          className="card-body"
          style={{
            textAlign: 'center',
            padding: '2.5rem',
            color: 'var(--text-muted)',
          }}
        >
          <div style={{ fontSize: '0.95rem', fontWeight: 600, color: 'var(--text-secondary)' }}>
            No defect snapshots extracted.
          </div>
          <p style={{ fontSize: '0.8rem', marginTop: '0.35rem' }}>
            Evidence snapshots are captured when a sustained defect track is confirmed by the ByteTrack tracker.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="glass-card">
      <div className="card-header">
        <div className="card-title-group">
          <ImageIcon size={18} color="var(--accent-cyan)" />
          <div>
            <div className="card-title">Representative Defect Evidence Gallery</div>
            <div className="card-subtitle">
              High-resolution annotated snapshots saved at peak model confidence frames
            </div>
          </div>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
          {selectedEvent && onClearSelectedEvent && (
            <button
              type="button"
              onClick={onClearSelectedEvent}
              className="btn btn-secondary btn-sm"
              style={{ fontSize: '0.72rem', padding: '0.2rem 0.5rem' }}
            >
              Clear Highlight (Track #{selectedEvent.track_id})
            </button>
          )}
          <span className="badge badge-cyan">{items.length} Snapshots Available</span>
        </div>
      </div>

      <div className="card-body">
        <div className="evidence-grid">
          {items.map((item) => {
            const isHighlighted = selectedEvent?.track_id === item.trackId;

            return (
              <div
                key={item.id}
                className="evidence-card"
                onClick={() => setModalItem(item)}
                style={{
                  border: isHighlighted
                    ? '2px solid var(--accent-cyan)'
                    : '1px solid var(--border-card)',
                  boxShadow: isHighlighted ? '0 0 20px rgba(6, 182, 212, 0.4)' : undefined,
                }}
              >
                <div className="evidence-thumb-wrap">
                  <img
                    src={item.url}
                    alt={`Track #${item.trackId} - ${item.title}`}
                    className="evidence-thumb-img"
                    loading="lazy"
                    onError={(e) => {
                      (e.target as HTMLElement).style.display = 'none';
                    }}
                  />
                  <div
                    style={{
                      position: 'absolute',
                      top: '8px',
                      left: '8px',
                      background: 'rgba(7, 10, 18, 0.85)',
                      backdropFilter: 'blur(4px)',
                      padding: '0.2rem 0.5rem',
                      borderRadius: '4px',
                      fontFamily: 'var(--font-mono)',
                      fontSize: '0.72rem',
                      color: 'var(--accent-cyan-light)',
                      border: '1px solid rgba(6, 182, 212, 0.3)',
                    }}
                  >
                    Track #{item.trackId}
                  </div>

                  <div
                    style={{
                      position: 'absolute',
                      bottom: '8px',
                      right: '8px',
                      background: 'rgba(7, 10, 18, 0.85)',
                      padding: '0.2rem 0.5rem',
                      borderRadius: '4px',
                      fontFamily: 'var(--font-mono)',
                      fontSize: '0.72rem',
                      color: '#fbbf24',
                    }}
                  >
                    Score: {(item.confidence * 100).toFixed(1)}%
                  </div>
                </div>

                <div className="evidence-details">
                  <div style={{ fontWeight: 600, fontSize: '0.88rem', color: '#f8fafc' }}>
                    {item.title}
                  </div>
                  <div
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      fontSize: '0.75rem',
                      color: 'var(--text-muted)',
                      fontFamily: 'var(--font-mono)',
                    }}
                  >
                    <span>Time: {item.timestamp.toFixed(2)}s</span>
                    <span>Frame: {item.frameIdx}</span>
                  </div>

                  <div
                    style={{
                      display: 'flex',
                      gap: '0.4rem',
                      marginTop: '0.4rem',
                      borderTop: '1px solid var(--border-subtle)',
                      paddingTop: '0.4rem',
                    }}
                  >
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onSeekVideo?.(item.timestamp);
                      }}
                      className="btn btn-secondary btn-sm"
                      style={{ flex: 1, padding: '0.25rem 0.5rem', fontSize: '0.72rem' }}
                    >
                      Seek in Video
                    </button>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setModalItem(item);
                      }}
                      className="btn btn-outline-cyan btn-sm"
                      style={{ padding: '0.25rem 0.5rem', fontSize: '0.72rem' }}
                      title="Enlarge snapshot"
                    >
                      <Maximize2 size={12} />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* High-Resolution Evidence Lightbox Modal */}
      {modalItem && (
        <div className="modal-overlay" onClick={() => setModalItem(null)}>
          <div
            className="modal-content"
            onClick={(e) => e.stopPropagation()}
            style={{ maxWidth: '900px' }}
          >
            <div className="card-header">
              <div className="card-title-group">
                <ImageIcon size={18} color="var(--accent-cyan)" />
                <div>
                  <div className="card-title">{modalItem.title}</div>
                  <div
                    style={{
                      fontSize: '0.8rem',
                      fontFamily: 'var(--font-mono)',
                      color: 'var(--text-muted)',
                    }}
                  >
                    Track #{modalItem.trackId} | Peak Prediction Score: {(modalItem.confidence * 100).toFixed(1)}%
                    | Timestamp: {modalItem.timestamp.toFixed(2)}s
                  </div>
                </div>
              </div>

              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                <a
                  href={modalItem.url}
                  download={`PipeSight_Evidence_Track_${modalItem.trackId}.jpg`}
                  className="btn btn-secondary btn-sm"
                  title="Download full resolution JPEG"
                >
                  <Download size={14} /> Download Image
                </a>
                <button
                  type="button"
                  onClick={() => setModalItem(null)}
                  className="btn btn-secondary btn-sm"
                  title="Close modal"
                >
                  <X size={16} />
                </button>
              </div>
            </div>

            <div style={{ padding: '1.25rem', background: '#000', textAlign: 'center' }}>
              <img
                src={modalItem.url}
                alt={modalItem.title}
                style={{
                  maxWidth: '100%',
                  maxHeight: '65vh',
                  objectFit: 'contain',
                  borderRadius: 'var(--radius-sm)',
                  border: '1px solid var(--border-subtle)',
                }}
              />
            </div>

            <div
              style={{
                padding: '1rem 1.25rem',
                background: 'var(--bg-card)',
                borderTop: '1px solid var(--border-subtle)',
                fontSize: '0.8rem',
                color: 'var(--text-secondary)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                flexWrap: 'wrap',
                gap: '0.5rem',
              }}
            >
              <div>
                <strong>Advisory Note:</strong> Bounding box coordinates and defect annotations were generated
                by OpenCV 5 drawing routines based on the YOLO26s detection network and ByteTrack Kalman filter state.
              </div>
              <button
                type="button"
                onClick={() => {
                  onSeekVideo?.(modalItem.timestamp);
                  setModalItem(null);
                }}
                className="btn btn-primary btn-sm"
              >
                Seek Video to this Frame ({modalItem.timestamp.toFixed(2)}s)
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

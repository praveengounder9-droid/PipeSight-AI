import { useState, useRef, useCallback } from 'react';
import {
  UploadCloud,
  FileVideo,
  Play,
  AlertCircle,
  Film,
  Info,
  Clock,
  Sparkles,
} from 'lucide-react';
import { uploadInspectionVideo } from '../services/api';
import type { JobCreationResponse } from '../types/inspection';

interface Props {
  onInspectionStarted: (jobId: string, filename: string, fileSize: number) => void;
  isBackendHealthy: boolean;
  supportedFormats?: string[];
}

export const VideoUploader: React.FC<Props> = ({
  onInspectionStarted,
  isBackendHealthy,
  supportedFormats = ['.mp4', '.avi', '.mov', '.mkv', '.webm'],
}) => {
  const [file, setFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [uploadProgress, setUploadProgress] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const formatFileSize = (bytes: number): string => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
  };

  const handleFileSelect = useCallback(
    (selectedFile: File) => {
      setErrorMessage(null);
      const ext = `.${selectedFile.name.split('.').pop()?.toLowerCase()}`;

      if (!supportedFormats.includes(ext)) {
        setErrorMessage(
          `Unsupported file format '${ext}'. Supported CCTV formats: ${supportedFormats.join(', ')}`
        );
        return;
      }

      // Check max size 500 MB (matching backend MAX_UPLOAD_SIZE_MB)
      const maxMb = 500;
      if (selectedFile.size > maxMb * 1024 * 1024) {
        setErrorMessage(`File exceeds the maximum upload limit of ${maxMb} MB.`);
        return;
      }

      setFile(selectedFile);

      // Create preview object URL if browser supports video codec
      try {
        const url = URL.createObjectURL(selectedFile);
        setPreviewUrl(url);
      } catch {
        setPreviewUrl(null);
      }
    },
    [supportedFormats]
  );

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleFileSelect(e.dataTransfer.files[0]);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!file || isSubmitting) return;

    if (!isBackendHealthy) {
      setErrorMessage('Backend is currently offline. Please ensure the backend server is running.');
      return;
    }

    setIsSubmitting(true);
    setErrorMessage(null);
    setUploadProgress('Uploading video to PipeSight backend via multipart stream...');

    try {
      const response: JobCreationResponse = await uploadInspectionVideo(file);
      setUploadProgress('Inspection job registered. Starting perception loop...');
      onInspectionStarted(response.job_id, file.name, file.size);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Video submission failed';
      setErrorMessage(msg);
      setIsSubmitting(false);
      setUploadProgress(null);
    }
  };

  return (
    <div className="glass-card" style={{ maxWidth: '840px', margin: '0 auto' }}>
      <div className="card-header">
        <div className="card-title-group">
          <Film size={20} color="var(--accent-cyan)" />
          <div>
            <div className="card-title">New CCTV Sewer Inspection</div>
            <div className="card-subtitle">
              Upload monocular pipe inspection footage for Agentic Vision & ByteTrack analysis
            </div>
          </div>
        </div>
        <div style={{ display: 'flex', gap: '0.4rem', flexWrap: 'wrap' }}>
          {supportedFormats.map((fmt) => (
            <span key={fmt} className="badge badge-cyan" style={{ fontSize: '0.7rem' }}>
              {fmt}
            </span>
          ))}
        </div>
      </div>

      <div className="card-body">
        <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
          {/* Hidden File Input */}
          <input
            type="file"
            ref={fileInputRef}
            onChange={(e) => {
              if (e.target.files && e.target.files[0]) {
                handleFileSelect(e.target.files[0]);
              }
            }}
            accept={supportedFormats.join(',')}
            style={{ display: 'none' }}
            id="video-file-input"
            disabled={isSubmitting}
          />

          {/* Drag & Drop Zone */}
          <div
            className={`dropzone-container ${isDragging ? 'is-dragging' : ''}`}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            onClick={() => !isSubmitting && fileInputRef.current?.click()}
            role="button"
            tabIndex={0}
            onKeyDown={(e) => {
              if (e.key === 'Enter' || e.key === ' ') {
                fileInputRef.current?.click();
              }
            }}
            aria-label="Upload sewer inspection video file"
          >
            <div className="dropzone-icon-box">
              <UploadCloud size={34} />
            </div>
            <h3 style={{ fontSize: '1.15rem', marginBottom: '0.35rem', color: '#ffffff' }}>
              {file ? 'Replace Selected Video' : 'Drag & Drop Sewer Video Here'}
            </h3>
            <p style={{ fontSize: '0.88rem', color: 'var(--text-muted)', marginBottom: '0.75rem' }}>
              or click to browse your local computer
            </p>
            <div
              style={{
                display: 'inline-flex',
                alignItems: 'center',
                gap: '0.4rem',
                fontSize: '0.78rem',
                color: 'var(--text-dim)',
              }}
            >
              <span>Formats: MP4, AVI, MOV, MKV, WEBM</span>
              <span>•</span>
              <span>Max file size: 500 MB</span>
            </div>
          </div>

          {/* File Selected Preview Section */}
          {file && (
            <div
              style={{
                background: 'rgba(10, 16, 29, 0.85)',
                border: '1px solid var(--border-subtle)',
                borderRadius: 'var(--radius-md)',
                padding: '1.1rem',
                display: 'flex',
                flexDirection: 'column',
                gap: '1rem',
              }}
            >
              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  flexWrap: 'wrap',
                  gap: '0.75rem',
                }}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                  <div
                    style={{
                      width: '42px',
                      height: '42px',
                      borderRadius: 'var(--radius-sm)',
                      background: 'rgba(6, 182, 212, 0.15)',
                      border: '1px solid rgba(6, 182, 212, 0.3)',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      color: 'var(--accent-cyan-light)',
                    }}
                  >
                    <FileVideo size={22} />
                  </div>
                  <div>
                    <div style={{ fontWeight: 600, fontSize: '0.95rem', color: '#f8fafc' }}>
                      {file.name}
                    </div>
                    <div
                      style={{
                        fontFamily: 'var(--font-mono)',
                        fontSize: '0.78rem',
                        color: 'var(--text-muted)',
                      }}
                    >
                      Size: {formatFileSize(file.size)} | Type: {file.type || 'video'}
                    </div>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    setFile(null);
                    setPreviewUrl(null);
                  }}
                  disabled={isSubmitting}
                  className="btn btn-secondary btn-sm"
                >
                  Clear Selection
                </button>
              </div>

              {/* Local Browser Video Preview */}
              {previewUrl && (
                <div style={{ borderRadius: 'var(--radius-sm)', overflow: 'hidden', background: '#000' }}>
                  <video
                    src={previewUrl}
                    controls
                    style={{
                      width: '100%',
                      maxHeight: '260px',
                      display: 'block',
                      objectFit: 'contain',
                    }}
                  >
                    Your browser does not support the video preview tag.
                  </video>
                </div>
              )}
            </div>
          )}

          {/* Validation or Error State */}
          {errorMessage && (
            <div
              style={{
                background: 'rgba(239, 68, 68, 0.12)',
                border: '1px solid rgba(239, 68, 68, 0.35)',
                borderRadius: 'var(--radius-md)',
                padding: '0.9rem 1.1rem',
                display: 'flex',
                alignItems: 'center',
                gap: '0.75rem',
                color: '#fca5a5',
                fontSize: '0.85rem',
              }}
              role="alert"
            >
              <AlertCircle size={20} style={{ flexShrink: 0 }} />
              <div>{errorMessage}</div>
            </div>
          )}

          {/* Backend offline warning */}
          {!isBackendHealthy && (
            <div
              style={{
                background: 'rgba(245, 158, 11, 0.12)',
                border: '1px solid rgba(245, 158, 11, 0.35)',
                borderRadius: 'var(--radius-md)',
                padding: '0.85rem 1rem',
                display: 'flex',
                alignItems: 'center',
                gap: '0.65rem',
                color: '#fcd34d',
                fontSize: '0.82rem',
              }}
            >
              <AlertCircle size={18} style={{ flexShrink: 0 }} />
              <div>
                Backend connection is not detected. Please verify that the FastAPI server is running
                before starting an inspection.
              </div>
            </div>
          )}

          {/* Non-cancellation Notice */}
          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '0.5rem',
              fontSize: '0.78rem',
              color: 'var(--text-dim)',
              padding: '0 0.25rem',
            }}
          >
            <Info size={14} />
            <span>
              <strong>Pipeline notice:</strong> The Agentic Vision worker executes sequentially on the backend.
              Cancellation is not supported once analysis commences.
            </span>
          </div>

          {/* Submit Actions */}
          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              flexWrap: 'wrap',
              gap: '1rem',
              borderTop: '1px solid var(--border-subtle)',
              paddingTop: '1.25rem',
            }}
          >
            <div style={{ fontSize: '0.82rem', color: 'var(--text-muted)' }}>
              {uploadProgress ? (
                <span style={{ color: 'var(--accent-cyan-light)', display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                  <Sparkles size={15} /> {uploadProgress}
                </span>
              ) : file ? (
                <span>Ready to transmit to OpenCV 5 inspection pipeline</span>
              ) : (
                <span>Please select a CCTV inspection video to begin</span>
              )}
            </div>

            <button
              type="submit"
              disabled={!file || isSubmitting || !isBackendHealthy}
              className="btn btn-primary"
              style={{ minWidth: '220px' }}
            >
              {isSubmitting ? (
                <>
                  <Clock size={16} className="spin" /> Initializing Job...
                </>
              ) : (
                <>
                  <Play size={16} fill="currentColor" /> Start Agentic Inspection
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

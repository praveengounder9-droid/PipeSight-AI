import {
  AlertTriangle,
  Film,
  Layers,
  Sparkles,
  Zap,
} from 'lucide-react';
import type { InspectionReport } from '../types/inspection';

interface Props {
  report: InspectionReport;
}

export const InspectionSummary: React.FC<Props> = ({ report }) => {
  const {
    job_id,
    created_at_utc,
    completed_at_utc,
    video_statistics,
    summary,
    model_identity,
  } = report;

  const formatDate = (isoString?: string | null) => {
    if (!isoString) return '—';
    try {
      return new Date(isoString).toLocaleString();
    } catch {
      return isoString;
    }
  };

  const classCounts = summary.events_by_class || {};
  const classEntries = Object.entries(classCounts);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
      {/* Top Banner / Key Stat Cards */}
      <div className="metrics-grid">
        {/* Estimated Unique Track Events */}
        <div
          className="metric-card"
          style={{
            borderLeft: '3px solid var(--accent-cyan)',
            background: 'linear-gradient(135deg, rgba(6, 182, 212, 0.08), var(--bg-card))',
          }}
        >
          <div className="metric-header">
            <span className="metric-label">Unique Track Events</span>
            <Layers size={18} className="metric-icon" />
          </div>
          <div className="metric-value" style={{ color: 'var(--accent-cyan-light)' }}>
            {summary.estimated_unique_events_count}
          </div>
          <div className="metric-meta">
            ByteTrack deduplicated spatial defect occurrences
          </div>
        </div>

        {/* Raw Detections Found */}
        <div className="metric-card" style={{ borderLeft: '3px solid #3b82f6' }}>
          <div className="metric-header">
            <span className="metric-label">Raw Model Detections</span>
            <Zap size={18} style={{ color: '#60a5fa' }} />
          </div>
          <div className="metric-value" style={{ color: '#93c5fd' }}>
            {summary.raw_detections_count}
          </div>
          <div className="metric-meta">
            Total per-frame YOLO26s bounding box hits
          </div>
        </div>

        {/* Frames Processed */}
        <div className="metric-card" style={{ borderLeft: '3px solid #10b981' }}>
          <div className="metric-header">
            <span className="metric-label">Processed Frames</span>
            <Film size={18} style={{ color: '#34d399' }} />
          </div>
          <div className="metric-value">
            {video_statistics.processed_frames}
            <span style={{ fontSize: '0.9rem', color: 'var(--text-dim)', fontWeight: 400 }}>
              {' '}/ {video_statistics.total_frames}
            </span>
          </div>
          <div className="metric-meta">
            {video_statistics.duration_sec.toFixed(1)}s at {video_statistics.fps.toFixed(1)} FPS
          </div>
        </div>

        {/* Luminance & Quality Flagged */}
        <div className="metric-card" style={{ borderLeft: '3px solid #f59e0b' }}>
          <div className="metric-header">
            <span className="metric-label">Adaptive Enhancements</span>
            <Sparkles size={18} style={{ color: '#fbbf24' }} />
          </div>
          <div className="metric-value" style={{ color: '#fef08a' }}>
            {summary.enhanced_frames_count}
          </div>
          <div className="metric-meta">
            CLAHE applied ({summary.low_quality_frames_count} low-light flagged)
          </div>
        </div>
      </div>

      {/* Distinction Explainer Note */}
      <div
        style={{
          background: 'rgba(10, 15, 29, 0.65)',
          border: '1px solid var(--border-subtle)',
          borderRadius: 'var(--radius-md)',
          padding: '0.85rem 1.15rem',
          display: 'flex',
          alignItems: 'center',
          gap: '0.75rem',
          fontSize: '0.82rem',
        }}
      >
        <span className="badge badge-cyan" style={{ flexShrink: 0 }}>
          Deduplication Note
        </span>
        <span style={{ color: 'var(--text-secondary)' }}>
          <strong>Raw detections ({summary.raw_detections_count})</strong> count every frame in which a bounding box
          was produced. <strong>Unique track events ({summary.estimated_unique_events_count})</strong> are aggregated
          using ByteTrack to prevent multiple alerts for the same defect as the camera rolls past it.
        </span>
      </div>

      {/* Defect Classes Distribution Tags */}
      <div className="glass-card">
        <div className="card-header">
          <div className="card-title-group">
            <AlertTriangle size={18} color="#f59e0b" />
            <div>
              <div className="card-title">Defect Categories Identified</div>
              <div className="card-subtitle">
                Model-predicted classifications derived from this inspection report
              </div>
            </div>
          </div>
        </div>
        <div className="card-body">
          {classEntries.length > 0 ? (
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.75rem' }}>
              {classEntries.map(([className, count]) => (
                <div
                  key={className}
                  style={{
                    background: 'rgba(15, 23, 42, 0.9)',
                    border: '1px solid var(--border-card)',
                    borderRadius: 'var(--radius-md)',
                    padding: '0.75rem 1.1rem',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '0.85rem',
                  }}
                >
                  <span className="badge badge-defect" style={{ fontSize: '0.82rem' }}>
                    {className}
                  </span>
                  <div style={{ display: 'flex', flexDirection: 'column' }}>
                    <span
                      style={{
                        fontFamily: 'var(--font-mono)',
                        fontSize: '1.2rem',
                        fontWeight: 700,
                        color: '#ffffff',
                      }}
                    >
                      {count}
                    </span>
                    <span style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>
                      {count === 1 ? 'tracked event' : 'tracked events'}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div
              style={{
                textAlign: 'center',
                padding: '1.5rem',
                color: 'var(--text-muted)',
                fontSize: '0.9rem',
              }}
            >
              No suspected pipe defects detected above confidence threshold in this video footage.
            </div>
          )}
        </div>
      </div>

      {/* Video & Hardware Metadata Table */}
      <div className="glass-card">
        <div className="card-header">
          <div className="card-title-group">
            <Film size={18} color="var(--accent-cyan)" />
            <div>
              <div className="card-title">Inspection Telemetry & Metadata</div>
              <div className="card-subtitle">Camera encoding, OpenCV runtime, and model details</div>
            </div>
          </div>
        </div>
        <div className="card-body" style={{ padding: '0' }}>
          <div className="table-responsive">
            <table className="data-table">
              <tbody>
                <tr>
                  <th style={{ width: '25%' }}>Source Filename</th>
                  <td style={{ fontWeight: 600 }}>{video_statistics.filename}</td>
                  <th style={{ width: '25%' }}>Resolution</th>
                  <td style={{ fontFamily: 'var(--font-mono)' }}>
                    {video_statistics.width} × {video_statistics.height} px
                  </td>
                </tr>
                <tr>
                  <th>Job Identifier</th>
                  <td style={{ fontFamily: 'var(--font-mono)', fontSize: '0.8rem' }}>{job_id}</td>
                  <th>Duration / FPS</th>
                  <td style={{ fontFamily: 'var(--font-mono)' }}>
                    {video_statistics.duration_sec.toFixed(2)}s @ {video_statistics.fps.toFixed(2)} fps
                  </td>
                </tr>
                <tr>
                  <th>Analyzed / Total Frames</th>
                  <td style={{ fontFamily: 'var(--font-mono)' }}>
                    {video_statistics.processed_frames} / {video_statistics.total_frames} frames
                  </td>
                  <th>Inspection Timestamps</th>
                  <td style={{ fontSize: '0.8rem' }}>
                    Created: {formatDate(created_at_utc)} <br />
                    Finished: {formatDate(completed_at_utc)}
                  </td>
                </tr>
                <tr>
                  <th>AI Model Identity</th>
                  <td>{model_identity.model_name}</td>
                  <th>Runtime Device</th>
                  <td style={{ fontFamily: 'var(--font-mono)', color: 'var(--accent-cyan-light)' }}>
                    {model_identity.device}
                  </td>
                </tr>
                <tr>
                  <th>OpenCV Engine</th>
                  <td style={{ fontFamily: 'var(--font-mono)' }}>{model_identity.opencv_version}</td>
                  <th>Frame Sampling & Stride</th>
                  <td style={{ fontFamily: 'var(--font-mono)' }}>
                    {report.performance_metrics
                      ? `Stride ${report.performance_metrics.frame_stride} (${report.performance_metrics.frames_processed} proc / ${report.performance_metrics.frames_skipped} skip)`
                      : 'Stride 3'}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* CPU Performance & Throughput Profiling */}
      {report.performance_metrics && (
        <div className="glass-card">
          <div className="card-header">
            <div className="card-title-group">
              <Zap size={18} color="var(--accent-cyan)" />
              <div>
                <div className="card-title">CPU Performance & Execution Profiling</div>
                <div className="card-subtitle">
                  Hardware-optimized inference throughput ({report.performance_metrics.processing_fps.toFixed(1)} FPS actual processing speed)
                </div>
              </div>
            </div>
            <span className="badge badge-success" style={{ fontSize: '0.8rem' }}>
              {report.performance_metrics.processing_fps.toFixed(1)} FPS
            </span>
          </div>

          <div className="card-body">
            <div
              style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
                gap: '1rem',
                marginBottom: '1rem',
              }}
            >
              <div style={{ background: 'rgba(15, 23, 42, 0.7)', padding: '0.85rem', borderRadius: 'var(--radius-sm)', border: '1px solid var(--border-card)' }}>
                <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Resolution Downscaling</div>
                <div style={{ fontFamily: 'var(--font-mono)', fontWeight: 700, fontSize: '0.95rem', marginTop: '0.25rem' }}>
                  {report.performance_metrics.original_resolution[0]}×{report.performance_metrics.original_resolution[1]} &rarr; {report.performance_metrics.processing_resolution[0]}×{report.performance_metrics.processing_resolution[1]}
                </div>
              </div>

              <div style={{ background: 'rgba(15, 23, 42, 0.7)', padding: '0.85rem', borderRadius: 'var(--radius-sm)', border: '1px solid var(--border-card)' }}>
                <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Elapsed Execution Time</div>
                <div style={{ fontFamily: 'var(--font-mono)', fontWeight: 700, fontSize: '0.95rem', marginTop: '0.25rem' }}>
                  {report.performance_metrics.actual_processing_duration_sec.toFixed(2)}s
                </div>
              </div>

              <div style={{ background: 'rgba(15, 23, 42, 0.7)', padding: '0.85rem', borderRadius: 'var(--radius-sm)', border: '1px solid var(--border-card)' }}>
                <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Enhancement Retries</div>
                <div style={{ fontFamily: 'var(--font-mono)', fontWeight: 700, fontSize: '0.95rem', marginTop: '0.25rem' }}>
                  {report.performance_metrics.enhancement_retries} CLAHE runs
                </div>
              </div>

              <div style={{ background: 'rgba(15, 23, 42, 0.7)', padding: '0.85rem', borderRadius: 'var(--radius-sm)', border: '1px solid var(--border-card)' }}>
                <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Sampling Mode</div>
                <div style={{ fontFamily: 'var(--font-mono)', fontWeight: 700, fontSize: '0.95rem', marginTop: '0.25rem' }}>
                  Stride={report.performance_metrics.frame_stride} (CPU mode)
                </div>
              </div>
            </div>

            {/* Time breakdown */}
            {report.performance_metrics.time_breakdown_sec && (
              <div>
                <div style={{ fontSize: '0.8rem', color: 'var(--text-secondary)', fontWeight: 600, marginBottom: '0.5rem' }}>
                  Stage Timing Breakdown:
                </div>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.5rem' }}>
                  {Object.entries(report.performance_metrics.time_breakdown_sec).map(([stage, dur]) => (
                    <span
                      key={stage}
                      className="badge"
                      style={{
                        background: 'rgba(10, 16, 29, 0.8)',
                        border: '1px solid var(--border-card)',
                        color: 'var(--text-secondary)',
                        fontFamily: 'var(--font-mono)',
                        fontSize: '0.75rem',
                        padding: '0.35rem 0.65rem',
                      }}
                    >
                      {stage.replace(/_/g, ' ')}: <strong style={{ color: 'var(--accent-cyan-light)' }}>{dur.toFixed(3)}s</strong>
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

import { useState, useEffect, useCallback, useRef } from 'react';
import {
  CheckCircle2,
  Cpu,
  RefreshCw,
  Server,
  WifiOff,
  X,
  ExternalLink,
} from 'lucide-react';
import { checkHealth, API_BASE_URL } from '../services/api';
import type { HealthResponse } from '../types/inspection';

interface Props {
  onHealthLoaded?: (health: HealthResponse | null) => void;
}

export const BackendStatus: React.FC<Props> = ({ onHealthLoaded }) => {
  const [health, setHealth] = useState<HealthResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [latencyMs, setLatencyMs] = useState<number | null>(null);
  const [isOpen, setIsOpen] = useState(false);
  const [lastChecked, setLastChecked] = useState<Date | null>(null);
  const popoverRef = useRef<HTMLDivElement>(null);

  const performHealthCheck = useCallback(async () => {
    setLoading(true);
    const start = performance.now();
    try {
      const data = await checkHealth();
      const duration = Math.round(performance.now() - start);
      setLatencyMs(duration);
      setHealth(data);
      setError(null);
      setLastChecked(new Date());
      onHealthLoaded?.(data);
    } catch (err: unknown) {
      setHealth(null);
      setLatencyMs(null);
      const msg = err instanceof Error ? err.message : 'Backend unreachable';
      setError(msg);
      setLastChecked(new Date());
      onHealthLoaded?.(null);
    } finally {
      setLoading(false);
    }
  }, [onHealthLoaded]);

  useEffect(() => {
    performHealthCheck();
    const interval = setInterval(performHealthCheck, 20000); // refresh every 20s
    return () => clearInterval(interval);
  }, [performHealthCheck]);

  // Close popover when clicking outside
  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (popoverRef.current && !popoverRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    }
    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [isOpen]);

  const isHealthy = health !== null && !error;

  return (
    <div style={{ position: 'relative' }} ref={popoverRef}>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="backend-status-pill"
        title="Click to view backend diagnostics & server capabilities"
        aria-label="Backend Connection Status"
        aria-expanded={isOpen}
      >
        <div
          className={`status-dot ${
            loading && !health ? 'checking' : isHealthy ? 'healthy' : 'offline'
          }`}
        />
        <span style={{ color: isHealthy ? '#e2e8f0' : '#fca5a5' }}>
          {loading && !health
            ? 'Connecting...'
            : isHealthy
            ? 'Backend Connected'
            : 'Backend Disconnected'}
        </span>
        {latencyMs !== null && (
          <span
            style={{
              fontFamily: 'var(--font-mono)',
              fontSize: '0.72rem',
              color: 'var(--text-muted)',
              paddingLeft: '0.2rem',
            }}
          >
            {latencyMs}ms
          </span>
        )}
      </button>

      {/* Popover Card */}
      {isOpen && (
        <div
          style={{
            position: 'absolute',
            top: 'calc(100% + 8px)',
            right: 0,
            width: '380px',
            maxWidth: '90vw',
            background: 'var(--bg-card)',
            border: '1px solid var(--border-card)',
            borderRadius: 'var(--radius-lg)',
            boxShadow: 'var(--shadow-lg)',
            zIndex: 100,
            padding: '1.25rem',
            display: 'flex',
            flexDirection: 'column',
            gap: '0.9rem',
            animation: 'fadeIn 150ms ease',
          }}
        >
          {/* Header */}
          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              borderBottom: '1px solid var(--border-subtle)',
              paddingBottom: '0.75rem',
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <Server size={18} color="var(--accent-cyan)" />
              <span style={{ fontWeight: 700, fontSize: '0.95rem' }}>Backend Diagnostics</span>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  performHealthCheck();
                }}
                disabled={loading}
                title="Refresh health check"
                style={{
                  padding: '4px',
                  borderRadius: '4px',
                  color: 'var(--text-muted)',
                  display: 'flex',
                  alignItems: 'center',
                }}
              >
                <RefreshCw size={14} className={loading ? 'spin' : ''} />
              </button>
              <button
                onClick={() => setIsOpen(false)}
                title="Close diagnostics"
                style={{
                  padding: '4px',
                  borderRadius: '4px',
                  color: 'var(--text-muted)',
                  display: 'flex',
                  alignItems: 'center',
                }}
              >
                <X size={16} />
              </button>
            </div>
          </div>

          {/* Connection Target */}
          <div
            style={{
              background: 'rgba(10, 15, 29, 0.7)',
              padding: '0.65rem 0.85rem',
              borderRadius: 'var(--radius-sm)',
              border: '1px solid var(--border-subtle)',
              fontSize: '0.78rem',
            }}
          >
            <div style={{ color: 'var(--text-muted)', marginBottom: '0.2rem' }}>
              Target Endpoint (VITE_API_BASE_URL):
            </div>
            <div
              style={{
                fontFamily: 'var(--font-mono)',
                color: 'var(--accent-cyan-light)',
                wordBreak: 'break-all',
              }}
            >
              {API_BASE_URL}
            </div>
          </div>

          {/* Status info */}
          {isHealthy && health ? (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  fontSize: '0.82rem',
                }}
              >
                <span style={{ color: 'var(--text-muted)', display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                  <CheckCircle2 size={15} color="var(--status-healthy)" /> Health Status:
                </span>
                <span className="badge badge-success">HEALTHY</span>
              </div>

              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  fontSize: '0.82rem',
                }}
              >
                <span style={{ color: 'var(--text-muted)' }}>OpenCV Version:</span>
                <span style={{ fontFamily: 'var(--font-mono)', fontWeight: 600 }}>
                  {health.opencv_version}
                </span>
              </div>

              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  fontSize: '0.82rem',
                }}
              >
                <span style={{ color: 'var(--text-muted)', display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
                  <Cpu size={14} /> Compute Device:
                </span>
                <span style={{ fontFamily: 'var(--font-mono)', color: 'var(--accent-cyan-light)' }}>
                  {health.device}
                </span>
              </div>

              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  fontSize: '0.82rem',
                }}
              >
                <span style={{ color: 'var(--text-muted)' }}>Model Checkpoint:</span>
                <span className="badge badge-cyan">
                  {health.model_loaded ? 'Loaded' : 'Missing'}
                </span>
              </div>

              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  fontSize: '0.82rem',
                }}
              >
                <span style={{ color: 'var(--text-muted)' }}>Classes Recognized:</span>
                <span style={{ fontFamily: 'var(--font-mono)' }}>{health.classes_count} classes</span>
              </div>

              {/* Capabilities pills */}
              <div style={{ marginTop: '0.4rem' }}>
                <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginBottom: '0.35rem' }}>
                  Active Capabilities:
                </div>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.3rem' }}>
                  {health.capabilities.slice(0, 6).map((cap: string) => (
                    <span
                      key={cap}
                      style={{
                        fontFamily: 'var(--font-mono)',
                        fontSize: '0.68rem',
                        padding: '0.15rem 0.4rem',
                        borderRadius: '3px',
                        background: 'rgba(255, 255, 255, 0.05)',
                        border: '1px solid var(--border-subtle)',
                        color: 'var(--text-secondary)',
                      }}
                    >
                      {cap.replace(/_/g, ' ')}
                    </span>
                  ))}
                  {health.capabilities.length > 6 && (
                    <span style={{ fontSize: '0.68rem', color: 'var(--text-dim)', alignSelf: 'center' }}>
                      +{health.capabilities.length - 6} more
                    </span>
                  )}
                </div>
              </div>
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.6rem' }}>
              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '0.4rem',
                  color: 'var(--status-danger)',
                  fontSize: '0.85rem',
                  fontWeight: 600,
                }}
              >
                <WifiOff size={16} /> Backend Server Unreachable
              </div>
              <p style={{ fontSize: '0.78rem', color: 'var(--text-secondary)', lineHeight: 1.4 }}>
                {error || 'The frontend could not establish a connection to /health.'}
              </p>
              <div
                style={{
                  background: 'rgba(239, 68, 68, 0.1)',
                  border: '1px solid rgba(239, 68, 68, 0.3)',
                  borderRadius: 'var(--radius-sm)',
                  padding: '0.6rem',
                  fontSize: '0.75rem',
                  color: '#fca5a5',
                }}
              >
                Ensure your FastAPI backend is running:
                <div
                  style={{
                    fontFamily: 'var(--font-mono)',
                    marginTop: '0.3rem',
                    background: 'rgba(0,0,0,0.4)',
                    padding: '0.3rem 0.5rem',
                    borderRadius: '4px',
                    color: '#ffffff',
                  }}
                >
                  uvicorn app.main:app --host 127.0.0.1 --port 8000
                </div>
              </div>
            </div>
          )}

          {/* Footer */}
          <div
            style={{
              borderTop: '1px solid var(--border-subtle)',
              paddingTop: '0.6rem',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              fontSize: '0.72rem',
              color: 'var(--text-dim)',
            }}
          >
            <span>
              {lastChecked
                ? `Updated: ${lastChecked.toLocaleTimeString()}`
                : 'Not checked yet'}
            </span>
            <a
              href={`${API_BASE_URL}/docs`}
              target="_blank"
              rel="noopener noreferrer"
              style={{ display: 'inline-flex', alignItems: 'center', gap: '0.25rem' }}
            >
              OpenAPI /docs <ExternalLink size={11} />
            </a>
          </div>
        </div>
      )}
    </div>
  );
};

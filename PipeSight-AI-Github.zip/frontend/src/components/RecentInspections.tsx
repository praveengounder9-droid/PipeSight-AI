import { useState } from 'react';
import {
  History,
  Search,
  Trash2,
  X,
} from 'lucide-react';
import type { RecentJobRecord } from '../types/inspection';
import { clearRecentJobs } from '../services/storage';

interface Props {
  recentJobs: RecentJobRecord[];
  currentJobId?: string | null;
  onSelectJob: (jobId: string) => void;
  onJobsCleared: () => void;
}

export const RecentInspections: React.FC<Props> = ({
  recentJobs,
  currentJobId,
  onSelectJob,
  onJobsCleared,
}) => {
  const [manualIdInput, setManualIdInput] = useState('');
  const [isOpen, setIsOpen] = useState(false);

  const handleManualLookup = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = manualIdInput.trim();
    if (trimmed) {
      onSelectJob(trimmed);
      setManualIdInput('');
      setIsOpen(false);
    }
  };

  const handleClear = () => {
    clearRecentJobs();
    onJobsCleared();
  };

  return (
    <div style={{ position: 'relative' }}>
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className="nav-tab-btn"
        title="View recent inspection sessions or look up a Job ID"
        style={{ padding: '0.45rem 0.85rem' }}
      >
        <History size={15} />
        <span>Recent Inspections</span>
        {recentJobs.length > 0 && (
          <span className="nav-tab-badge">{recentJobs.length}</span>
        )}
      </button>

      {isOpen && (
        <div
          style={{
            position: 'absolute',
            top: 'calc(100% + 8px)',
            right: 0,
            width: '360px',
            maxWidth: '90vw',
            background: 'var(--bg-card)',
            border: '1px solid var(--border-card)',
            borderRadius: 'var(--radius-lg)',
            boxShadow: 'var(--shadow-lg)',
            zIndex: 100,
            padding: '1.25rem',
            display: 'flex',
            flexDirection: 'column',
            gap: '1rem',
            animation: 'fadeIn 150ms ease',
          }}
        >
          {/* Header */}
          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              borderBottom: '1px solid var(--border-subtle)',
              paddingBottom: '0.75rem',
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', fontWeight: 700 }}>
              <History size={16} color="var(--accent-cyan)" />
              <span>Inspection History</span>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
              {recentJobs.length > 0 && (
                <button
                  type="button"
                  onClick={handleClear}
                  title="Clear history"
                  style={{
                    color: 'var(--text-muted)',
                    padding: '4px',
                    borderRadius: '4px',
                  }}
                >
                  <Trash2 size={14} />
                </button>
              )}
              <button
                type="button"
                onClick={() => setIsOpen(false)}
                style={{
                  color: 'var(--text-muted)',
                  padding: '4px',
                  borderRadius: '4px',
                }}
              >
                <X size={16} />
              </button>
            </div>
          </div>

          {/* Manual Job ID Lookup */}
          <form onSubmit={handleManualLookup} style={{ display: 'flex', gap: '0.5rem' }}>
            <div style={{ position: 'relative', flex: 1 }}>
              <input
                type="text"
                placeholder="Lookup Job ID (UUID)..."
                value={manualIdInput}
                onChange={(e) => setManualIdInput(e.target.value)}
                style={{
                  width: '100%',
                  background: 'var(--bg-input)',
                  border: '1px solid var(--border-subtle)',
                  borderRadius: 'var(--radius-sm)',
                  padding: '0.45rem 0.65rem 0.45rem 2rem',
                  fontSize: '0.78rem',
                  color: '#ffffff',
                  fontFamily: 'var(--font-mono)',
                  outline: 'none',
                }}
              />
              <Search
                size={14}
                style={{
                  position: 'absolute',
                  left: '0.65rem',
                  top: '50%',
                  transform: 'translateY(-50%)',
                  color: 'var(--text-dim)',
                }}
              />
            </div>
            <button type="submit" className="btn btn-outline-cyan btn-sm" disabled={!manualIdInput.trim()}>
              View
            </button>
          </form>

          {/* List of Recent Jobs */}
          <div
            style={{
              maxHeight: '260px',
              overflowY: 'auto',
              display: 'flex',
              flexDirection: 'column',
              gap: '0.5rem',
            }}
          >
            {recentJobs.length > 0 ? (
              recentJobs.map((item) => {
                const isSelected = item.job_id === currentJobId;

                return (
                  <div
                    key={item.job_id}
                    onClick={() => {
                      onSelectJob(item.job_id);
                      setIsOpen(false);
                    }}
                    style={{
                      background: isSelected
                        ? 'rgba(6, 182, 212, 0.15)'
                        : 'rgba(10, 16, 29, 0.6)',
                      border: isSelected
                        ? '1px solid var(--accent-cyan)'
                        : '1px solid var(--border-subtle)',
                      borderRadius: 'var(--radius-sm)',
                      padding: '0.6rem 0.8rem',
                      cursor: 'pointer',
                      display: 'flex',
                      flexDirection: 'column',
                      gap: '0.25rem',
                      transition: 'background var(--transition-fast)',
                    }}
                  >
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                      <span
                        style={{
                          fontWeight: 600,
                          fontSize: '0.82rem',
                          color: '#ffffff',
                          maxWidth: '200px',
                          overflow: 'hidden',
                          textOverflow: 'ellipsis',
                          whiteSpace: 'nowrap',
                        }}
                      >
                        {item.filename}
                      </span>
                      <span
                        className={`badge ${
                          item.status === 'completed'
                            ? 'badge-success'
                            : item.status === 'processing'
                            ? 'badge-cyan'
                            : 'badge-defect'
                        }`}
                        style={{ fontSize: '0.65rem', padding: '0.1rem 0.35rem' }}
                      >
                        {item.status}
                      </span>
                    </div>

                    <div
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'space-between',
                        fontSize: '0.72rem',
                        color: 'var(--text-dim)',
                        fontFamily: 'var(--font-mono)',
                      }}
                    >
                      <span>{item.job_id.slice(0, 14)}...</span>
                      {item.events_count !== undefined && (
                        <span>{item.events_count} defects</span>
                      )}
                    </div>
                  </div>
                );
              })
            ) : (
              <div
                style={{
                  textAlign: 'center',
                  padding: '1.5rem',
                  fontSize: '0.78rem',
                  color: 'var(--text-muted)',
                }}
              >
                No inspections run in this browser session yet.
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

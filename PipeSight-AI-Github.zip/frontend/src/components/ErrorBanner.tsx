import React from 'react';
import { AlertCircle, RefreshCw, X } from 'lucide-react';

interface Props {
  title?: string;
  message: string;
  onRetry?: () => void;
  onDismiss?: () => void;
}

export const ErrorBanner: React.FC<Props> = ({
  title = 'Inspection Error',
  message,
  onRetry,
  onDismiss,
}) => {
  return (
    <div
      style={{
        background: 'rgba(239, 68, 68, 0.12)',
        border: '1px solid rgba(239, 68, 68, 0.35)',
        borderRadius: 'var(--radius-md)',
        padding: '1rem 1.25rem',
        display: 'flex',
        alignItems: 'flex-start',
        justifyContent: 'space-between',
        gap: '1rem',
        marginBottom: '1.25rem',
        boxShadow: '0 4px 16px rgba(239, 68, 68, 0.1)',
      }}
      role="alert"
    >
      <div style={{ display: 'flex', alignItems: 'flex-start', gap: '0.75rem' }}>
        <AlertCircle size={20} color="#f87171" style={{ flexShrink: 0, marginTop: '2px' }} />
        <div>
          <div style={{ fontWeight: 700, fontSize: '0.9rem', color: '#fef2f2', marginBottom: '0.2rem' }}>
            {title}
          </div>
          <div style={{ fontSize: '0.82rem', color: '#fca5a5', lineHeight: 1.45 }}>
            {message}
          </div>
        </div>
      </div>

      <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', flexShrink: 0 }}>
        {onRetry && (
          <button onClick={onRetry} className="btn btn-secondary btn-sm" style={{ padding: '0.35rem 0.65rem' }}>
            <RefreshCw size={13} /> Retry
          </button>
        )}
        {onDismiss && (
          <button
            onClick={onDismiss}
            style={{
              color: 'var(--text-muted)',
              padding: '4px',
              borderRadius: '4px',
            }}
            title="Dismiss error"
          >
            <X size={16} />
          </button>
        )}
      </div>
    </div>
  );
};

import {
  Camera,
  Cpu,
  FileText,
  Layers,
  Network,
  ShieldAlert,
  Sparkles,
} from 'lucide-react';
import type { HealthResponse, SystemInfoResponse } from '../types/inspection';
import { ModelLimitationsNotice } from './ModelLimitationsNotice';

interface Props {
  health?: HealthResponse | null;
  systemInfo?: SystemInfoResponse | null;
}

export const AboutView: React.FC<Props> = ({ health, systemInfo }) => {
  return (
    <div style={{ maxWidth: '1000px', margin: '0 auto', display: 'flex', flexDirection: 'column', gap: '1.75rem' }}>
      {/* Title Hero */}
      <div className="glass-card" style={{ padding: '2rem', textAlign: 'center' }}>
        <span className="prototype-tag" style={{ marginBottom: '0.75rem', display: 'inline-block' }}>
          Technical Whitepaper & Architecture
        </span>
        <h2 style={{ fontSize: '1.85rem', marginBottom: '0.75rem', fontWeight: 800 }}>
          PipeSight AI — Agentic Sewer Inspection
        </h2>
        <p style={{ maxWidth: '680px', margin: '0 auto', fontSize: '0.95rem', color: 'var(--text-secondary)' }}>
          An automated plumbing and sewer infrastructure diagnostics system using OpenCV 5, a trained
          YOLO26s checkpoint, and ByteTrack. Driven by an agentic perception-decision-action loop for real-time
          adaptive luminance enhancement and human review workflows.
        </p>
      </div>

      {/* Model Limitations Notice */}
      <ModelLimitationsNotice metricMap50={systemInfo?.model_metric_map50 || '42.6%'} />

      {/* Architecture Pipeline Pillars */}
      <div className="glass-card">
        <div className="card-header">
          <div className="card-title-group">
            <Network size={20} color="var(--accent-cyan)" />
            <div>
              <div className="card-title">Inspection Pipeline Architecture</div>
              <div className="card-subtitle">
                Deterministic 5-stage agentic perception loop coordinating computer vision primitives
              </div>
            </div>
          </div>
        </div>

        <div className="card-body">
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))',
              gap: '1.25rem',
            }}
          >
            {/* Pillar 1 */}
            <div
              style={{
                background: 'rgba(10, 16, 29, 0.7)',
                border: '1px solid var(--border-card)',
                borderRadius: 'var(--radius-md)',
                padding: '1.25rem',
                display: 'flex',
                flexDirection: 'column',
                gap: '0.65rem',
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', color: 'var(--accent-cyan-light)' }}>
                <Camera size={18} />
                <span style={{ fontWeight: 700, fontSize: '0.95rem' }}>1. OpenCV 5 Video Ingestion</span>
              </div>
              <p style={{ fontSize: '0.82rem', color: 'var(--text-secondary)', lineHeight: 1.45 }}>
                Rigorous codec and container validation. Streams frames sequentially, computing Laplacian variance
                for blur quantification and luminance histograms for lighting level classification.
              </p>
            </div>

            {/* Pillar 2 */}
            <div
              style={{
                background: 'rgba(10, 16, 29, 0.7)',
                border: '1px solid var(--border-card)',
                borderRadius: 'var(--radius-md)',
                padding: '1.25rem',
                display: 'flex',
                flexDirection: 'column',
                gap: '0.65rem',
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', color: '#fbbf24' }}>
                <Sparkles size={18} />
                <span style={{ fontWeight: 700, fontSize: '0.95rem' }}>2. Agentic Quality Assessment</span>
              </div>
              <p style={{ fontSize: '0.82rem', color: 'var(--text-secondary)', lineHeight: 1.45 }}>
                When sub-threshold illumination is detected (&lt;40 brightness mean), the agent dynamically selects
                CLAHE (Contrast Limited Adaptive Histogram Equalization) on the luminance channel with bilateral
                filtering, re-checking candidate detections.
              </p>
            </div>

            {/* Pillar 3 */}
            <div
              style={{
                background: 'rgba(10, 16, 29, 0.7)',
                border: '1px solid var(--border-card)',
                borderRadius: 'var(--radius-md)',
                padding: '1.25rem',
                display: 'flex',
                flexDirection: 'column',
                gap: '0.65rem',
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', color: '#60a5fa' }}>
                <Layers size={18} />
                <span style={{ fontWeight: 700, fontSize: '0.95rem' }}>3. YOLO26s Defect Detection</span>
              </div>
              <p style={{ fontSize: '0.82rem', color: 'var(--text-secondary)', lineHeight: 1.45 }}>
                Infers candidate defect locations for longitudinal cracks, circumferential cracks, joint offsets,
                root intrusions, and structural wall deformities using the pre-trained PyTorch checkpoint.
              </p>
            </div>

            {/* Pillar 4 */}
            <div
              style={{
                background: 'rgba(10, 16, 29, 0.7)',
                border: '1px solid var(--border-card)',
                borderRadius: 'var(--radius-md)',
                padding: '1.25rem',
                display: 'flex',
                flexDirection: 'column',
                gap: '0.65rem',
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', color: '#a78bfa' }}>
                <Cpu size={18} />
                <span style={{ fontWeight: 700, fontSize: '0.95rem' }}>4. ByteTrack Deduplication</span>
              </div>
              <p style={{ fontSize: '0.82rem', color: 'var(--text-secondary)', lineHeight: 1.45 }}>
                Persistent multi-object tracking links observations across contiguous frames. Kalman filtering
                prevents duplicate defect counting as the CCTV camera crawler progresses down the sewer main.
              </p>
            </div>

            {/* Pillar 5 */}
            <div
              style={{
                background: 'rgba(10, 16, 29, 0.7)',
                border: '1px solid var(--border-card)',
                borderRadius: 'var(--radius-md)',
                padding: '1.25rem',
                display: 'flex',
                flexDirection: 'column',
                gap: '0.65rem',
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', color: '#34d399' }}>
                <ShieldAlert size={18} />
                <span style={{ fontWeight: 700, fontSize: '0.95rem' }}>5. Human Review Escalation</span>
              </div>
              <p style={{ fontSize: '0.82rem', color: 'var(--text-secondary)', lineHeight: 1.45 }}>
                Detections falling within the ambiguous confidence band (25% to 42%) or showing temporal variance
                are tagged with <strong style={{ color: '#fbbf24' }}>Human Review Required</strong>, ensuring safety
                and preventing automated false alarms.
              </p>
            </div>

            {/* Pillar 6 */}
            <div
              style={{
                background: 'rgba(10, 16, 29, 0.7)',
                border: '1px solid var(--border-card)',
                borderRadius: 'var(--radius-md)',
                padding: '1.25rem',
                display: 'flex',
                flexDirection: 'column',
                gap: '0.65rem',
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', color: '#f472b6' }}>
                <FileText size={18} />
                <span style={{ fontWeight: 700, fontSize: '0.95rem' }}>6. Formal Report Synthesis</span>
              </div>
              <p style={{ fontSize: '0.82rem', color: 'var(--text-secondary)', lineHeight: 1.45 }}>
                Automated ReportLab PDF document compilation and structured JSON generation, attaching peak confidence
                evidence images and time-coded audit trails for engineering records.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* System Specifications & Model Identity */}
      <div className="glass-card">
        <div className="card-header">
          <div className="card-title-group">
            <Cpu size={20} color="var(--accent-cyan)" />
            <div>
              <div className="card-title">Live Backend System Specifications</div>
              <div className="card-subtitle">Reported dynamically by the active FastAPI service</div>
            </div>
          </div>
        </div>

        <div className="card-body" style={{ padding: '0' }}>
          <div className="table-responsive">
            <table className="data-table">
              <tbody>
                <tr>
                  <th style={{ width: '30%' }}>OpenCV Runtime</th>
                  <td style={{ fontFamily: 'var(--font-mono)' }}>
                    {health?.opencv_version || 'Loading...'}
                  </td>
                </tr>
                <tr>
                  <th>PyTorch & Compute Device</th>
                  <td style={{ fontFamily: 'var(--font-mono)' }}>
                    PyTorch {health?.torch_version || '—'} on {health?.device || 'cpu'}
                  </td>
                </tr>
                <tr>
                  <th>Ultralytics Framework</th>
                  <td style={{ fontFamily: 'var(--font-mono)' }}>
                    v{health?.ultralytics_version || '—'}
                  </td>
                </tr>
                <tr>
                  <th>Model Architecture</th>
                  <td style={{ fontFamily: 'var(--font-mono)' }}>
                    {systemInfo?.model_name || 'YOLO26s Sewer Defect Detector'}
                  </td>
                </tr>
                <tr>
                  <th>CPU Optimization & Stride</th>
                  <td style={{ fontFamily: 'var(--font-mono)' }}>
                    Max {systemInfo?.max_processing_dim || 640}px bounding box &bull; Stride: {systemInfo?.frame_stride || 3} ({systemInfo?.cpu_threads || 4} PyTorch CPU threads)
                  </td>
                </tr>
                <tr>
                  <th>Class Vocabulary Count</th>
                  <td>{health?.classes_count ? `${health.classes_count} defect classes` : '—'}</td>
                </tr>
                <tr>
                  <th>Held-out Benchmark Metric</th>
                  <td>
                    <span className="badge badge-warning">
                      ~{systemInfo?.model_metric_map50 || '42.6%'} mAP@50
                    </span>
                  </td>
                </tr>
                <tr>
                  <th>Storage Backend</th>
                  <td style={{ fontFamily: 'var(--font-mono)' }}>
                    {systemInfo?.storage_backend || 'local'} filesystem storage
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

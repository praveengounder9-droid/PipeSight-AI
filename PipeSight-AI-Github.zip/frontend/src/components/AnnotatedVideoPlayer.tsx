import { useState, useRef, useEffect } from 'react';
import {
  Download,
  Film,
  Maximize,
  Pause,
  Play,
  RotateCcw,
  Volume2,
  VolumeX,
} from 'lucide-react';
import { resolveBackendUrl, getAnnotatedVideoUrl } from '../services/api';

interface Props {
  jobId: string;
  videoUrl?: string | null;
  seekTime?: number | null;
  onTimeUpdate?: (currentTime: number) => void;
}

export const AnnotatedVideoPlayer: React.FC<Props> = ({
  jobId,
  videoUrl,
  seekTime,
  onTimeUpdate,
}) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [playbackRate, setPlaybackRate] = useState(1);
  const [isMuted, setIsMuted] = useState(true);
  const [hasError, setHasError] = useState(false);

  // Resolved URL for annotated video
  const directUrl = videoUrl
    ? resolveBackendUrl(videoUrl)
    : getAnnotatedVideoUrl(jobId);

  // Handle external seek triggers from DefectTable or TraceTimeline
  useEffect(() => {
    if (seekTime !== null && seekTime !== undefined && videoRef.current) {
      videoRef.current.currentTime = seekTime;
      setCurrentTime(seekTime);
      if (!isPlaying) {
        videoRef.current.play().then(() => setIsPlaying(true)).catch(() => {});
      }
    }
  }, [seekTime]);

  const togglePlay = () => {
    if (!videoRef.current) return;
    if (videoRef.current.paused) {
      videoRef.current.play().then(() => setIsPlaying(true)).catch(() => {});
    } else {
      videoRef.current.pause();
      setIsPlaying(false);
    }
  };

  const handleTimeUpdate = () => {
    if (!videoRef.current) return;
    const time = videoRef.current.currentTime;
    setCurrentTime(time);
    onTimeUpdate?.(time);
  };

  const handleLoadedMetadata = () => {
    if (!videoRef.current) return;
    setDuration(videoRef.current.duration);
    setHasError(false);
  };

  const handleScrubberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    if (videoRef.current) {
      videoRef.current.currentTime = val;
      setCurrentTime(val);
    }
  };

  const changePlaybackRate = (rate: number) => {
    setPlaybackRate(rate);
    if (videoRef.current) {
      videoRef.current.playbackRate = rate;
    }
  };

  const toggleFullscreen = () => {
    if (!videoRef.current) return;
    if (videoRef.current.requestFullscreen) {
      videoRef.current.requestFullscreen();
    }
  };

  const formatSec = (sec: number) => {
    if (isNaN(sec)) return '0:00';
    const mins = Math.floor(sec / 60);
    const s = Math.floor(sec % 60);
    return `${mins}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <div className="glass-card">
      <div className="card-header">
        <div className="card-title-group">
          <Film size={18} color="var(--accent-cyan)" />
          <div>
            <div className="card-title">Annotated Inspection Stream</div>
            <div className="card-subtitle">
              OpenCV 5 rendered video overlay with ByteTrack bounding boxes & quality metrics HUD
            </div>
          </div>
        </div>

        <a
          href={directUrl}
          download={`PipeSight_annotated_${jobId}.mp4`}
          className="btn btn-secondary btn-sm"
          title="Download the annotated MP4 file to local storage"
        >
          <Download size={14} /> Download MP4
        </a>
      </div>

      <div className="card-body" style={{ padding: '0', background: '#000' }}>
        <div className="video-player-container">
          <video
            ref={videoRef}
            src={directUrl}
            className="video-player-element"
            playsInline
            muted={isMuted}
            onTimeUpdate={handleTimeUpdate}
            onLoadedMetadata={handleLoadedMetadata}
            onPlay={() => setIsPlaying(true)}
            onPause={() => setIsPlaying(false)}
            onError={() => setHasError(true)}
            onClick={togglePlay}
          />

          {hasError && (
            <div
              style={{
                padding: '2rem',
                textAlign: 'center',
                color: '#fca5a5',
                background: 'rgba(15, 23, 42, 0.95)',
              }}
            >
              <p style={{ fontWeight: 600, marginBottom: '0.5rem' }}>
                Annotated video preview unavailable or codec not supported in this browser.
              </p>
              <p style={{ fontSize: '0.8rem', color: 'var(--text-muted)', marginBottom: '1rem' }}>
                OpenCV 5 wrote the video stream directly. You can download and inspect it locally:
              </p>
              <a href={directUrl} download className="btn btn-primary btn-sm">
                <Download size={14} /> Download {jobId}_annotated.mp4
              </a>
            </div>
          )}

          {/* Custom Video Control Bar */}
          {!hasError && (
            <div
              style={{
                background: 'linear-gradient(180deg, transparent 0%, rgba(7, 10, 18, 0.95) 100%)',
                padding: '1rem',
                display: 'flex',
                flexDirection: 'column',
                gap: '0.65rem',
              }}
            >
              {/* Scrubber slider */}
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.75rem', color: '#ffffff' }}>
                  {formatSec(currentTime)}
                </span>
                <input
                  type="range"
                  min={0}
                  max={duration || 100}
                  step={0.05}
                  value={currentTime}
                  onChange={handleScrubberChange}
                  style={{
                    flex: 1,
                    accentColor: 'var(--accent-cyan)',
                    cursor: 'pointer',
                    height: '5px',
                  }}
                  aria-label="Video Seek Scrubber"
                />
                <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                  {formatSec(duration)}
                </span>
              </div>

              {/* Action buttons row */}
              <div
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  flexWrap: 'wrap',
                  gap: '0.75rem',
                }}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                  <button
                    type="button"
                    onClick={togglePlay}
                    className="btn btn-primary btn-sm"
                    aria-label={isPlaying ? 'Pause' : 'Play'}
                    style={{ padding: '0.4rem 0.8rem' }}
                  >
                    {isPlaying ? <Pause size={14} /> : <Play size={14} fill="currentColor" />}
                    <span>{isPlaying ? 'Pause' : 'Play'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      if (videoRef.current) {
                        videoRef.current.currentTime = 0;
                        setCurrentTime(0);
                      }
                    }}
                    className="btn btn-secondary btn-sm"
                    title="Rewind to start"
                    style={{ padding: '0.4rem 0.6rem' }}
                  >
                    <RotateCcw size={14} />
                  </button>

                  {/* Playback speed chips */}
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.25rem', marginLeft: '0.5rem' }}>
                    <span style={{ fontSize: '0.72rem', color: 'var(--text-muted)', marginRight: '0.2rem' }}>
                      Speed:
                    </span>
                    {[0.5, 1, 1.5, 2].map((rate) => (
                      <button
                        key={rate}
                        type="button"
                        onClick={() => changePlaybackRate(rate)}
                        style={{
                          fontFamily: 'var(--font-mono)',
                          fontSize: '0.7rem',
                          padding: '0.15rem 0.45rem',
                          borderRadius: '4px',
                          background:
                            playbackRate === rate ? 'rgba(6, 182, 212, 0.3)' : 'rgba(255, 255, 255, 0.08)',
                          color: playbackRate === rate ? 'var(--accent-cyan-light)' : 'var(--text-secondary)',
                          border:
                            playbackRate === rate
                              ? '1px solid var(--accent-cyan)'
                              : '1px solid var(--border-subtle)',
                        }}
                      >
                        {rate}x
                      </button>
                    ))}
                  </div>
                </div>

                <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                  <button
                    type="button"
                    onClick={() => setIsMuted(!isMuted)}
                    className="btn btn-secondary btn-sm"
                    title={isMuted ? 'Unmute' : 'Mute'}
                    style={{ padding: '0.4rem 0.6rem' }}
                  >
                    {isMuted ? <VolumeX size={14} /> : <Volume2 size={14} />}
                  </button>

                  <button
                    type="button"
                    onClick={toggleFullscreen}
                    className="btn btn-secondary btn-sm"
                    title="Fullscreen"
                    style={{ padding: '0.4rem 0.6rem' }}
                  >
                    <Maximize size={14} />
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

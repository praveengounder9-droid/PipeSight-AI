import {
  Activity,
  BookOpen,
  PlusCircle,
} from 'lucide-react';
import { BackendStatus } from './BackendStatus';
import { RecentInspections } from './RecentInspections';
import type { HealthResponse, RecentJobRecord } from '../types/inspection';

export type ActiveTab = 'new-inspection' | 'results' | 'about';

interface Props {
  activeTab: ActiveTab;
  onTabChange: (tab: ActiveTab) => void;
  recentJobs: RecentJobRecord[];
  currentJobId?: string | null;
  onSelectJob: (jobId: string) => void;
  onJobsCleared: () => void;
  onHealthLoaded?: (health: HealthResponse | null) => void;
  hasActiveReport?: boolean;
  children: React.ReactNode;
}

export const AppShell: React.FC<Props> = ({
  activeTab,
  onTabChange,
  recentJobs,
  currentJobId,
  onSelectJob,
  onJobsCleared,
  onHealthLoaded,
  hasActiveReport = false,
  children,
}) => {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', minHeight: '100vh' }}>
      {/* Top Header */}
      <header className="app-header">
        <div className="app-container">
          <div className="header-content">
            {/* Brand Logo & Title */}
            <div
              className="brand-wrapper"
              onClick={() => onTabChange('new-inspection')}
              role="button"
              tabIndex={0}
              onKeyDown={(e) => {
                if (e.key === 'Enter') onTabChange('new-inspection');
              }}
              aria-label="PipeSight AI Home"
            >
              <div className="brand-logo-glow">
                <img src="/logo.svg" alt="PipeSight AI Logo" className="brand-logo-img" />
              </div>
              <div className="brand-text-col">
                <div className="brand-title-row">
                  <span className="brand-title">PipeSight AI</span>
                  <span className="prototype-tag">PROTOTYPE</span>
                </div>
                <span className="brand-tagline">
                  Agentic Sewer Inspection & Diagnostic Platform
                </span>
              </div>
            </div>

            {/* Navigation Tabs */}
            <nav className="nav-tabs" aria-label="Main Navigation">
              <button
                type="button"
                className={`nav-tab-btn ${activeTab === 'new-inspection' ? 'active' : ''}`}
                onClick={() => onTabChange('new-inspection')}
              >
                <PlusCircle size={16} />
                <span>New Inspection</span>
              </button>

              <button
                type="button"
                className={`nav-tab-btn ${activeTab === 'results' ? 'active' : ''}`}
                onClick={() => onTabChange('results')}
              >
                <Activity size={16} />
                <span>Inspection Results</span>
                {hasActiveReport && (
                  <span className="nav-tab-badge">Active</span>
                )}
              </button>

              <button
                type="button"
                className={`nav-tab-btn ${activeTab === 'about' ? 'active' : ''}`}
                onClick={() => onTabChange('about')}
              >
                <BookOpen size={16} />
                <span>About & Specs</span>
              </button>
            </nav>

            {/* Right: History & Backend Health Status */}
            <div className="header-actions">
              <RecentInspections
                recentJobs={recentJobs}
                currentJobId={currentJobId}
                onSelectJob={onSelectJob}
                onJobsCleared={onJobsCleared}
              />

              <BackendStatus onHealthLoaded={onHealthLoaded} />
            </div>
          </div>
        </div>
      </header>

      {/* Main App Content Viewport */}
      <main style={{ flex: 1, padding: '1.75rem 0 3rem' }}>
        <div className="app-container">{children}</div>
      </main>

      {/* Footer */}
      <footer className="app-footer">
        <div className="app-container">
          <div className="footer-content">
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.35rem' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', fontWeight: 700, color: '#ffffff' }}>
                <img src="/logo.svg" alt="" width={18} height={18} />
                <span>PipeSight AI — Engineering Prototype</span>
              </div>
              <p style={{ maxWidth: '650px', fontSize: '0.78rem', color: 'var(--text-dim)' }}>
                Powered by OpenCV 5, YOLO26s, and ByteTrack. Predictions represent model-assisted advisory detections
                achieving ~42.6% mAP@50 on held-out test data. Certified human engineer verification required.
              </p>
            </div>

            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '1rem',
                fontSize: '0.78rem',
                color: 'var(--text-dim)',
              }}
            >
              <span>Deterministic Vision Loop</span>
              <span>•</span>
              <span>OpenCV 5 Decoders</span>
              <span>•</span>
              <span>FastAPI Backend</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

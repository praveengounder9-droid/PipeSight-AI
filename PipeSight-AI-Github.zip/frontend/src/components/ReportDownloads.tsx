import { useState } from 'react';
import {
  Archive,
  Clock,
  Download,
  FileCode,
  FileDown,
  FileText,
  Film,
  Loader2,
} from 'lucide-react';
import {
  getPdfReportUrl,
  getJsonReportUrl,
  getAnnotatedVideoUrl,
  getZipReportUrl,
  getInspectionReport,
} from '../services/api';

interface Props {
  jobId: string;
}

export const ReportDownloads: React.FC<Props> = ({ jobId }) => {
  const [downloadingJson, setDownloadingJson] = useState(false);

  const pdfUrl = getPdfReportUrl(jobId);
  const videoUrl = getAnnotatedVideoUrl(jobId);
  const zipUrl = getZipReportUrl(jobId);

  const handleDownloadJson = async () => {
    setDownloadingJson(true);
    try {
      const data = await getInspectionReport(jobId);
      const jsonStr = JSON.stringify(data, null, 2);
      const blob = new Blob([jsonStr], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `PipeSight_Report_${jobId}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error('Failed to download JSON report:', err);
      // Fallback: direct window open to backend endpoint
      window.open(getJsonReportUrl(jobId), '_blank');
    } finally {
      setDownloadingJson(false);
    }
  };

  return (
    <div className="glass-card">
      <div className="card-header">
        <div className="card-title-group">
          <FileDown size={18} color="var(--accent-cyan)" />
          <div>
            <div className="card-title">Inspection Artifacts & Exports</div>
            <div className="card-subtitle">
              Download formal engineering reports, structured JSON data, annotated video, and complete ZIP package
            </div>
          </div>
        </div>
      </div>

      <div className="card-body">
        {/* Temporary Storage Retention Notice */}
        <div
          style={{
            background: 'rgba(234, 179, 8, 0.08)',
            border: '1px solid rgba(234, 179, 8, 0.25)',
            borderRadius: 'var(--radius-sm)',
            padding: '0.75rem 1rem',
            marginBottom: '1.25rem',
            display: 'flex',
            alignItems: 'center',
            gap: '0.75rem',
          }}
        >
          <Clock size={18} style={{ color: '#eab308', flexShrink: 0 }} />
          <div style={{ fontSize: '0.8rem', color: '#fef08a', lineHeight: 1.4 }}>
            <strong>Temporary Storage Notice:</strong> Inspection results and generated media are temporarily retained on local EC2 storage for <strong>24 hours</strong>. Please download your reports and evidence archives before scheduled cleanup.
          </div>
        </div>

        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))',
            gap: '1rem',
          }}
        >
          {/* Complete ZIP Package */}
          <div
            style={{
              background: 'rgba(10, 16, 29, 0.75)',
              border: '1px solid rgba(16, 185, 129, 0.3)',
              borderRadius: 'var(--radius-md)',
              padding: '1.25rem',
              display: 'flex',
              flexDirection: 'column',
              justifyContent: 'space-between',
              gap: '1rem',
            }}
          >
            <div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem', marginBottom: '0.4rem' }}>
                <div
                  style={{
                    width: '36px',
                    height: '36px',
                    borderRadius: 'var(--radius-sm)',
                    background: 'rgba(16, 185, 129, 0.15)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    color: '#34d399',
                  }}
                >
                  <Archive size={18} />
                </div>
                <div>
                  <div style={{ fontWeight: 700, fontSize: '0.95rem', color: '#f8fafc' }}>
                    Full Package (ZIP)
                  </div>
                  <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>
                    All artifacts bundled
                  </div>
                </div>
              </div>
              <p style={{ fontSize: '0.78rem', color: 'var(--text-secondary)', lineHeight: 1.4 }}>
                Complete archive containing annotated MP4, PDF report, JSON telemetry, agent trace, and all evidence crops.
              </p>
            </div>

            <a
              href={zipUrl}
              download={`PipeSight_Results_${jobId}.zip`}
              className="btn btn-primary btn-sm"
              style={{ width: '100%', background: 'linear-gradient(135deg, #059669 0%, #10b981 100%)' }}
            >
              <Download size={14} /> Download All (ZIP)
            </a>
          </div>

          {/* PDF Report */}
          <div
            style={{
              background: 'rgba(10, 16, 29, 0.75)',
              border: '1px solid var(--border-card)',
              borderRadius: 'var(--radius-md)',
              padding: '1.25rem',
              display: 'flex',
              flexDirection: 'column',
              justifyContent: 'space-between',
              gap: '1rem',
            }}
          >
            <div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem', marginBottom: '0.4rem' }}>
                <div
                  style={{
                    width: '36px',
                    height: '36px',
                    borderRadius: 'var(--radius-sm)',
                    background: 'rgba(239, 68, 68, 0.15)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    color: '#f87171',
                  }}
                >
                  <FileText size={18} />
                </div>
                <div>
                  <div style={{ fontWeight: 700, fontSize: '0.95rem', color: '#f8fafc' }}>
                    PDF Diagnostic Report
                  </div>
                  <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>
                    ReportLab document
                  </div>
                </div>
              </div>
              <p style={{ fontSize: '0.78rem', color: 'var(--text-secondary)', lineHeight: 1.4 }}>
                Formal summary with telemetry headers, defect tables, evidence crops, and engineering disclaimers.
              </p>
            </div>

            <a
              href={pdfUrl}
              target="_blank"
              rel="noopener noreferrer"
              download={`PipeSight_Report_${jobId}.pdf`}
              className="btn btn-secondary btn-sm"
              style={{ width: '100%' }}
            >
              <Download size={14} /> Download PDF Report
            </a>
          </div>

          {/* JSON Report */}
          <div
            style={{
              background: 'rgba(10, 16, 29, 0.75)',
              border: '1px solid var(--border-card)',
              borderRadius: 'var(--radius-md)',
              padding: '1.25rem',
              display: 'flex',
              flexDirection: 'column',
              justifyContent: 'space-between',
              gap: '1rem',
            }}
          >
            <div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem', marginBottom: '0.4rem' }}>
                <div
                  style={{
                    width: '36px',
                    height: '36px',
                    borderRadius: 'var(--radius-sm)',
                    background: 'rgba(6, 182, 212, 0.15)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    color: 'var(--accent-cyan-light)',
                  }}
                >
                  <FileCode size={18} />
                </div>
                <div>
                  <div style={{ fontWeight: 700, fontSize: '0.95rem', color: '#f8fafc' }}>
                    JSON Inspection Data
                  </div>
                  <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>
                    Structured REST payload
                  </div>
                </div>
              </div>
              <p style={{ fontSize: '0.78rem', color: 'var(--text-secondary)', lineHeight: 1.4 }}>
                Raw telemetry, bounding box coordinates, ByteTrack timestamps, and Agentic Vision action traces.
              </p>
            </div>

            <button
              type="button"
              onClick={handleDownloadJson}
              disabled={downloadingJson}
              className="btn btn-outline-cyan btn-sm"
              style={{ width: '100%' }}
            >
              {downloadingJson ? (
                <>
                  <Loader2 size={14} className="spin" /> Fetching JSON...
                </>
              ) : (
                <>
                  <Download size={14} /> Download JSON Report
                </>
              )}
            </button>
          </div>

          {/* Annotated Video */}
          <div
            style={{
              background: 'rgba(10, 16, 29, 0.75)',
              border: '1px solid var(--border-card)',
              borderRadius: 'var(--radius-md)',
              padding: '1.25rem',
              display: 'flex',
              flexDirection: 'column',
              justifyContent: 'space-between',
              gap: '1rem',
            }}
          >
            <div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem', marginBottom: '0.4rem' }}>
                <div
                  style={{
                    width: '36px',
                    height: '36px',
                    borderRadius: 'var(--radius-sm)',
                    background: 'rgba(59, 130, 246, 0.15)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    color: '#60a5fa',
                  }}
                >
                  <Film size={18} />
                </div>
                <div>
                  <div style={{ fontWeight: 700, fontSize: '0.95rem', color: '#f8fafc' }}>
                    Annotated Video MP4
                  </div>
                  <div style={{ fontSize: '0.72rem', color: 'var(--text-muted)' }}>
                    OpenCV 5 rendered stream
                  </div>
                </div>
              </div>
              <p style={{ fontSize: '0.78rem', color: 'var(--text-secondary)', lineHeight: 1.4 }}>
                Full-length video with rendered HUD, defect boxes, tracking labels, and luminance analysis.
              </p>
            </div>

            <a
              href={videoUrl}
              download={`PipeSight_annotated_${jobId}.mp4`}
              className="btn btn-secondary btn-sm"
              style={{ width: '100%' }}
            >
              <Download size={14} /> Download Annotated MP4
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

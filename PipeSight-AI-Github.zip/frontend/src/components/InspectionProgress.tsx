import { useState, useEffect, useCallback, useRef } from 'react';
import {
  Activity,
  AlertOctagon,
  CheckCircle2,
  Clock,
  Eye,
  Film,
  Info,
  Loader2,
  Sparkles,
} from 'lucide-react';
import { getJobStatus } from '../services/api';
import type { JobStatusResponse } from '../types/inspection';

interface Props {
  jobId: string;
  filename?: string;
  onJobCompleted: (jobId: string) => void;
  onReset: () => void;
  pollIntervalMs?: number;
}

export const InspectionProgress: React.FC<Props> = ({
  jobId,
  filename,
  onJobCompleted,
  onReset,
  pollIntervalMs = 1000,
}) => {
  const [statusData, setStatusData] = useState<JobStatusResponse | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [consecutiveFailures, setConsecutiveFailures] = useState(0);

  const hasNotifiedCompleted = useRef(false);

  const pollStatus = useCallback(async () => {
    try {
      const data = await getJobStatus(jobId);
      setStatusData(data);
      setError(null);
      setConsecutiveFailures(0);

      if (data.status === 'completed' && !hasNotifiedCompleted.current) {
        hasNotifiedCompleted.current = true;
        // Short delay to let the user see the 100% completion bar
        setTimeout(() => {
          onJobCompleted(jobId);
        }, 800);
      }
    } catch (err: unknown) {
      setConsecutiveFailures((prev: number) => prev + 1);
      const msg = err instanceof Error ? err.message : 'Failed to query job status';
      setError(msg);
    }
  }, [jobId, onJobCompleted]);

  useEffect(() => {
    pollStatus();
    const interval = setInterval(() => {
      // If completed or failed, stop polling
      if (statusData?.status === 'completed' || statusData?.status === 'failed') {
        clearInterval(interval);
        return;
      }
      pollStatus();
    }, pollIntervalMs);

    return () => clearInterval(interval);
  }, [pollStatus, pollIntervalMs, statusData?.status]);

  const progress = statusData ? Math.min(100, Math.max(0, statusData.progress_pct)) : 0;
  const isCompleted = statusData?.status === 'completed';
  const isFailed = statusData?.status === 'failed';
  const isProcessing = statusData?.status === 'processing';
  const isQueued = statusData?.status === 'queued';

  return (
    <div className="glass-card" style={{ maxWidth: '840px', margin: '0 auto' }}>
      <div className="card-header">
        <div className="card-title-group">
          <Activity size={20} color="var(--accent-cyan)" />
          <div>
            <div className="card-title">Agentic Inspection In Progress</div>
            <div
              style={{
                fontSize: '0.8rem',
                fontFamily: 'var(--font-mono)',
                color: 'var(--text-muted)',
              }}
            >
              Job ID: {jobId}
            </div>
          </div>
        </div>

        <div>
          {isCompleted && (
            <span className="badge badge-success">
              <CheckCircle2 size={13} /> Completed
            </span>
          )}
          {isProcessing && (
            <span className="badge badge-cyan">
              <Loader2 size={13} className="spin" /> Processing Frames
            </span>
          )}
          {isQueued && (
            <span className="badge badge-warning">
              <Clock size={13} /> Queued in Worker
            </span>
          )}
          {isFailed && (
            <span className="badge badge-defect">
              <AlertOctagon size={13} /> Failed
            </span>
          )}
        </div>
      </div>

      <div className="card-body" style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
        {/* Progress Bar Container */}
        <div>
          <div
            style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              marginBottom: '0.65rem',
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', fontWeight: 600 }}>
              <Film size={16} color="var(--accent-cyan-light)" />
              <span>{filename || 'Inspection Video Analysis'}</span>
            </div>
            <div
              style={{
                fontFamily: 'var(--font-mono)',
                fontSize: '1.25rem',
                fontWeight: 700,
                color: 'var(--accent-cyan-light)',
              }}
            >
              {progress.toFixed(1)}%
            </div>
          </div>

          <div className="progress-bar-track">
            <div className="progress-bar-fill" style={{ width: `${progress}%` }} />
          </div>
        </div>

        {/* Live Counters Grid */}
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))',
            gap: '1rem',
          }}
        >
          {/* Frames Counter */}
          <div
            style={{
              background: 'rgba(10, 16, 29, 0.7)',
              padding: '0.9rem',
              borderRadius: 'var(--radius-md)',
              border: '1px solid var(--border-subtle)',
            }}
          >
            <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginBottom: '0.25rem' }}>
              Frames Analyzed
            </div>
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: '1.2rem', fontWeight: 700 }}>
              {statusData ? statusData.current_frame : 0}{' '}
              <span style={{ fontSize: '0.85rem', color: 'var(--text-dim)', fontWeight: 400 }}>
                / {statusData && statusData.total_frames > 0 ? statusData.total_frames : '—'}
              </span>
            </div>
          </div>

          {/* Elapsed Time */}
          <div
            style={{
              background: 'rgba(10, 16, 29, 0.7)',
              padding: '0.9rem',
              borderRadius: 'var(--radius-md)',
              border: '1px solid var(--border-subtle)',
            }}
          >
            <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginBottom: '0.25rem' }}>
              Elapsed Execution
            </div>
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: '1.2rem', fontWeight: 700 }}>
              {statusData ? `${statusData.elapsed_sec.toFixed(1)}s` : '0.0s'}
            </div>
          </div>

          {/* Estimated Remaining */}
          <div
            style={{
              background: 'rgba(10, 16, 29, 0.7)',
              padding: '0.9rem',
              borderRadius: 'var(--radius-md)',
              border: '1px solid var(--border-subtle)',
            }}
          >
            <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginBottom: '0.25rem' }}>
              Estimated Remaining
            </div>
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: '1.2rem', fontWeight: 700 }}>
              {statusData?.estimated_time_remaining_sec !== null &&
              statusData?.estimated_time_remaining_sec !== undefined
                ? `${statusData.estimated_time_remaining_sec.toFixed(1)}s`
                : 'Estimating...'}
            </div>
          </div>
        </div>

        {/* Live Pipeline Stage Callout */}
        <div
          style={{
            background: 'linear-gradient(135deg, rgba(6, 182, 212, 0.08), rgba(99, 102, 241, 0.08))',
            border: '1px solid rgba(6, 182, 212, 0.25)',
            borderRadius: 'var(--radius-md)',
            padding: '1rem',
            display: 'flex',
            alignItems: 'flex-start',
            gap: '0.75rem',
          }}
        >
          <Sparkles size={18} color="var(--accent-cyan)" style={{ flexShrink: 0, marginTop: '2px' }} />
          <div style={{ fontSize: '0.82rem', lineHeight: 1.45 }}>
            <strong style={{ color: '#ffffff' }}>Active Pipeline Stage: </strong>
            <span style={{ color: 'var(--text-secondary)' }}>
              {isProcessing
                ? 'OpenCV 5 video decoding, Laplacian blur & illumination assessment, CLAHE luminance enhancement, YOLO26s inference, and ByteTrack spatial tracking.'
                : isQueued
                ? 'Worker thread initializing model checkpoint and validating video codec container...'
                : isCompleted
                ? 'Inspection complete! Aggregated unique defect events, annotated video rendered, and ReportLab PDF generated.'
                : 'Pipeline stopped.'}
            </span>
          </div>
        </div>

        {/* Failure State */}
        {isFailed && (
          <div
            style={{
              background: 'rgba(239, 68, 68, 0.12)',
              border: '1px solid rgba(239, 68, 68, 0.35)',
              borderRadius: 'var(--radius-md)',
              padding: '1rem',
              display: 'flex',
              flexDirection: 'column',
              gap: '0.5rem',
              color: '#fca5a5',
            }}
            role="alert"
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', fontWeight: 700 }}>
              <AlertOctagon size={18} /> Inspection Processing Failed
            </div>
            <div style={{ fontSize: '0.82rem', fontFamily: 'var(--font-mono)' }}>
              {statusData?.error_message || error || 'Unknown processing error'}
            </div>
            <div style={{ marginTop: '0.5rem' }}>
              <button onClick={onReset} className="btn btn-secondary btn-sm">
                Try Uploading Another Video
              </button>
            </div>
          </div>
        )}

        {/* Polling Error warning */}
        {error && consecutiveFailures > 2 && !isFailed && (
          <div
            style={{
              background: 'rgba(245, 158, 11, 0.12)',
              border: '1px solid rgba(245, 158, 11, 0.3)',
              borderRadius: 'var(--radius-md)',
              padding: '0.75rem 1rem',
              fontSize: '0.8rem',
              color: '#fcd34d',
            }}
          >
            Polling delay: {error}. Retrying automatically...
          </div>
        )}

        {/* Pipeline Control Information Note */}
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '0.5rem',
            fontSize: '0.75rem',
            color: 'var(--text-dim)',
            borderTop: '1px solid var(--border-subtle)',
            paddingTop: '0.85rem',
          }}
        >
          <Info size={14} />
          <span>
            <strong>Note on Cancellation:</strong> The backend pipeline does not support mid-flight task cancellation.
            The job will complete or terminate automatically.
          </span>
        </div>

        {/* Completion button if ready */}
        {isCompleted && (
          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '0.75rem' }}>
            <button
              onClick={() => onJobCompleted(jobId)}
              className="btn btn-primary"
            >
              <Eye size={16} /> View Inspection Report
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

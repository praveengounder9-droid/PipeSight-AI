import { useState } from 'react';
import {
  Activity,
  AlertTriangle,
  CheckCircle,
  Play,
  Sliders,
  Sparkles,
  Sun,
} from 'lucide-react';
import type { AgentDecisionsSummary } from '../types/inspection';

interface Props {
  decisionsSummary: AgentDecisionsSummary;
  onSeekVideo?: (seconds: number) => void;
}

export const AgentTraceTimeline: React.FC<Props> = ({
  decisionsSummary,
  onSeekVideo,
}) => {
  const [selectedFilter, setSelectedFilter] = useState<string>('ALL');

  const { total_actions, action_counts = {}, sample_traces = [] } = decisionsSummary;

  // Distinct decisions present in sample traces
  const distinctDecisions = Object.keys(action_counts);

  const filteredTraces = selectedFilter === 'ALL'
    ? sample_traces
    : sample_traces.filter((t) => t.decision === selectedFilter);

  const getDecisionBadge = (decision: string) => {
    switch (decision) {
      case 'ENHANCE_AND_RECHECK':
        return (
          <span className="badge badge-warning">
            <Sparkles size={11} /> ENHANCE & RECHECK
          </span>
        );
      case 'REQUEST_HUMAN_REVIEW':
        return (
          <span className="badge badge-defect">
            <AlertTriangle size={11} /> HUMAN REVIEW REQUESTED
          </span>
        );
      case 'INSPECT_ADJACENT_FRAMES':
        return (
          <span className="badge badge-purple">
            <Sliders size={11} /> INSPECT ADJACENT
          </span>
        );
      case 'CONTINUE':
        return (
          <span className="badge badge-success">
            <CheckCircle size={11} /> CONTINUE
          </span>
        );
      case 'LOG_AND_CONTINUE':
      default:
        return (
          <span className="badge badge-cyan">
            <Activity size={11} /> {decision.replace(/_/g, ' ')}
          </span>
        );
    }
  };

  const getBulletClass = (decision: string) => {
    if (decision === 'ENHANCE_AND_RECHECK') return 'enhance';
    if (decision === 'REQUEST_HUMAN_REVIEW') return 'review';
    if (decision === 'CONTINUE') return 'continue';
    return 'default';
  };

  return (
    <div className="glass-card">
      <div className="card-header">
        <div className="card-title-group">
          <Activity size={18} color="var(--accent-cyan)" />
          <div>
            <div className="card-title">Agentic Vision Perception-Decision Timeline</div>
            <div className="card-subtitle">
              Authentic backend reasoning traces recorded during OpenCV 5 frame-by-frame analysis
            </div>
          </div>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', fontSize: '0.78rem' }}>
          <span className="badge badge-cyan">{total_actions} Total Agent Steps</span>
        </div>
      </div>

      <div className="card-body">
        {/* Decision Breakdown Summary Chips */}
        <div style={{ marginBottom: '1.25rem' }}>
          <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginBottom: '0.45rem' }}>
            Decision Action Breakdown (from real backend execution):
          </div>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '0.5rem' }}>
            <button
              type="button"
              onClick={() => setSelectedFilter('ALL')}
              className={`nav-tab-btn ${selectedFilter === 'ALL' ? 'active' : ''}`}
              style={{ padding: '0.35rem 0.75rem', fontSize: '0.78rem' }}
            >
              All Actions ({sample_traces.length} samples)
            </button>
            {distinctDecisions.map((dec) => (
              <button
                key={dec}
                type="button"
                onClick={() => setSelectedFilter(dec)}
                className={`nav-tab-btn ${selectedFilter === dec ? 'active' : ''}`}
                style={{ padding: '0.35rem 0.75rem', fontSize: '0.78rem' }}
              >
                {dec.replace(/_/g, ' ')} ({action_counts[dec]})
              </button>
            ))}
          </div>
        </div>

        {/* Timeline of Steps */}
        {filteredTraces.length > 0 ? (
          <div className="trace-timeline">
            {filteredTraces.map((step, idx) => {
              const obs = step.observations || {};
              const brightness = obs.brightness_mean !== undefined
                ? Number(obs.brightness_mean).toFixed(1)
                : null;
              const blur = obs.blur_score !== undefined
                ? Number(obs.blur_score).toFixed(1)
                : null;

              return (
                <div key={`${step.frame}_${idx}`} className="trace-item">
                  <div className={`trace-bullet ${getBulletClass(step.decision)}`} />

                  <div
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      flexWrap: 'wrap',
                      gap: '0.5rem',
                      marginBottom: '0.4rem',
                    }}
                  >
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem' }}>
                      {getDecisionBadge(step.decision)}
                      <span
                        style={{
                          fontFamily: 'var(--font-mono)',
                          fontSize: '0.8rem',
                          color: '#f8fafc',
                          fontWeight: 600,
                        }}
                      >
                        Frame #{step.frame}
                      </span>
                    </div>

                    <button
                      type="button"
                      onClick={() => onSeekVideo?.(step.timestamp_sec)}
                      className="time-seek-btn"
                      title="Jump video to this trace frame"
                    >
                      <Play size={10} fill="currentColor" />
                      <span>{step.timestamp_sec.toFixed(2)}s</span>
                    </button>
                  </div>

                  {/* Observations row */}
                  <div
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      flexWrap: 'wrap',
                      gap: '0.75rem',
                      background: 'rgba(8, 12, 22, 0.6)',
                      padding: '0.45rem 0.75rem',
                      borderRadius: 'var(--radius-sm)',
                      fontSize: '0.75rem',
                      fontFamily: 'var(--font-mono)',
                      color: 'var(--text-secondary)',
                      marginBottom: '0.45rem',
                      border: '1px solid var(--border-subtle)',
                    }}
                  >
                    {brightness !== null && (
                      <span style={{ display: 'flex', alignItems: 'center', gap: '0.25rem' }}>
                        <Sun size={12} color="#fbbf24" /> Brightness: {brightness}
                      </span>
                    )}
                    {blur !== null && (
                      <span style={{ display: 'flex', alignItems: 'center', gap: '0.25rem' }}>
                        <Sliders size={12} color="var(--accent-cyan)" /> Laplacian Blur: {blur}
                      </span>
                    )}
                    <span style={{ color: 'var(--text-dim)' }}>
                      Action: <strong style={{ color: '#e2e8f0' }}>{step.action}</strong>
                    </span>
                    <span style={{ color: 'var(--text-dim)' }}>
                      Outcome: <strong style={{ color: '#e2e8f0' }}>{step.outcome}</strong>
                    </span>
                  </div>

                  {/* Trace details if present */}
                  {step.details && (
                    <div
                      style={{
                        fontSize: '0.76rem',
                        color: 'var(--text-muted)',
                        paddingLeft: '0.25rem',
                      }}
                    >
                      {step.details}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        ) : (
          <div
            style={{
              textAlign: 'center',
              padding: '2rem',
              color: 'var(--text-muted)',
              fontSize: '0.85rem',
            }}
          >
            No trace steps match the selected filter.
          </div>
        )}
      </div>
    </div>
  );
};

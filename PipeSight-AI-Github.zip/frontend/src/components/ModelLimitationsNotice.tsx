import { useState } from 'react';
import { AlertTriangle, ChevronDown, ChevronUp } from 'lucide-react';

interface Props {
  metricMap50?: string;
  className?: string;
}

export const ModelLimitationsNotice: React.FC<Props> = ({
  metricMap50 = '42.6%',
  className = '',
}) => {
  const [isExpanded, setIsExpanded] = useState(false);

  return (
    <div
      className={`model-alert-banner ${className}`}
      role="region"
      aria-label="Model Limitations and Prototype Advisory"
    >
      <AlertTriangle className="model-alert-icon" size={22} aria-hidden="true" />
      <div className="model-alert-content" style={{ flex: 1 }}>
        <h4>
          <span>AI-Assisted Inspection Advisory</span>
          <span className="prototype-tag">Prototype Notice</span>
        </h4>
        <p>
          PipeSight AI is an experimental prototype. The current sewer defect detection model
          achieved approximately <strong className="metric-pill-highlight">~{metricMap50} mAP@50</strong> on
          the held-out test dataset. All predictions are model-assisted advisory detections and{' '}
          <strong>require mandatory manual verification</strong> by certified pipeline inspection personnel.
          This system is not validated for autonomous repair decisions.
        </p>

        {isExpanded && (
          <div
            style={{
              marginTop: '0.75rem',
              paddingTop: '0.75rem',
              borderTop: '1px solid rgba(245, 158, 11, 0.25)',
              fontSize: '0.8rem',
              color: '#fef3c7',
              display: 'flex',
              flexDirection: 'column',
              gap: '0.4rem',
            }}
          >
            <div>
              <strong>ByteTrack Disclaimer:</strong> Track associations are estimated across sequential video frames.
              Identity switches may occur during rapid camera panning or visual occlusions.
            </div>
            <div>
              <strong>Spatial Metric Disclaimer:</strong> Monocular CCTV video does not provide calibrated physical
              defect measurements, wall penetration depth, or absolute linear pipe stationing without external odometry.
            </div>
            <div>
              <strong>Prediction Scores:</strong> Confidence percentages represent internal model feature alignment,
              not the confirmed statistical probability of structural pipe failure.
            </div>
          </div>
        )}

        <button
          onClick={() => setIsExpanded(!isExpanded)}
          style={{
            marginTop: '0.5rem',
            fontSize: '0.75rem',
            color: '#fbbf24',
            display: 'inline-flex',
            alignItems: 'center',
            gap: '0.3rem',
            fontWeight: 600,
            textDecoration: 'underline',
          }}
          aria-expanded={isExpanded}
        >
          {isExpanded ? (
            <>
              Hide Technical Disclaimers <ChevronUp size={14} />
            </>
          ) : (
            <>
              View Full Engineering Limitations & Assumptions <ChevronDown size={14} />
            </>
          )}
        </button>
      </div>
    </div>
  );
};

import {
  AlertTriangle,
  Eye,
  HelpCircle,
  ImageIcon,
  Play,
  ShieldAlert,
} from 'lucide-react';
import type { TrackEvent } from '../types/inspection';

interface Props {
  events: TrackEvent[];
  onSeekVideo?: (seconds: number) => void;
  onViewEvidence?: (event: TrackEvent) => void;
}

export const DefectEventTable: React.FC<Props> = ({
  events,
  onSeekVideo,
  onViewEvidence,
}) => {
  const formatTime = (sec: number): string => {
    const mins = Math.floor(sec / 60);
    const secs = (sec % 60).toFixed(1);
    return `${mins}:${secs.padStart(4, '0')}s`;
  };

  if (!events || events.length === 0) {
    return (
      <div className="glass-card">
        <div className="card-header">
          <div className="card-title">Defect Event Log</div>
        </div>
        <div
          className="card-body"
          style={{
            textAlign: 'center',
            padding: '2.5rem',
            color: 'var(--text-muted)',
          }}
        >
          <div style={{ fontSize: '1rem', fontWeight: 600, color: 'var(--text-secondary)' }}>
            No defect occurrences logged.
          </div>
          <p style={{ fontSize: '0.82rem', marginTop: '0.35rem' }}>
            The ByteTrack tracker did not register any sustained defect tracks above the confidence threshold.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="glass-card">
      <div className="card-header">
        <div className="card-title-group">
          <ShieldAlert size={18} color="var(--accent-cyan)" />
          <div>
            <div className="card-title">Tracked Defect Events Log</div>
            <div className="card-subtitle">
              Spatially associated pipe defects with advisory model prediction scores
            </div>
          </div>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', fontSize: '0.78rem' }}>
          <span className="badge badge-cyan">{events.length} Unique Events</span>
        </div>
      </div>

      <div className="card-body" style={{ padding: '0' }}>
        {/* Advisory Header Note */}
        <div
          style={{
            padding: '0.65rem 1.25rem',
            background: 'rgba(10, 16, 29, 0.5)',
            borderBottom: '1px solid var(--border-subtle)',
            fontSize: '0.76rem',
            color: 'var(--text-muted)',
            display: 'flex',
            alignItems: 'center',
            gap: '0.5rem',
          }}
        >
          <HelpCircle size={14} color="var(--accent-cyan)" />
          <span>
            <strong>Prediction Score Disclosure:</strong> The score represents YOLO model detection confidence
            (0.00 – 1.00), <em>not</em> an engineered confirmation of structural failure. Findings flagged with{' '}
            <strong style={{ color: '#fbbf24' }}>Human Review</strong> fall within the uncertain boundary and require
            inspection operator sign-off.
          </span>
        </div>

        <div className="table-responsive">
          <table className="data-table">
            <thead>
              <tr>
                <th style={{ width: '80px' }}>Track ID</th>
                <th>Defect Name / Advisory Label</th>
                <th>Prediction Score</th>
                <th>Timestamp Span</th>
                <th>Duration / Frames</th>
                <th>Review Status</th>
                <th style={{ textAlign: 'right' }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {events.map((ev) => {
                const isUncertain = ev.peak_confidence < 0.42;
                const repTime = ev.representative_timestamp_sec ?? ev.first_seen_sec;

                return (
                  <tr key={ev.track_id}>
                    {/* Track ID */}
                    <td style={{ fontFamily: 'var(--font-mono)', fontWeight: 700 }}>
                      <span
                        style={{
                          background: 'rgba(6, 182, 212, 0.15)',
                          color: 'var(--accent-cyan-light)',
                          padding: '0.2rem 0.45rem',
                          borderRadius: '4px',
                          border: '1px solid rgba(6, 182, 212, 0.3)',
                        }}
                      >
                        #{ev.track_id}
                      </span>
                    </td>

                    {/* Defect Name & Label */}
                    <td>
                      <div style={{ display: 'flex', flexDirection: 'column', gap: '0.2rem' }}>
                        <span style={{ fontWeight: 600, color: '#f8fafc', fontSize: '0.9rem' }}>
                          {ev.advisory_label || ev.class_name}
                        </span>
                        <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                          Class: {ev.class_name}
                        </span>
                      </div>
                    </td>

                    {/* Model Confidence / Prediction Score */}
                    <td>
                      <div style={{ display: 'flex', flexDirection: 'column', gap: '0.25rem' }}>
                        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                          <span
                            style={{
                              fontFamily: 'var(--font-mono)',
                              fontWeight: 700,
                              fontSize: '0.95rem',
                              color: isUncertain ? '#fbbf24' : '#38bdf8',
                            }}
                          >
                            {(ev.peak_confidence * 100).toFixed(1)}%
                          </span>
                          <span style={{ fontSize: '0.72rem', color: 'var(--text-dim)', fontFamily: 'var(--font-mono)' }}>
                            (peak: {ev.peak_confidence.toFixed(3)})
                          </span>
                        </div>

                        {/* Visual confidence bar */}
                        <div
                          style={{
                            width: '100px',
                            height: '4px',
                            background: 'rgba(255, 255, 255, 0.1)',
                            borderRadius: '2px',
                            overflow: 'hidden',
                          }}
                        >
                          <div
                            style={{
                              width: `${Math.min(100, ev.peak_confidence * 100)}%`,
                              height: '100%',
                              background: isUncertain ? '#f59e0b' : '#06b6d4',
                            }}
                          />
                        </div>
                      </div>
                    </td>

                    {/* Timestamps (clickable) */}
                    <td>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                        <button
                          type="button"
                          onClick={() => onSeekVideo?.(ev.first_seen_sec)}
                          className="time-seek-btn"
                          title={`Seek video to ${ev.first_seen_sec.toFixed(2)}s`}
                        >
                          <Play size={10} fill="currentColor" />
                          <span>{formatTime(ev.first_seen_sec)}</span>
                        </button>
                        <span style={{ color: 'var(--text-dim)' }}>→</span>
                        <button
                          type="button"
                          onClick={() => onSeekVideo?.(ev.last_seen_sec)}
                          className="time-seek-btn"
                          title={`Seek video to ${ev.last_seen_sec.toFixed(2)}s`}
                        >
                          <span>{formatTime(ev.last_seen_sec)}</span>
                        </button>
                      </div>
                    </td>

                    {/* Observation count */}
                    <td>
                      <div style={{ display: 'flex', flexDirection: 'column' }}>
                        <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.85rem' }}>
                          {ev.duration_sec.toFixed(2)}s
                        </span>
                        <span style={{ fontSize: '0.72rem', color: 'var(--text-dim)' }}>
                          {ev.observation_count} frames observed
                        </span>
                      </div>
                    </td>

                    {/* Review Status */}
                    <td>
                      {isUncertain ? (
                        <span
                          className="badge badge-warning"
                          title="Confidence between 25% and 42%. Manual verification recommended by pipeline controller."
                        >
                          <AlertTriangle size={12} />
                          <span>Human Review Required</span>
                        </span>
                      ) : (
                        <span
                          className="badge badge-cyan"
                          title="Sustained track meeting detection confidence criteria."
                        >
                          <Eye size={12} />
                          <span>Advisory Detected</span>
                        </span>
                      )}
                    </td>

                    {/* Actions */}
                    <td style={{ textAlign: 'right' }}>
                      <div style={{ display: 'inline-flex', gap: '0.4rem' }}>
                        <button
                          type="button"
                          onClick={() => onSeekVideo?.(repTime)}
                          className="btn btn-secondary btn-sm"
                          title="Seek video to representative frame"
                          style={{ padding: '0.3rem 0.6rem' }}
                        >
                          <Play size={12} fill="currentColor" /> Seek
                        </button>

                        {(ev.evidence_image_url || ev.evidence_image_key) && (
                          <button
                            type="button"
                            onClick={() => onViewEvidence?.(ev)}
                            className="btn btn-outline-cyan btn-sm"
                            title="View annotated evidence snapshot"
                            style={{ padding: '0.3rem 0.6rem' }}
                          >
                            <ImageIcon size={12} /> Evidence
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

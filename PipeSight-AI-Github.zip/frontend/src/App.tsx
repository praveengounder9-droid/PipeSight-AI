import React, { useState, useEffect, useCallback } from 'react';
import {
  Film,
  History,
  Loader2,
  PlusCircle,
} from 'lucide-react';

import {
  AppShell,
  type ActiveTab,
} from './components/AppShell';
import { VideoUploader } from './components/VideoUploader';
import { InspectionProgress } from './components/InspectionProgress';
import { InspectionSummary } from './components/InspectionSummary';
import { DefectEventTable } from './components/DefectEventTable';
import { AnnotatedVideoPlayer } from './components/AnnotatedVideoPlayer';
import { EvidenceGallery } from './components/EvidenceGallery';
import { AgentTraceTimeline } from './components/AgentTraceTimeline';
import { ReportDownloads } from './components/ReportDownloads';
import { ErrorBanner } from './components/ErrorBanner';
import { AboutView } from './components/AboutView';
import { ModelLimitationsNotice } from './components/ModelLimitationsNotice';

import {
  getInspectionReport,
  getEvidenceList,
  getSystemInfo,
} from './services/api';
import {
  getRecentJobs,
  saveRecentJob,
  updateRecentJobStatus,
} from './services/storage';

import type {
  EvidenceItem,
  HealthResponse,
  InspectionReport,
  RecentJobRecord,
  SystemInfoResponse,
  TrackEvent,
} from './types/inspection';

export const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<ActiveTab>('new-inspection');

  // Job and Processing State
  const [currentJobId, setCurrentJobId] = useState<string | null>(null);
  const [currentFilename, setCurrentFilename] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);

  // Completed Report State
  const [report, setReport] = useState<InspectionReport | null>(null);
  const [evidenceItems, setEvidenceItems] = useState<EvidenceItem[]>([]);
  const [reportLoading, setReportLoading] = useState<boolean>(false);
  const [reportError, setReportError] = useState<string | null>(null);

  // Synchronized Video Seek
  const [seekTime, setSeekTime] = useState<number | null>(null);
  const [selectedEvidenceEvent, setSelectedEvidenceEvent] = useState<TrackEvent | null>(null);

  // System and Backend State
  const [health, setHealth] = useState<HealthResponse | null>(null);
  const [systemInfo, setSystemInfo] = useState<SystemInfoResponse | null>(null);
  const [recentJobs, setRecentJobs] = useState<RecentJobRecord[]>([]);

  // Load initial data
  useEffect(() => {
    setRecentJobs(getRecentJobs());

    // Fetch system info
    getSystemInfo()
      .then((info) => setSystemInfo(info))
      .catch((err) => console.warn('Could not fetch system info:', err));
  }, []);

  // Fetch report and evidence for a specific job ID
  const fetchReportForJob = useCallback(async (jobId: string) => {
    setReportLoading(true);
    setReportError(null);
    try {
      const [reportData, evidenceData] = await Promise.all([
        getInspectionReport(jobId),
        getEvidenceList(jobId).catch(() => ({ job_id: jobId, count: 0, evidence_items: [] })),
      ]);
      setReport(reportData);
      setEvidenceItems(evidenceData.evidence_items || []);
      setCurrentJobId(jobId);
      setCurrentFilename(reportData.video_statistics.filename);

      // Update storage
      updateRecentJobStatus(
        jobId,
        'completed',
        reportData.summary.estimated_unique_events_count
      );
      setRecentJobs(getRecentJobs());
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Failed to load report';
      setReportError(msg);
      setReport(null);
    } finally {
      setReportLoading(false);
    }
  }, []);

  // Handler: Video inspection submitted
  const handleInspectionStarted = (jobId: string, filename: string, fileSize: number) => {
    setCurrentJobId(jobId);
    setCurrentFilename(filename);
    setIsProcessing(true);
    setReport(null);
    setReportError(null);

    // Save to recent jobs
    const newRecord: RecentJobRecord = {
      job_id: jobId,
      filename,
      file_size_bytes: fileSize,
      created_at: new Date().toISOString(),
      status: 'processing',
    };
    saveRecentJob(newRecord);
    setRecentJobs(getRecentJobs());
  };

  // Handler: Background worker finished
  const handleJobCompleted = (jobId: string) => {
    setIsProcessing(false);
    setActiveTab('results');
    fetchReportForJob(jobId);
  };

  // Handler: Select a job from history or manual search
  const handleSelectJob = (jobId: string) => {
    setIsProcessing(false);
    setActiveTab('results');
    fetchReportForJob(jobId);
  };

  // Handler: Seek video player to timestamp
  const handleSeekVideo = (seconds: number) => {
    setSeekTime(seconds);
  };

  // Handler: View Evidence in gallery
  const handleViewEvidence = (event: TrackEvent) => {
    setSelectedEvidenceEvent(event);
    // Smooth scroll to gallery
    const el = document.getElementById('evidence-gallery-section');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const isBackendHealthy = health !== null && health.status === 'healthy';

  return (
    <AppShell
      activeTab={activeTab}
      onTabChange={setActiveTab}
      recentJobs={recentJobs}
      currentJobId={currentJobId}
      onSelectJob={handleSelectJob}
      onJobsCleared={() => setRecentJobs([])}
      onHealthLoaded={setHealth}
      hasActiveReport={Boolean(report)}
    >
      {/* View 1: New Inspection View */}
      {activeTab === 'new-inspection' && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
          {/* Top Banner Notice */}
          <ModelLimitationsNotice metricMap50={systemInfo?.model_metric_map50 || '42.6%'} />

          {isProcessing && currentJobId ? (
            <InspectionProgress
              jobId={currentJobId}
              filename={currentFilename || undefined}
              onJobCompleted={handleJobCompleted}
              onReset={() => {
                setIsProcessing(false);
                setCurrentJobId(null);
              }}
            />
          ) : (
            <VideoUploader
              onInspectionStarted={handleInspectionStarted}
              isBackendHealthy={isBackendHealthy}
              supportedFormats={systemInfo?.supported_file_types || ['.mp4', '.avi', '.mov', '.mkv', '.webm']}
            />
          )}
        </div>
      )}

      {/* View 2: Inspection Results View */}
      {activeTab === 'results' && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
          {/* Model Notice on Results */}
          <ModelLimitationsNotice metricMap50={systemInfo?.model_metric_map50 || '42.6%'} />

          {/* Error Banner */}
          {reportError && (
            <ErrorBanner
              title="Report Loading Error"
              message={reportError}
              onRetry={currentJobId ? () => fetchReportForJob(currentJobId) : undefined}
              onDismiss={() => setReportError(null)}
            />
          )}

          {/* Loading Skeleton */}
          {reportLoading && (
            <div className="glass-card" style={{ padding: '3.5rem', textAlign: 'center' }}>
              <Loader2 size={36} className="spin" color="var(--accent-cyan)" style={{ margin: '0 auto 1rem' }} />
              <div style={{ fontSize: '1.1rem', fontWeight: 600, color: '#f8fafc' }}>
                Fetching Structured Inspection Report...
              </div>
              <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)', marginTop: '0.4rem' }}>
                Aggregating defect coordinates, ByteTrack telemetry, and evidence metadata
              </p>
            </div>
          )}

          {/* Empty State: No Job Selected */}
          {!reportLoading && !report && !reportError && (
            <div className="glass-card" style={{ padding: '3.5rem 2rem', textAlign: 'center', maxWidth: '720px', margin: '0 auto' }}>
              <div
                style={{
                  width: '64px',
                  height: '64px',
                  borderRadius: '50%',
                  background: 'rgba(6, 182, 212, 0.12)',
                  border: '1px solid rgba(6, 182, 212, 0.3)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  margin: '0 auto 1.25rem',
                  color: 'var(--accent-cyan-light)',
                }}
              >
                <Film size={32} />
              </div>
              <h2 style={{ fontSize: '1.4rem', fontWeight: 700, marginBottom: '0.5rem' }}>
                No Active Inspection Report Selected
              </h2>
              <p style={{ fontSize: '0.9rem', color: 'var(--text-secondary)', marginBottom: '1.5rem', lineHeight: 1.5 }}>
                Submit a new sewer video to run Agentic Vision inspection, or select an existing inspection session
                from your recent history.
              </p>

              <div style={{ display: 'flex', justifyContent: 'center', gap: '0.75rem', flexWrap: 'wrap' }}>
                <button
                  type="button"
                  onClick={() => setActiveTab('new-inspection')}
                  className="btn btn-primary"
                >
                  <PlusCircle size={16} /> Start New Inspection
                </button>

                {recentJobs.length > 0 && (
                  <button
                    type="button"
                    onClick={() => handleSelectJob(recentJobs[0].job_id)}
                    className="btn btn-secondary"
                  >
                    <History size={16} /> Open Latest Job ({recentJobs[0].job_id.slice(0, 8)}...)
                  </button>
                )}
              </div>
            </div>
          )}

          {/* Render Full Report when loaded */}
          {!reportLoading && report && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1.75rem' }}>
              {/* Summary Cards */}
              <InspectionSummary report={report} />

              {/* Video Player Section */}
              <AnnotatedVideoPlayer
                jobId={report.job_id}
                videoUrl={report.artifacts.annotated_video_url}
                seekTime={seekTime}
              />

              {/* Defect Event Log Table */}
              <DefectEventTable
                events={report.defect_events}
                onSeekVideo={handleSeekVideo}
                onViewEvidence={handleViewEvidence}
              />

              {/* Evidence Gallery */}
              <div id="evidence-gallery-section">
                <EvidenceGallery
                  jobId={report.job_id}
                  events={report.defect_events}
                  evidenceItems={evidenceItems}
                  selectedEvent={selectedEvidenceEvent}
                  onClearSelectedEvent={() => setSelectedEvidenceEvent(null)}
                  onSeekVideo={handleSeekVideo}
                />
              </div>

              {/* Agentic Vision Trace Timeline */}
              <AgentTraceTimeline
                decisionsSummary={report.agent_decisions_summary}
                onSeekVideo={handleSeekVideo}
              />

              {/* Download Artifacts */}
              <ReportDownloads jobId={report.job_id} />
            </div>
          )}
        </div>
      )}

      {/* View 3: About & Architecture View */}
      {activeTab === 'about' && (
        <AboutView health={health} systemInfo={systemInfo} />
      )}
    </AppShell>
  );
};

export default App;

"""
Unit tests for the Agentic Vision perception-decision-action controller.
"""

from unittest.mock import MagicMock
import numpy as np

from app.schemas import AgentDecision, DetectionBox
from app.services.agent_service import AgentVisionController


def test_agent_dark_frame_enhancement():
    agent = AgentVisionController(job_id="test_agent_job")

    # Dark frame (brightness = 15)
    dark_frame = np.full((120, 120, 3), 15, dtype=np.uint8)

    rendered, detections, quality, enhanced = agent.step(
        frame=dark_frame,
        frame_idx=10,
        timestamp_sec=0.4,
    )

    assert quality.is_too_dark is True
    # At least one trace must reflect ENHANCE_AND_RECHECK
    decisions = [t.decision for t in agent.traces]
    assert AgentDecision.ENHANCE_AND_RECHECK.value in decisions

    summary = agent.get_summary()
    assert summary.total_actions > 0
    assert AgentDecision.ENHANCE_AND_RECHECK.value in summary.action_counts


def test_agent_uncertain_detection_human_review():
    mock_vision = MagicMock()
    # Mock vision returning borderline confidence detection on low quality frame
    mock_vision.track_frame.return_value = [
        DetectionBox(
            class_id=1,
            class_name="Crack",
            confidence=0.30,  # Borderline uncertain
            bbox=[10, 10, 50, 50],
            track_id=1,
            frame_idx=0,
            timestamp_sec=0.0,
            enhanced=False,
        )
    ]

    agent = AgentVisionController(job_id="test_mock", vision_svc=mock_vision)
    dark_frame = np.full((120, 120, 3), 15, dtype=np.uint8)

    _, _, _, _ = agent.step(frame=dark_frame, frame_idx=0, timestamp_sec=0.0)

    decisions = [t.decision for t in agent.traces]
    # Should include either ENHANCE_AND_RECHECK, INSPECT_ADJACENT_FRAMES, or REQUEST_HUMAN_REVIEW
    assert any(
        d in decisions
        for d in [
            AgentDecision.ENHANCE_AND_RECHECK.value,
            AgentDecision.INSPECT_ADJACENT_FRAMES.value,
            AgentDecision.REQUEST_HUMAN_REVIEW.value,
        ]
    )

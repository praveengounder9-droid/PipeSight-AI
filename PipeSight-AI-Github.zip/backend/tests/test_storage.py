"""
Unit tests for storage service adapters (Local and S3).
"""

from pathlib import Path
from unittest.mock import MagicMock
import pytest

from app.services.storage_service import LocalStorageService, S3StorageService


def test_local_storage_adapter(tmp_path: Path):
    storage = LocalStorageService(base_dir=str(tmp_path))
    job_id = "test_local_job"
    filename = "test_artifact.txt"
    content = b"PipeSight AI Local Storage Test"

    # Save bytes
    key = storage.save_bytes(job_id, filename, content)
    assert filename in key

    # File exists
    assert storage.file_exists(job_id, filename) is True
    assert storage.file_exists(job_id, "non_existent.txt") is False

    # Get local path
    local_path = storage.get_local_path(job_id, filename)
    assert local_path is not None
    assert Path(local_path).read_bytes() == content

    # List files
    files = storage.list_files(job_id)
    assert filename in files

    # URL generation
    url = storage.get_url(job_id, filename)
    assert job_id in url


def test_s3_storage_adapter():
    storage = S3StorageService(bucket_name="test-pipesight-bucket", region_name="us-east-1")
    # Mock boto3 s3 client
    mock_s3 = MagicMock()
    storage.s3_client = mock_s3
    mock_s3.generate_presigned_url.return_value = "https://test-pipesight-bucket.s3.amazonaws.com/inspections/job123/report.pdf?sig=test"

    job_id = "job123"
    filename = "report.pdf"
    content = b"%PDF-1.4 test content"

    key = storage.save_bytes(job_id, filename, content, "application/pdf")
    assert key == f"inspections/{job_id}/{filename}"
    mock_s3.put_object.assert_called_once_with(
        Bucket="test-pipesight-bucket",
        Key=f"inspections/{job_id}/{filename}",
        Body=content,
        ContentType="application/pdf",
    )

    url = storage.get_url(job_id, filename)
    assert url.startswith("https://test-pipesight-bucket")

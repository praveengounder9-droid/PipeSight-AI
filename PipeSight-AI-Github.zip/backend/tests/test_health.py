"""
Unit tests for the /health and /api/v1/info endpoints.
"""

from fastapi.testclient import TestClient


def test_health_endpoint(client: TestClient):
    response = client.get("/health")
    assert response.status_code == 200
    data = response.json()

    assert data["status"] == "healthy"
    assert "opencv_version" in data
    assert data["opencv_version"].startswith("5.")
    assert "torch_version" in data
    assert "ultralytics_version" in data
    assert data["model_loaded"] is True
    assert data["classes_count"] == 7
    assert "device" in data
    assert isinstance(data["capabilities"], list)
    assert len(data["capabilities"]) > 0
    assert "cool_enabled" in data
    assert "cool_status" in data


def test_info_endpoint(client: TestClient):
    response = client.get("/api/v1/info")
    assert response.status_code == 200
    data = response.json()

    assert data["class_count"] == 7
    assert len(data["class_names"]) == 7
    assert "Crack" in data["class_names"].values()
    assert "Buckling" in data["class_names"].values()
    assert data["confidence_threshold"] > 0
    assert ".mp4" in data["supported_file_types"]
    assert "42.6%" in data["model_metric_map50"]
    assert "prototype" in data["model_limitations_notice"].lower()

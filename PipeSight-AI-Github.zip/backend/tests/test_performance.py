"""
Unit tests for CPU Performance Optimizations:
- Aspect-preserving frame resizing
- Frame sampling with configurable FRAME_STRIDE
- ByteTrack tracker reset
- PerformanceMetrics and progress reporting
"""

import numpy as np
import pytest
from app.config import settings
from app.schemas import PerformanceMetrics
from app.services.vision_service import vision_service
from app.utils.video_utils import (
    compute_aspect_preserving_dimensions,
    resize_frame_if_needed,
)


def test_aspect_preserving_dimensions_1080p():
    """Verify 1920x1080 downscales to 640x360 preserving 16:9 aspect ratio."""
    w, h, scale = compute_aspect_preserving_dimensions(1920, 1080, max_dim=640)
    assert w == 640
    assert h == 360
    assert w % 2 == 0 and h % 2 == 0
    assert abs((w / h) - (1920 / 1080)) < 0.01


def test_aspect_preserving_dimensions_already_small():
    """Verify 480x480 remains untouched (no unnecessary resize)."""
    w, h, scale = compute_aspect_preserving_dimensions(480, 480, max_dim=640)
    assert w == 480
    assert h == 480
    assert scale == 1.0


def test_aspect_preserving_dimensions_portrait():
    """Verify portrait video (1080x1920) fits inside 640x640 without distortion."""
    w, h, scale = compute_aspect_preserving_dimensions(1080, 1920, max_dim=640)
    assert h == 640
    assert w == 360
    assert w % 2 == 0 and h % 2 == 0


def test_aspect_preserving_dimensions_odd_numbers():
    """Verify odd resolutions result in even target dimensions for codec compatibility."""
    w, h, scale = compute_aspect_preserving_dimensions(1921, 1079, max_dim=640)
    assert w % 2 == 0
    assert h % 2 == 0
    assert w <= 640 and h <= 640


def test_resize_frame_if_needed_no_op():
    """Verify frame is not copied or re-allocated if dimensions already match."""
    frame = np.zeros((480, 480, 3), dtype=np.uint8)
    out = resize_frame_if_needed(frame, target_w=480, target_h=480)
    assert out is frame  # Identity check: zero overhead


def test_resize_frame_if_needed_downscale():
    """Verify frame downscaling produces expected shape."""
    frame = np.zeros((1080, 1920, 3), dtype=np.uint8)
    out = resize_frame_if_needed(frame, target_w=640, target_h=360)
    assert out.shape == (360, 640, 3)


def test_tracker_state_reset():
    """Verify ByteTrack tracker reset can be called cleanly between inspection runs."""
    vision_service.reset_tracker()
    assert vision_service.model is not None


def test_performance_metrics_schema():
    """Verify PerformanceMetrics serialization and schema integrity."""
    pm = PerformanceMetrics(
        original_resolution=(1920, 1080),
        processing_resolution=(640, 360),
        fps=30.0,
        total_source_frames=300,
        frames_processed=100,
        frames_skipped=200,
        frame_stride=3,
        confidence_threshold=0.25,
        video_duration_sec=10.0,
        actual_processing_duration_sec=5.2,
        processing_fps=57.7,
        time_breakdown_sec={
            "decoding_sec": 0.45,
            "resizing_sec": 0.22,
            "inference_sec": 3.8,
            "tracking_sec": 0.35,
            "encoding_sec": 0.38,
        },
        enhancement_retries=1,
        candidate_defect_events_count=3,
        processing_limitations=["Frame sampling stride=3 enabled."],
    )
    dumped = pm.model_dump()
    assert dumped["frame_stride"] == 3
    assert dumped["frames_processed"] == 100
    assert dumped["frames_skipped"] == 200
    assert dumped["processing_fps"] == 57.7
    assert "decoding_sec" in dumped["time_breakdown_sec"]

"""
Unit tests for OpenCV 5 image quality analysis and luminance enhancement.
"""

import cv2
import numpy as np

from app.utils.image_quality import (
    compare_detection_candidates,
    compute_image_quality,
    enhance_frame_luminance,
)
from tests.conftest import generate_synthetic_pipe_frame


def test_compute_image_quality_normal():
    frame = generate_synthetic_pipe_frame(draw_crack=True)
    metrics = compute_image_quality(frame)

    assert metrics.brightness_mean > 0
    assert metrics.blur_score > 0
    assert metrics.contrast_score > 0
    assert not metrics.is_too_dark


def test_compute_image_quality_dark():
    # Artificially dark frame
    dark_frame = np.full((100, 100, 3), 15, dtype=np.uint8)
    metrics = compute_image_quality(dark_frame)

    assert metrics.is_too_dark
    assert metrics.is_low_quality
    assert any("low_brightness" in flag for flag in metrics.quality_flags)


def test_compute_image_quality_blur():
    sharp_frame = generate_synthetic_pipe_frame(draw_crack=True)
    blurry_frame = cv2.GaussianBlur(sharp_frame, (25, 25), 10.0)

    sharp_metrics = compute_image_quality(sharp_frame)
    blurry_metrics = compute_image_quality(blurry_frame)

    # Blur score (Laplacian variance) must drop significantly for blurry image
    assert blurry_metrics.blur_score < sharp_metrics.blur_score


def test_enhance_frame_luminance_clahe():
    dark_frame = np.full((100, 100, 3), 20, dtype=np.uint8)
    enhanced, meta = enhance_frame_luminance(dark_frame, apply_bilateral=True)

    assert enhanced.shape == dark_frame.shape
    assert meta["clahe_applied"] is True
    assert meta["bilateral_applied"] is True
    assert meta["new_brightness"] > 20


def test_compare_detection_candidates():
    orig = [{"class_name": "Crack", "confidence": 0.35}]
    enh = [
        {"class_name": "Crack", "confidence": 0.55},
        {"class_name": "Debris", "confidence": 0.40},
    ]

    diff = compare_detection_candidates(orig, enh)
    assert diff["outcome"] == "recovered_additional_defects"
    assert diff["enhanced_count"] == 2
    assert diff["conf_delta"] == 0.20

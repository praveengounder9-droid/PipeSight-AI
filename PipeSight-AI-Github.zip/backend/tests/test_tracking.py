"""
Unit tests for ByteTrack deduplication and defect-event aggregation.
"""

import numpy as np

from app.schemas import DetectionBox
from app.services.tracking_service import TrackingService
from app.services.vision_service import vision_service


def test_tracking_aggregation():
    tracker = TrackingService(job_id="test_job")
    dummy_frame = np.zeros((100, 100, 3), dtype=np.uint8)

    # Frame 1: Detection for track 1
    d1 = DetectionBox(
        class_id=1,
        class_name="Crack",
        confidence=0.45,
        bbox=[10.0, 10.0, 50.0, 50.0],
        track_id=1,
        frame_idx=0,
        timestamp_sec=0.0,
    )
    tracker.add_detections([d1], frame=dummy_frame)

    # Frame 2: Detection for track 1 with higher confidence and track 2 (Debris)
    d2 = DetectionBox(
        class_id=1,
        class_name="Crack",
        confidence=0.75,
        bbox=[12.0, 11.0, 52.0, 51.0],
        track_id=1,
        frame_idx=5,
        timestamp_sec=0.5,
    )
    d3 = DetectionBox(
        class_id=2,
        class_name="Debris",
        confidence=0.60,
        bbox=[80.0, 80.0, 95.0, 95.0],
        track_id=2,
        frame_idx=5,
        timestamp_sec=0.5,
    )
    tracker.add_detections([d2, d3], frame=dummy_frame)

    # Frame 3: Detection for track 1
    d4 = DetectionBox(
        class_id=1,
        class_name="Crack",
        confidence=0.70,
        bbox=[14.0, 12.0, 54.0, 52.0],
        track_id=1,
        frame_idx=10,
        timestamp_sec=1.0,
    )
    tracker.add_detections([d4], frame=dummy_frame)

    # Aggregate events
    events = tracker.aggregate_events()
    assert len(events) == 2

    # Verify track 1 event aggregation
    ev1 = next(e for e in events if e.track_id == 1)
    assert ev1.observation_count == 3
    assert ev1.first_seen_sec == 0.0
    assert ev1.last_seen_sec == 1.0
    assert ev1.duration_sec == 1.0
    assert ev1.peak_confidence == 0.75
    assert ev1.avg_confidence == round((0.45 + 0.75 + 0.70) / 3, 3)
    assert ev1.advisory_label == "Suspected Crack"
    assert ev1.representative_frame_idx == 5

    # Verify track 2 event
    ev2 = next(e for e in events if e.track_id == 2)
    assert ev2.observation_count == 1
    assert ev2.class_name == "Debris"
    assert ev2.advisory_label == "Model-predicted Debris"


def test_tracker_reset():
    # Calling reset_tracker should not error even if no video has been run yet
    vision_service.reset_tracker()

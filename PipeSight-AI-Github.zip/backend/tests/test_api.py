"""
End-to-end API integration tests for PipeSight AI video and image inspection.
"""

import time
from pathlib import Path
from fastapi.testclient import TestClient
import numpy as np
import pytest

from app.schemas import JobStatus


def test_invalid_file_type(client: TestClient, text_file_path: Path):
    with open(text_file_path, "rb") as f:
        response = client.post(
            "/api/v1/inspect/video",
            files={"file": ("invalid_input.txt", f, "text/plain")},
        )
    assert response.status_code == 400
    assert "Unsupported file extension" in response.json()["detail"]


def test_corrupt_video(client: TestClient, corrupt_video_path: Path):
    with open(corrupt_video_path, "rb") as f:
        response = client.post(
            "/api/v1/inspect/video",
            files={"file": ("corrupt.mp4", f, "video/mp4")},
        )
    assert response.status_code == 400
    assert "Invalid video file" in response.json()["detail"]


def test_clean_video_inspection(client: TestClient, clean_video_path: Path):
    """Test video processing pipeline with a video containing no defects."""
    with open(clean_video_path, "rb") as f:
        response = client.post(
            "/api/v1/inspect/video",
            files={"file": ("clean_pipe.mp4", f, "video/mp4")},
        )
    assert response.status_code == 202
    job_data = response.json()
    job_id = job_data["job_id"]
    assert job_id is not None

    # Poll until completed
    max_wait = 20
    start = time.time()
    completed = False
    while time.time() - start < max_wait:
        poll_resp = client.get(f"/api/v1/inspect/{job_id}")
        assert poll_resp.status_code == 200
        status_info = poll_resp.json()
        if status_info["status"] == JobStatus.COMPLETED.value:
            completed = True
            break
        elif status_info["status"] == JobStatus.FAILED.value:
            pytest.fail(f"Job failed: {status_info['error_message']}")
        time.sleep(0.5)

    assert completed, "Video processing timed out"

    # Fetch report
    report_resp = client.get(f"/api/v1/inspect/{job_id}/report")
    assert report_resp.status_code == 200
    report = report_resp.json()

    assert report["job_id"] == job_id
    assert "model_identity" in report
    assert "video_statistics" in report
    assert report["video_statistics"]["processed_frames"] > 0
    assert "agent_decisions_summary" in report
    assert "limitations_and_disclosures" in report
    assert "42.6%" in report["limitations_and_disclosures"]["validation_metric"]


def test_dark_video_quality_enhancement(client: TestClient, dark_video_path: Path):
    """Test that low-light video triggers Agentic Vision CLAHE enhancement."""
    with open(dark_video_path, "rb") as f:
        response = client.post(
            "/api/v1/inspect/video",
            files={"file": ("dark_sewer.mp4", f, "video/mp4")},
        )
    assert response.status_code == 202
    job_id = response.json()["job_id"]

    # Poll for completion
    max_wait = 20
    start = time.time()
    while time.time() - start < max_wait:
        status_info = client.get(f"/api/v1/inspect/{job_id}").json()
        if status_info["status"] in (JobStatus.COMPLETED.value, JobStatus.FAILED.value):
            break
        time.sleep(0.5)

    report_resp = client.get(f"/api/v1/inspect/{job_id}/report")
    assert report_resp.status_code == 200
    report = report_resp.json()

    # Agent must have triggered ENHANCE_AND_RECHECK
    action_counts = report["agent_decisions_summary"]["action_counts"]
    assert "ENHANCE_AND_RECHECK" in action_counts
    assert report["summary"]["low_quality_frames_count"] > 0


def test_single_image_inspection(client: TestClient):
    """Test single image test inspection endpoint."""
    import cv2
    img = np.full((120, 120, 3), 120, dtype=np.uint8)
    # Add a mock line
    cv2.line(img, (20, 20), (100, 100), (0, 0, 0), 3)
    _, enc = cv2.imencode(".jpg", img)

    response = client.post(
        "/api/v1/inspect/image",
        files={"file": ("test_pipe.jpg", enc.tobytes(), "image/jpeg")},
    )
    assert response.status_code == 200
    data = response.json()
    assert "quality_metrics" in data
    assert "agent_decision" in data
    assert "detections" in data
    assert "prototype" in data["notice"].lower()


def test_video_inspection_with_detections_and_pdf_download(
    client: TestClient,
    defect_video_path: Path,
    monkeypatch,
):
    """
    Test video inspection producing tracked defect events, evidence images,
    annotated video download, and PDF report download.
    """
    from app.services.vision_service import vision_service
    from app.schemas import DetectionBox

    # Ensure deterministic detection for this test
    orig_track = vision_service.track_frame

    def mock_track_frame(frame, frame_idx, timestamp_sec, conf_thresh=None, enhanced=False):
        if frame_idx in (2, 3, 4):
            return [
                DetectionBox(
                    class_id=1,
                    class_name="Crack",
                    confidence=0.78,
                    bbox=[50.0, 50.0, 120.0, 120.0],
                    track_id=1,
                    frame_idx=frame_idx,
                    timestamp_sec=timestamp_sec,
                    enhanced=enhanced,
                )
            ]
        return []

    monkeypatch.setattr(vision_service, "track_frame", mock_track_frame)

    with open(defect_video_path, "rb") as f:
        resp = client.post(
            "/api/v1/inspect/video",
            files={"file": ("defect_pipe.mp4", f, "video/mp4")},
        )
    assert resp.status_code == 202
    job_id = resp.json()["job_id"]

    # Poll for completion
    max_wait = 20
    start = time.time()
    while time.time() - start < max_wait:
        status_info = client.get(f"/api/v1/inspect/{job_id}").json()
        if status_info["status"] in (JobStatus.COMPLETED.value, JobStatus.FAILED.value):
            break
        time.sleep(0.4)

    assert status_info["status"] == JobStatus.COMPLETED.value

    # 1. Report check
    report = client.get(f"/api/v1/inspect/{job_id}/report").json()
    assert report["summary"]["estimated_unique_events_count"] == 1
    assert len(report["defect_events"]) == 1
    ev = report["defect_events"][0]
    assert ev["track_id"] == 1
    assert ev["class_name"] == "Crack"
    assert ev["peak_confidence"] == 0.78
    assert ev["advisory_label"] == "Suspected Crack"

    # 2. Evidence list endpoint
    ev_resp = client.get(f"/api/v1/inspect/{job_id}/evidence")
    assert ev_resp.status_code == 200
    ev_data = ev_resp.json()
    assert ev_data["count"] >= 1
    evidence_url = ev_data["evidence_items"][0]["url"]

    # 3. Evidence image download
    img_resp = client.get(evidence_url)
    assert img_resp.status_code == 200
    assert img_resp.headers["content-type"] == "image/jpeg"

    # 4. Annotated video download
    vid_resp = client.get(f"/api/v1/inspect/{job_id}/video")
    assert vid_resp.status_code == 200
    assert vid_resp.headers["content-type"] == "video/mp4"

    # 5. PDF report download
    pdf_resp = client.get(f"/api/v1/inspect/{job_id}/report.pdf")
    assert pdf_resp.status_code == 200
    assert pdf_resp.headers["content-type"] == "application/pdf"
    assert len(pdf_resp.content) > 1000

    # 6. ZIP bundle download
    zip_resp = client.get(f"/api/v1/inspect/{job_id}/zip")
    assert zip_resp.status_code == 200
    assert zip_resp.headers["content-type"] == "application/zip"
    assert len(zip_resp.content) > 100

    # 7. Agent trace download
    trace_resp = client.get(f"/api/v1/inspect/{job_id}/trace")
    assert trace_resp.status_code == 200
    assert trace_resp.headers["content-type"] == "application/json"
    trace_data = trace_resp.json()
    assert isinstance(trace_data, list)


def test_job_id_validation_security(client: TestClient):
    """Test that malformed job IDs are rejected with 400 Bad Request."""
    malformed_ids = [
        "short",
        "a" * 100,  # exceeds 64 characters
        "job!@#$%",
        "job id with spaces",
        "job.with.dots",
        "semi;colon",
    ]
    for bad_id in malformed_ids:
        resp = client.get(f"/api/v1/inspect/{bad_id}")
        assert resp.status_code == 400
        assert "Invalid job ID" in resp.json()["detail"]


def test_list_inspection_jobs(client: TestClient):
    """Test retrieving recent inspection jobs."""
    resp = client.get("/api/v1/inspect/jobs")
    assert resp.status_code == 200
    jobs = resp.json()
    assert isinstance(jobs, list)


def test_system_info_retention_and_storage(client: TestClient):
    """Test system info endpoint reports retention hours and storage notice."""
    resp = client.get("/api/v1/info")
    assert resp.status_code == 200
    data = resp.json()
    assert data["retention_hours"] == 24
    assert data["storage_notice"] is not None
    assert "24 hours" in data["storage_notice"]



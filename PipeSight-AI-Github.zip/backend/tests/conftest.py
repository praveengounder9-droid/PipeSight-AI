"""
Pytest fixtures and synthetic test video generators for PipeSight AI backend tests.
"""

import os
from pathlib import Path
import tempfile
from typing import Generator, Tuple
import cv2
from fastapi.testclient import TestClient
import numpy as np
import pytest

from app.main import app


@pytest.fixture(scope="session")
def client() -> Generator[TestClient, None, None]:
    """TestClient for FastAPI app."""
    with TestClient(app) as test_client:
        yield test_client


def generate_synthetic_pipe_frame(
    width: int = 320,
    height: int = 320,
    brightness_offset: int = 0,
    draw_crack: bool = False,
    draw_debris: bool = False,
    crack_pos: Tuple[int, int] = (160, 160),
) -> np.ndarray:
    """
    Generate a synthetic frame resembling a sewer pipe interior:
    radial vignette/gradient, pipe joints, and optional synthetic defect patterns.
    """
    # 1. Circular pipe vignette
    y, x = np.ogrid[:height, :width]
    center_y, center_x = height / 2, width / 2
    dist_from_center = np.sqrt((x - center_x) ** 2 + (y - center_y) ** 2)
    max_radius = np.sqrt(center_x**2 + center_y**2)

    # Base illumination drops towards distance
    intensity = 160 - (dist_from_center / max_radius) * 110 + brightness_offset
    intensity = np.clip(intensity, 10, 255).astype(np.uint8)

    # 3-channel BGR
    frame = cv2.merge([intensity, (intensity * 0.9).astype(np.uint8), (intensity * 0.8).astype(np.uint8)])

    # Draw circular joint rings
    cv2.circle(frame, (int(center_x), int(center_y)), int(max_radius * 0.4), (40, 45, 50), 2)
    cv2.circle(frame, (int(center_x), int(center_y)), int(max_radius * 0.7), (35, 40, 45), 3)

    # Optional synthetic defect: irregular dark line (simulated crack)
    if draw_crack:
        cx, cy = crack_pos
        points = np.array(
            [
                [cx - 30, cy - 15],
                [cx - 15, cy - 5],
                [cx, cy],
                [cx + 12, cy + 18],
                [cx + 25, cy + 35],
            ],
            dtype=np.int32,
        )
        cv2.polylines(frame, [points], isClosed=False, color=(15, 15, 20), thickness=3)

    # Optional synthetic debris: irregular blob at bottom
    if draw_debris:
        cv2.ellipse(frame, (int(center_x), int(height * 0.85)), (40, 15), 0, 0, 360, (25, 45, 55), -1)

    return frame


@pytest.fixture
def clean_video_path(tmp_path: Path) -> Path:
    """Create a short 15-frame video of a clean pipe with no defects."""
    video_file = tmp_path / "clean_pipe.mp4"
    fourcc = cv2.VideoWriter_fourcc(*"mp4v")
    out = cv2.VideoWriter(str(video_file), fourcc, 10.0, (320, 320))
    for _ in range(15):
        frame = generate_synthetic_pipe_frame(draw_crack=False, draw_debris=False)
        out.write(frame)
    out.release()
    return video_file


@pytest.fixture
def dark_video_path(tmp_path: Path) -> Path:
    """Create a short 15-frame low-brightness sewer video (<40 mean brightness)."""
    video_file = tmp_path / "dark_sewer.mp4"
    fourcc = cv2.VideoWriter_fourcc(*"mp4v")
    out = cv2.VideoWriter(str(video_file), fourcc, 10.0, (320, 320))
    for _ in range(15):
        # Force very dark frame to trigger CLAHE
        frame = generate_synthetic_pipe_frame(brightness_offset=-100, draw_crack=True)
        out.write(frame)
    out.release()
    return video_file


@pytest.fixture
def defect_video_path(tmp_path: Path) -> Path:
    """Create a 20-frame video with a moving synthetic defect."""
    video_file = tmp_path / "defect_pipe.mp4"
    fourcc = cv2.VideoWriter_fourcc(*"mp4v")
    out = cv2.VideoWriter(str(video_file), fourcc, 10.0, (320, 320))
    for i in range(20):
        # Move crack slightly across frames to test tracking
        pos = (140 + i * 2, 150 + i)
        frame = generate_synthetic_pipe_frame(draw_crack=True, crack_pos=pos)
        out.write(frame)
    out.release()
    return video_file


@pytest.fixture
def corrupt_video_path(tmp_path: Path) -> Path:
    """Create a corrupted video file with garbage bytes."""
    corrupt_file = tmp_path / "corrupt.mp4"
    corrupt_file.write_bytes(b"\x00\x00\x00\x18ftypmp42" + b"RANDOM_CORRUPTED_STREAM_DATA" * 50)
    return corrupt_file


@pytest.fixture
def text_file_path(tmp_path: Path) -> Path:
    """Create a text file masquerading with or without extension."""
    text_file = tmp_path / "invalid_input.txt"
    text_file.write_text("This is not a video file.")
    return text_file

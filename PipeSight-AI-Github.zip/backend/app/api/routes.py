"""
FastAPI route definitions for PipeSight AI inspection endpoints.
"""

from datetime import datetime, timezone
import logging
import os
from pathlib import Path
import re
import shutil
from typing import List
import uuid
import cv2
from fastapi import APIRouter, File, HTTPException, UploadFile, status
from fastapi.responses import FileResponse, RedirectResponse
import numpy as np

from app.config import settings
from app.schemas import (
    EvidenceItem,
    EvidenceListResponse,
    ImageInspectionResponse,
    InspectionReport,
    JobCreationResponse,
    JobStatus,
    JobStatusResponse,
    SystemInfoResponse,
)
from app.services.db_service import db_service
from app.services.storage_service import storage_service
from app.services.video_service import video_service
from app.services.vision_service import vision_service
from app.utils.image_quality import (
    compute_image_quality,
    enhance_frame_luminance,
)
from app.utils.video_utils import draw_inspection_overlay, validate_video_file

logger = logging.getLogger(__name__)

router = APIRouter()

JOB_ID_REGEX = re.compile(r"^[a-zA-Z0-9_\-]{8,64}$")


def _validate_job_id(job_id: str) -> str:
    cleaned = (job_id or "").strip()
    if not JOB_ID_REGEX.match(cleaned):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid job ID '{job_id}'. Must be alphanumeric with hyphens or underscores (8-64 chars).",
        )
    return cleaned


@router.get(
    "/info",
    response_model=SystemInfoResponse,
    summary="Get inspection system and model configuration",
)
def get_system_info():
    """
    Return model identity, classes, confidence threshold, and supported features.
    """
    return SystemInfoResponse(
        model_name="YOLO26s Sewer Inspection Model",
        class_names=vision_service.class_names,
        class_count=len(vision_service.class_names),
        confidence_threshold=settings.CONFIDENCE_THRESHOLD,
        iou_threshold=settings.IOU_THRESHOLD,
        frame_stride=settings.FRAME_STRIDE,
        max_processing_dim=settings.MAX_PROCESSING_DIM,
        supported_file_types=settings.ALLOWED_EXTENSIONS,
        supported_processing_modes=[
            "sequential_agentic_inspection",
            "cpu_frame_stride_sampling",
            "aspect_preserving_640_resize",
            "luminance_clahe_enhancement",
            "bytetrack_tracking",
            "single_image_test",
        ],
        storage_backend=settings.STORAGE_BACKEND,
        model_metric_map50=settings.MODEL_METRIC_MAP50,
        model_limitations_notice=settings.MODEL_LIMITATIONS_NOTICE,
        retention_hours=settings.RETENTION_HOURS,
        storage_notice=settings.STORAGE_NOTICE,
    )


@router.get(
    "/inspect/jobs",
    response_model=List[JobStatusResponse],
    summary="List recent inspection jobs",
)
def list_inspection_jobs(limit: int = 50):
    """
    Returns recent inspection jobs persisted in SQLite database.
    """
    return video_service.list_jobs(limit=min(limit, 100))


@router.post(
    "/inspect/video",
    response_model=JobCreationResponse,
    status_code=status.HTTP_202_ACCEPTED,
    summary="Submit sewer inspection video for agentic analysis",
)
async def inspect_video(file: UploadFile = File(...)):
    """
    Accepts video upload, validates codecs and headers with OpenCV 5, creates
    an asynchronous inspection job, and starts the Agentic Vision pipeline.
    """
    # 0. Opportunistic cleanup of expired jobs (> retention_hours old)
    try:
        db_service.cleanup_old_jobs(retention_hours=settings.RETENTION_HOURS)
    except Exception as exc:
        logger.warning(f"Storage cleanup notice: {exc}")

    # 1. Pre-check persistent disk space
    storage_root = Path(settings.LOCAL_STORAGE_DIR).resolve()
    storage_root.mkdir(parents=True, exist_ok=True)
    try:
        _, _, free_bytes = shutil.disk_usage(storage_root)
        free_mb = free_bytes / (1024 * 1024)
        if free_mb < settings.MIN_FREE_DISK_MB:
            raise HTTPException(
                status_code=status.HTTP_507_INSUFFICIENT_STORAGE,
                detail=(
                    f"Insufficient server storage ({free_mb:.1f} MB available). "
                    f"PipeSight AI requires at least {settings.MIN_FREE_DISK_MB} MB free disk space to process video."
                ),
            )
    except OSError as e:
        logger.warning(f"Could not verify disk space: {e}")

    # 2. Validate file extension
    ext = Path(file.filename or "").suffix.lower()
    if ext not in settings.ALLOWED_EXTENSIONS:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=(
                f"Unsupported file extension '{ext}'. Allowed video formats: "
                f"{', '.join(settings.ALLOWED_EXTENSIONS)}"
            ),
        )

    # 3. Assign unique job ID and secure file path: backend/storage/jobs/<job_id>/input_video.mp4
    job_id = str(uuid.uuid4())
    upload_dir = storage_root / "jobs" / job_id
    upload_dir.mkdir(parents=True, exist_ok=True)
    temp_source_path = upload_dir / "input_video.mp4"

    # 4. Stream upload chunks to disk to prevent OOM
    total_bytes = 0
    max_bytes = settings.MAX_UPLOAD_SIZE_MB * 1024 * 1024
    with open(temp_source_path, "wb") as f_out:
        while chunk := await file.read(1024 * 1024):  # 1 MB chunks
            total_bytes += len(chunk)
            if total_bytes > max_bytes:
                temp_source_path.unlink(missing_ok=True)
                raise HTTPException(
                    status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
                    detail=f"Video exceeds maximum upload limit of {settings.MAX_UPLOAD_SIZE_MB} MB.",
                )
            f_out.write(chunk)

    # 5. Rigorous OpenCV 5 validation (never trust extension alone)
    try:
        video_meta = validate_video_file(str(temp_source_path), max_size_bytes=max_bytes)
    except ValueError as ve:
        temp_source_path.unlink(missing_ok=True)
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid video file: {str(ve)}",
        )

    # 6. Register persistent job status
    video_service.register_job(job_id, file.filename, total_frames=video_meta.total_frames)

    # 7. Kick off background processing thread
    video_service.start_background_processing(
        job_id=job_id,
        video_source_path=str(temp_source_path),
        original_filename=file.filename,
    )

    now_iso = datetime.now(timezone.utc).isoformat()
    return JobCreationResponse(
        job_id=job_id,
        status=JobStatus.QUEUED,
        filename=file.filename,
        file_size_bytes=total_bytes,
        message="Video accepted and queued for Agentic Vision inspection.",
        created_at=now_iso,
        status_url=f"{settings.API_PREFIX}/inspect/{job_id}",
    )


@router.get(
    "/inspect/{job_id}",
    response_model=JobStatusResponse,
    summary="Get video inspection progress and status",
)
def get_inspection_status(job_id: str):
    """
    Poll job status, progress percentage, current frame, and artifact links.
    """
    clean_id = _validate_job_id(job_id)
    job = video_service.get_job(clean_id)
    if not job:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Inspection job '{clean_id}' not found.",
        )
    return job


@router.get(
    "/inspect/{job_id}/report",
    response_model=InspectionReport,
    summary="Get complete structured JSON inspection report",
)
def get_inspection_report(job_id: str):
    """
    Returns the comprehensive JSON diagnostic report with defect events,
    quality metrics, agent trace actions, and limitations.
    """
    clean_id = _validate_job_id(job_id)
    job = video_service.get_job(clean_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found.")

    if job.status == JobStatus.FAILED:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Inspection failed: {job.error_message}",
        )

    if job.status != JobStatus.COMPLETED:
        raise HTTPException(
            status_code=status.HTTP_202_ACCEPTED,
            detail=f"Inspection is still {job.status.value} ({job.progress_pct}%). Please check back shortly.",
        )

    report = video_service.get_report(clean_id)
    if not report:
        raise HTTPException(status_code=404, detail="Inspection report not found.")

    return report


@router.get(
    "/inspect/{job_id}/video",
    summary="Retrieve or stream the annotated inspection video",
)
def get_annotated_video(job_id: str):
    """
    Download or stream the OpenCV 5 annotated inspection MP4 video.
    """
    clean_id = _validate_job_id(job_id)
    job = video_service.get_job(clean_id)
    if not job or job.status != JobStatus.COMPLETED:
        raise HTTPException(status_code=404, detail="Annotated video not available or job incomplete.")

    if settings.STORAGE_BACKEND.lower() == "s3":
        presigned_url = storage_service.get_url(clean_id, "annotated_video.mp4")
        return RedirectResponse(url=presigned_url)

    video_path = storage_service.get_local_path(clean_id, "annotated_video.mp4")
    if not video_path or not os.path.isfile(video_path):
        raise HTTPException(status_code=404, detail="Annotated video file not found on disk.")

    return FileResponse(
        video_path,
        media_type="video/mp4",
        filename=f"annotated_{clean_id}.mp4",
    )


@router.get(
    "/inspect/{job_id}/evidence",
    response_model=EvidenceListResponse,
    summary="List all representative defect evidence images",
)
def get_evidence_images(job_id: str):
    """
    Return list of evidence images for confirmed defect tracks.
    """
    clean_id = _validate_job_id(job_id)
    job = video_service.get_job(clean_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found.")

    evidence_items = video_service.get_evidence(clean_id)
    return EvidenceListResponse(
        job_id=clean_id,
        count=len(evidence_items),
        evidence_items=evidence_items,
    )


@router.get(
    "/inspect/{job_id}/evidence/{filename}",
    summary="Download an individual evidence image",
)
def get_evidence_file(job_id: str, filename: str):
    """
    Download a specific evidence image artifact.
    """
    clean_id = _validate_job_id(job_id)
    if settings.STORAGE_BACKEND.lower() == "s3":
        presigned_url = storage_service.get_url(clean_id, filename)
        return RedirectResponse(url=presigned_url)

    file_path = storage_service.get_local_path(clean_id, filename)
    if not file_path or not os.path.isfile(file_path):
        raise HTTPException(status_code=404, detail=f"Evidence image '{filename}' not found.")

    return FileResponse(file_path, media_type="image/jpeg", filename=Path(filename).name)


@router.get(
    "/inspect/{job_id}/report.pdf",
    summary="Download formal PDF inspection report",
)
def get_pdf_report(job_id: str):
    """
    Download the generated PDF report with tables, agent traces, and disclosures.
    """
    clean_id = _validate_job_id(job_id)
    job = video_service.get_job(clean_id)
    if not job or job.status != JobStatus.COMPLETED:
        raise HTTPException(status_code=404, detail="PDF report not ready or job incomplete.")

    if settings.STORAGE_BACKEND.lower() == "s3":
        presigned_url = storage_service.get_url(clean_id, "report.pdf")
        return RedirectResponse(url=presigned_url)

    pdf_path = storage_service.get_local_path(clean_id, "report.pdf")
    if not pdf_path or not os.path.isfile(pdf_path):
        raise HTTPException(status_code=404, detail="PDF report file not found on disk.")

    return FileResponse(
        pdf_path,
        media_type="application/pdf",
        filename=f"PipeSight_Report_{clean_id}.pdf",
    )


@router.get(
    "/inspect/{job_id}/zip",
    summary="Download complete ZIP bundle of inspection results",
)
def get_results_zip(job_id: str):
    """
    Download a comprehensive ZIP bundle containing annotated video, PDF report,
    JSON report, agent trace, and all captured defect snapshots.
    """
    clean_id = _validate_job_id(job_id)
    job = video_service.get_job(clean_id)
    if not job:
        raise HTTPException(status_code=404, detail=f"Job '{clean_id}' not found.")

    if job.status != JobStatus.COMPLETED:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Inspection results package is not ready (job status: {job.status.value}).",
        )

    zip_path = storage_service.get_local_path(clean_id, "results.zip")
    if not zip_path or not os.path.isfile(zip_path):
        # Assemble package on demand if missing
        zip_path = storage_service.create_results_zip(clean_id)

    if not zip_path or not os.path.isfile(zip_path):
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to generate results archive for download.",
        )

    return FileResponse(
        zip_path,
        media_type="application/zip",
        filename=f"PipeSight_Results_{clean_id}.zip",
    )


@router.get(
    "/inspect/{job_id}/trace",
    summary="Download raw Agentic Vision execution trace JSON",
)
def get_agent_trace(job_id: str):
    """
    Download the detailed Agentic Vision perception-decision-action log.
    """
    clean_id = _validate_job_id(job_id)
    job = video_service.get_job(clean_id)
    if not job:
        raise HTTPException(status_code=404, detail=f"Job '{clean_id}' not found.")

    trace_path = storage_service.get_local_path(clean_id, "agent_trace.json")
    if not trace_path or not os.path.isfile(trace_path):
        raise HTTPException(status_code=404, detail="Agent trace log not available for this job.")

    return FileResponse(
        trace_path,
        media_type="application/json",
        filename=f"agent_trace_{clean_id}.json",
    )


@router.post(
    "/inspect/image",
    response_model=ImageInspectionResponse,
    summary="Single-image inspection testing endpoint",
)
async def inspect_single_image(file: UploadFile = File(...)):
    """
    Test endpoint for a single sewer pipe photo.
    Performs image quality analysis, applies CLAHE enhancement if low-light,
    runs YOLO26s detection, and returns structured findings.
    """
    content = await file.read()
    np_arr = np.frombuffer(content, np.uint8)
    frame = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)

    if frame is None or frame.size == 0:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Failed to decode image file. Ensure valid JPG/PNG format.",
        )

    # 1. Quality evaluation
    quality = compute_image_quality(frame)

    # 2. Enhancement decision
    decision = "CONTINUE"
    action = "direct_inference"
    enhanced_used = False

    if quality.is_low_quality and settings.ENABLE_CLAHE_ENHANCEMENT:
        enhanced_frame, _ = enhance_frame_luminance(frame)
        frame_for_infer = enhanced_frame
        decision = "ENHANCE_AND_RECHECK"
        action = "applied_clahe_luminance"
        enhanced_used = True
    else:
        frame_for_infer = frame

    # 3. Run YOLO inference
    detections = vision_service.detect_single(frame_for_infer)

    # 4. Render overlay
    annotated = draw_inspection_overlay(
        frame=frame_for_infer,
        detections=detections,
        timestamp_sec=0.0,
        frame_idx=0,
        quality=quality,
        enhanced=enhanced_used,
    )

    # Save to storage for quick reference
    test_id = str(uuid.uuid4())[:8]
    success, enc = cv2.imencode(".jpg", annotated)
    annotated_url = None
    if success:
        storage_service.save_bytes(
            job_id="single_images",
            filename=f"annotated_{test_id}.jpg",
            data=enc.tobytes(),
            content_type="image/jpeg",
        )
        annotated_url = storage_service.get_url("single_images", f"annotated_{test_id}.jpg")

    return ImageInspectionResponse(
        filename=file.filename,
        quality_metrics=quality,
        agent_decision=decision,
        agent_action=action,
        detections=detections,
        annotated_image_url=annotated_url,
        notice=settings.MODEL_LIMITATIONS_NOTICE,
    )

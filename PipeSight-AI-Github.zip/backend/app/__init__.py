"""
PipeSight AI - Agentic Sewer Inspection Backend
Built with OpenCV 5, Ultralytics YOLO26s, and ByteTrack
"""

__version__ = "1.0.0"

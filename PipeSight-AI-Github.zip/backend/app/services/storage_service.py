"""
Storage abstraction supporting Local Disk and Amazon S3.
"""

from abc import ABC, abstractmethod
import logging
import os
from pathlib import Path
from typing import List, Optional
import boto3
from botocore.exceptions import ClientError

from app.config import settings

logger = logging.getLogger(__name__)


import re
import shutil
import zipfile

JOB_ID_PATTERN = re.compile(r"^[a-zA-Z0-9_-]{8,64}$")


class StorageService(ABC):
    """Abstract base class for storage adapters."""

    @abstractmethod
    def save_bytes(self, job_id: str, filename: str, data: bytes, content_type: str = "application/octet-stream") -> str:
        """Save raw bytes to storage. Returns the key or relative path."""
        pass

    @abstractmethod
    def save_file(self, job_id: str, filename: str, source_path: str, content_type: str = "application/octet-stream") -> str:
        """Upload or copy an existing local file to storage. Returns key or relative path."""
        pass

    @abstractmethod
    def get_url(self, job_id: str, filename: str, expires_in: int = 3600) -> str:
        """Get an accessible download URL (presigned if S3, API route if local)."""
        pass

    @abstractmethod
    def get_local_path(self, job_id: str, filename: str) -> Optional[str]:
        """Return local file system path if available (or None if strictly remote)."""
        pass

    @abstractmethod
    def file_exists(self, job_id: str, filename: str) -> bool:
        """Check if file exists."""
        pass

    @abstractmethod
    def list_files(self, job_id: str, prefix: str = "") -> List[str]:
        """List filenames for a given inspection job."""
        pass

    @abstractmethod
    def create_results_zip(self, job_id: str) -> Optional[str]:
        """Bundle inspection artifacts (video, pdf, json, trace, evidence) into results.zip."""
        pass


class LocalStorageService(StorageService):
    """
    Local filesystem storage adapter organizing inspection files under:
    backend/storage/jobs/<job_id>/
      ├── input_video.mp4
      ├── annotated_video.mp4
      ├── evidence/
      │   └── evidence_track_*.jpg
      ├── report.json
      ├── report.pdf
      ├── agent_trace.json
      └── results.zip
    """

    def __init__(self, base_dir: str = None):
        self.base_dir = Path(base_dir or settings.LOCAL_STORAGE_DIR).resolve()
        self.jobs_dir = self.base_dir / "jobs"
        self.jobs_dir.mkdir(parents=True, exist_ok=True)

    def _validate_job_id(self, job_id: str) -> str:
        clean = job_id.strip()
        if not JOB_ID_PATTERN.match(clean):
            raise ValueError(f"Invalid job ID '{clean}'. Must be alphanumeric with hyphens/underscores.")
        return clean

    def _get_job_dir(self, job_id: str) -> Path:
        valid_id = self._validate_job_id(job_id)
        job_dir = (self.jobs_dir / valid_id).resolve()
        # Security: prevent path traversal attacks
        if not str(job_dir).startswith(str(self.jobs_dir)):
            raise ValueError("Security violation: path traversal detected.")
        job_dir.mkdir(parents=True, exist_ok=True)
        (job_dir / "evidence").mkdir(parents=True, exist_ok=True)
        return job_dir

    def _resolve_dest(self, job_dir: Path, filename: str) -> Path:
        # Organize evidence snapshots into evidence/ subfolder
        clean_name = Path(filename).name
        if filename.startswith("evidence") or clean_name.startswith("evidence_"):
            dest = job_dir / "evidence" / clean_name
        else:
            dest = job_dir / clean_name
        if not str(dest.resolve()).startswith(str(job_dir)):
            raise ValueError("Security violation: target path escapes job directory.")
        return dest

    def save_bytes(self, job_id: str, filename: str, data: bytes, content_type: str = "application/octet-stream") -> str:
        job_dir = self._get_job_dir(job_id)
        dest = self._resolve_dest(job_dir, filename)
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(data)
        rel = dest.relative_to(self.jobs_dir)
        return str(rel).replace("\\", "/")

    def save_file(self, job_id: str, filename: str, source_path: str, content_type: str = "application/octet-stream") -> str:
        job_dir = self._get_job_dir(job_id)
        dest = self._resolve_dest(job_dir, filename)
        dest.parent.mkdir(parents=True, exist_ok=True)
        src_resolved = str(Path(source_path).resolve())
        if src_resolved != str(dest.resolve()):
            shutil.copyfile(source_path, dest)
        rel = dest.relative_to(self.jobs_dir)
        return str(rel).replace("\\", "/")

    def get_url(self, job_id: str, filename: str, expires_in: int = 3600) -> str:
        valid_id = self._validate_job_id(job_id)
        clean_name = Path(filename).name
        if clean_name.endswith(".zip") or clean_name == "results.zip":
            return f"{settings.API_PREFIX}/inspect/{valid_id}/zip"
        elif clean_name.endswith(".pdf"):
            return f"{settings.API_PREFIX}/inspect/{valid_id}/report.pdf"
        elif clean_name.endswith(".mp4"):
            return f"{settings.API_PREFIX}/inspect/{valid_id}/video"
        elif clean_name.startswith("evidence") or clean_name.endswith(".jpg"):
            return f"{settings.API_PREFIX}/inspect/{valid_id}/evidence/{clean_name}"
        return f"{settings.API_PREFIX}/inspect/{valid_id}/report"

    def get_local_path(self, job_id: str, filename: str) -> Optional[str]:
        job_dir = self._get_job_dir(job_id)
        clean_name = Path(filename).name
        # Check root of job directory
        candidate_root = job_dir / clean_name
        if candidate_root.is_file():
            return str(candidate_root)
        # Check evidence subdirectory
        candidate_ev = job_dir / "evidence" / clean_name
        if candidate_ev.is_file():
            return str(candidate_ev)
        return None

    def file_exists(self, job_id: str, filename: str) -> bool:
        return self.get_local_path(job_id, filename) is not None

    def list_files(self, job_id: str, prefix: str = "") -> List[str]:
        job_dir = self._get_job_dir(job_id)
        if not job_dir.exists():
            return []
        files = []
        for p in job_dir.rglob(f"{prefix}*"):
            if p.is_file():
                files.append(str(p.relative_to(job_dir)).replace("\\", "/"))
        return files

    def create_results_zip(self, job_id: str) -> Optional[str]:
        """
        Creates a self-contained results.zip packaging all job artifacts:
        - annotated_video.mp4
        - report.pdf
        - report.json
        - agent_trace.json
        - evidence/ folder
        """
        job_dir = self._get_job_dir(job_id)
        zip_path = job_dir / "results.zip"
        
        try:
            with zipfile.ZipFile(str(zip_path), "w", zipfile.ZIP_DEFLATED) as zf:
                # Add core artifacts
                for artifact_name in ["annotated_video.mp4", "report.pdf", "report.json", "agent_trace.json"]:
                    f_path = job_dir / artifact_name
                    if f_path.is_file():
                        zf.write(str(f_path), arcname=artifact_name)

                # Add evidence folder
                ev_dir = job_dir / "evidence"
                if ev_dir.is_dir():
                    for ev_file in ev_dir.glob("*.jpg"):
                        zf.write(str(ev_file), arcname=f"evidence/{ev_file.name}")

            return str(zip_path) if zip_path.is_file() else None
        except Exception as e:
            logger.error(f"Failed to create results.zip for job {job_id}: {e}")
            return None


class S3StorageService(StorageService):
    """
    Amazon S3 storage adapter.
    Uses AWS IAM role or credentials to store videos, reports, and evidence.
    Generates time-limited presigned URLs for secure browser access.
    """

    def __init__(self, bucket_name: str = None, region_name: str = None):
        self.bucket = bucket_name or settings.S3_BUCKET_NAME
        self.region = region_name or settings.AWS_REGION
        self.s3_client = boto3.client("s3", region_name=self.region)
        self.local_cache_dir = Path(settings.LOCAL_STORAGE_DIR) / "_s3_temp"
        self.local_cache_dir.mkdir(parents=True, exist_ok=True)

    def _s3_key(self, job_id: str, filename: str) -> str:
        return f"inspections/{job_id}/{filename}"

    def save_bytes(self, job_id: str, filename: str, data: bytes, content_type: str = "application/octet-stream") -> str:
        key = self._s3_key(job_id, filename)
        try:
            self.s3_client.put_object(
                Bucket=self.bucket,
                Key=key,
                Body=data,
                ContentType=content_type,
            )
            return key
        except ClientError as e:
            logger.error(f"S3 put_object failed for key {key}: {e}")
            raise

    def save_file(self, job_id: str, filename: str, source_path: str, content_type: str = "application/octet-stream") -> str:
        key = self._s3_key(job_id, filename)
        try:
            self.s3_client.upload_file(
                Filename=source_path,
                Bucket=self.bucket,
                Key=key,
                ExtraArgs={"ContentType": content_type},
            )
            return key
        except ClientError as e:
            logger.error(f"S3 upload_file failed for key {key}: {e}")
            raise

    def get_url(self, job_id: str, filename: str, expires_in: int = 3600) -> str:
        key = self._s3_key(job_id, filename)
        try:
            url = self.s3_client.generate_presigned_url(
                ClientMethod="get_object",
                Params={"Bucket": self.bucket, "Key": key},
                ExpiresIn=expires_in,
            )
            return url
        except ClientError as e:
            logger.error(f"Failed to generate presigned URL for key {key}: {e}")
            return f"s3://{self.bucket}/{key}"

    def get_local_path(self, job_id: str, filename: str) -> Optional[str]:
        # Download from S3 to temporary cache if local path is requested
        key = self._s3_key(job_id, filename)
        cache_path = self.local_cache_dir / job_id / filename
        cache_path.parent.mkdir(parents=True, exist_ok=True)
        if cache_path.exists():
            return str(cache_path)
        try:
            self.s3_client.download_file(self.bucket, key, str(cache_path))
            return str(cache_path)
        except ClientError:
            return None

    def file_exists(self, job_id: str, filename: str) -> bool:
        key = self._s3_key(job_id, filename)
        try:
            self.s3_client.head_object(Bucket=self.bucket, Key=key)
            return True
        except ClientError:
            return False

    def list_files(self, job_id: str, prefix: str = "") -> List[str]:
        s3_prefix = f"inspections/{job_id}/{prefix}"
        try:
            response = self.s3_client.list_objects_v2(Bucket=self.bucket, Prefix=s3_prefix)
            keys = [item["Key"].split("/")[-1] for item in response.get("Contents", [])]
            return keys
        except ClientError as e:
            logger.error(f"S3 list_objects_v2 failed: {e}")
            return []

    def create_results_zip(self, job_id: str) -> Optional[str]:
        return None


def get_storage_service() -> StorageService:
    """Factory to retrieve configured storage adapter."""
    if settings.STORAGE_BACKEND.lower() == "s3":
        return S3StorageService()
    return LocalStorageService()


storage_service = get_storage_service()

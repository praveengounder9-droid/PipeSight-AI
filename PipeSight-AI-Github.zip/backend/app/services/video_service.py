"""
Video Processing Service coordinating OpenCV 5 video decode, Agentic Vision loop,
ByteTrack tracking, evidence extraction, and report generation.
"""

from datetime import datetime, timezone
import logging
import os
from pathlib import Path
import threading
import time
from typing import Dict, List, Optional
import cv2
import numpy as np

import json
from app.config import settings
from app.schemas import (
    EvidenceItem,
    InspectionReport,
    JobStatus,
    JobStatusResponse,
    PerformanceMetrics,
    QualityMetrics,
    TrackEvent,
    VideoMetadata,
)
from app.services.agent_service import AgentVisionController
from app.services.db_service import db_service
from app.services.report_service import report_service
from app.services.storage_service import storage_service
from app.services.tracking_service import TrackingService
from app.services.vision_service import vision_service
from app.utils.video_utils import (
    compute_aspect_preserving_dimensions,
    create_video_writer,
    draw_inspection_overlay,
    resize_frame_if_needed,
    validate_video_file,
)

logger = logging.getLogger(__name__)


class VideoProcessingService:
    """
    Coordinates asynchronous sewer inspection video analysis.
    Uses SQLite database for persistent job recovery across server restarts,
    with an in-memory thread-safe cache for real-time progress polling.
    """

    def __init__(self):
        self.jobs: Dict[str, JobStatusResponse] = {}
        self.reports: Dict[str, InspectionReport] = {}
        self.evidence_registry: Dict[str, List[EvidenceItem]] = {}
        self._lock = threading.Lock()

    def get_job(self, job_id: str) -> Optional[JobStatusResponse]:
        with self._lock:
            if job_id in self.jobs:
                return self.jobs[job_id]
        # Query persistent SQLite database
        persisted = db_service.get_job(job_id)
        if persisted:
            with self._lock:
                self.jobs[job_id] = persisted
        return persisted

    def get_report(self, job_id: str) -> Optional[InspectionReport]:
        with self._lock:
            if job_id in self.reports:
                return self.reports[job_id]
        persisted = db_service.get_report(job_id)
        if persisted:
            with self._lock:
                self.reports[job_id] = persisted
        return persisted

    def get_evidence(self, job_id: str) -> List[EvidenceItem]:
        with self._lock:
            if job_id in self.evidence_registry and self.evidence_registry[job_id]:
                return self.evidence_registry[job_id]
        persisted = db_service.get_evidence(job_id)
        if persisted:
            with self._lock:
                self.evidence_registry[job_id] = persisted
        return persisted or []

    def list_jobs(self, limit: int = 50) -> List[JobStatusResponse]:
        return db_service.list_jobs(limit=limit)

    def register_job(self, job_id: str, filename: str, total_frames: int = 0) -> JobStatusResponse:
        now_str = datetime.now(timezone.utc).isoformat()
        job = JobStatusResponse(
            job_id=job_id,
            status=JobStatus.QUEUED,
            progress_pct=0.0,
            current_frame=0,
            total_frames=total_frames,
            frames_processed=0,
            frames_skipped=0,
            frame_stride=settings.FRAME_STRIDE,
            processing_fps=None,
            elapsed_sec=0.0,
            estimated_time_remaining_sec=None,
            error_message=None,
            report_url=None,
            video_url=None,
            pdf_url=None,
            updated_at=now_str,
        )
        with self._lock:
            self.jobs[job_id] = job
        db_service.save_job(job)
        return job

    def start_background_processing(
        self,
        job_id: str,
        video_source_path: str,
        original_filename: str,
    ) -> None:
        """Launch video processing in a background worker thread."""
        thread = threading.Thread(
            target=self._process_video_job,
            args=(job_id, video_source_path, original_filename),
            daemon=True,
        )
        thread.start()

    def _process_video_job(
        self,
        job_id: str,
        video_source_path: str,
        original_filename: str,
    ) -> None:
        overall_start_time = time.perf_counter()
        created_at_utc = datetime.now(timezone.utc).isoformat()
        logger.info(f"Starting inspection job {job_id} for {original_filename}")

        # Update job to processing
        with self._lock:
            if job_id in self.jobs:
                self.jobs[job_id].status = JobStatus.PROCESSING
                self.jobs[job_id].updated_at = datetime.now(timezone.utc).isoformat()

        temp_output_video_path = Path(settings.LOCAL_STORAGE_DIR) / job_id / "annotated_video.mp4"
        temp_output_video_path.parent.mkdir(parents=True, exist_ok=True)

        writer: Optional[cv2.VideoWriter] = None
        cap: Optional[cv2.VideoCapture] = None

        try:
            # 1. Validate video input with OpenCV 5
            video_meta = validate_video_file(video_source_path, max_size_bytes=settings.MAX_UPLOAD_SIZE_MB * 1024 * 1024)
            video_meta.filename = original_filename

            # Save input video to standardized job directory: storage/jobs/<job_id>/input_video.mp4
            storage_service.save_file(job_id, "input_video.mp4", str(video_source_path))

            # Compute aspect-preserving processing dimensions (e.g. 1920x1080 -> 640x360, 480x480 -> 480x480)
            proc_w, proc_h, _ = compute_aspect_preserving_dimensions(
                orig_w=video_meta.width,
                orig_h=video_meta.height,
                max_dim=settings.MAX_PROCESSING_DIM,
            )

            with self._lock:
                if job_id in self.jobs:
                    self.jobs[job_id].total_frames = video_meta.total_frames
                    self.jobs[job_id].frame_stride = settings.FRAME_STRIDE
                    db_service.save_job(self.jobs[job_id])

            # 2. Reset ByteTrack tracker state to prevent track ID pollution between jobs
            vision_service.reset_tracker()

            # 3. Instantiate Agentic Controller and Tracking Service
            agent = AgentVisionController(job_id=job_id, vision_svc=vision_service)
            tracker = TrackingService(job_id=job_id)

            # 4. Open video capture and output writer using processing resolution
            cap = cv2.VideoCapture(str(video_source_path))
            writer = create_video_writer(
                str(temp_output_video_path),
                fps=video_meta.fps,
                width=proc_w,
                height=proc_h,
            )

            frame_idx = 0
            processed_count = 0
            skipped_count = 0
            raw_detections_total = 0
            low_quality_count = 0
            enhanced_count = 0

            time_decoding = 0.0
            time_resizing = 0.0
            time_agent = 0.0
            time_tracking = 0.0
            time_overlay_and_write = 0.0

            # 5. Process frames sequentially
            while cap.isOpened():
                t_decode_start = time.perf_counter()
                ret, frame = cap.read()
                time_decoding += (time.perf_counter() - t_decode_start)

                if not ret or frame is None:
                    break

                # Resize frame if needed to fit within max 640x640 bounding box using cv2.INTER_AREA
                t_resize_start = time.perf_counter()
                proc_frame = resize_frame_if_needed(frame, target_w=proc_w, target_h=proc_h)
                time_resizing += (time.perf_counter() - t_resize_start)

                timestamp_sec = frame_idx / video_meta.fps

                # Frame sampling: run inference only on every Nth frame (FRAME_STRIDE)
                is_sampled = (frame_idx % settings.FRAME_STRIDE == 0)

                if is_sampled:
                    # Run Agentic Vision perception-decision-action loop
                    t_agent_start = time.perf_counter()
                    rendered_frame, detections, quality, was_enhanced = agent.step(
                        frame=proc_frame,
                        frame_idx=frame_idx,
                        timestamp_sec=timestamp_sec,
                    )
                    time_agent += (time.perf_counter() - t_agent_start)

                    if quality.is_low_quality:
                        low_quality_count += 1
                    if was_enhanced:
                        enhanced_count += 1
                    raw_detections_total += len(detections)

                    # Update tracking
                    t_track_start = time.perf_counter()
                    tracker.add_detections(detections, frame=rendered_frame)
                    time_tracking += (time.perf_counter() - t_track_start)

                    # Render OpenCV 5 inspection HUD overlay
                    t_overlay_start = time.perf_counter()
                    annotated = draw_inspection_overlay(
                        frame=rendered_frame,
                        detections=detections,
                        timestamp_sec=timestamp_sec,
                        frame_idx=frame_idx,
                        quality=quality,
                        enhanced=was_enhanced,
                        is_skipped=False,
                    )
                    writer.write(annotated)
                    time_overlay_and_write += (time.perf_counter() - t_overlay_start)

                    processed_count += 1
                else:
                    # Skipped frame: render with frame-skipped indicator to preserve complete playback sync
                    t_overlay_start = time.perf_counter()
                    annotated = draw_inspection_overlay(
                        frame=proc_frame,
                        detections=[],
                        timestamp_sec=timestamp_sec,
                        frame_idx=frame_idx,
                        quality=None,
                        enhanced=False,
                        is_skipped=True,
                    )
                    writer.write(annotated)
                    time_overlay_and_write += (time.perf_counter() - t_overlay_start)

                    skipped_count += 1

                frame_idx += 1

                # Update progress periodically
                if frame_idx % 10 == 0 or frame_idx == video_meta.total_frames:
                    elapsed = time.perf_counter() - overall_start_time
                    progress = min(99.0, round((frame_idx / max(1, video_meta.total_frames)) * 100, 1))
                    remaining = (elapsed / max(1, frame_idx)) * (video_meta.total_frames - frame_idx)
                    cur_fps = round(frame_idx / max(0.001, elapsed), 1)

                    with self._lock:
                        if job_id in self.jobs:
                            self.jobs[job_id].progress_pct = progress
                            self.jobs[job_id].current_frame = frame_idx
                            self.jobs[job_id].frames_processed = processed_count
                            self.jobs[job_id].frames_skipped = skipped_count
                            self.jobs[job_id].processing_fps = cur_fps
                            self.jobs[job_id].elapsed_sec = round(elapsed, 1)
                            self.jobs[job_id].estimated_time_remaining_sec = round(remaining, 1)
                            self.jobs[job_id].updated_at = datetime.now(timezone.utc).isoformat()
                            if frame_idx % 30 == 0 or frame_idx == video_meta.total_frames:
                                db_service.save_job(self.jobs[job_id])

            # Release video capture and writer before verification
            if cap is not None:
                cap.release()
                cap = None
            if writer is not None:
                writer.release()
                writer = None

            video_meta.processed_frames = processed_count

            # 6. Verify annotated video was created and can be opened
            verify_cap = cv2.VideoCapture(str(temp_output_video_path))
            if not verify_cap.isOpened():
                raise RuntimeError("Generated output video could not be reopened for verification.")
            verify_cap.release()

            # Save annotated video to configured storage
            storage_service.save_file(
                job_id=job_id,
                filename="annotated_video.mp4",
                source_path=str(temp_output_video_path),
                content_type="video/mp4",
            )

            # 7. Aggregate unique defect-track events and extract evidence
            t_artifacts_start = time.perf_counter()
            events = tracker.aggregate_events()

            evidence_items: List[EvidenceItem] = []
            evidence_image_local_paths: Dict[int, str] = {}
            evidence_images_info: List[Dict[str, any]] = []

            for ev in events:
                rep_data = tracker.get_representative_frame(ev.track_id)
                if rep_data:
                    rep_frame, rep_box = rep_data
                    ev_annotated = draw_inspection_overlay(
                        frame=rep_frame,
                        detections=[rep_box],
                        timestamp_sec=rep_box.timestamp_sec,
                        frame_idx=rep_box.frame_idx,
                        enhanced=rep_box.enhanced,
                    )
                    evidence_filename = f"evidence_track_{ev.track_id}.jpg"
                    success, enc_img = cv2.imencode(".jpg", ev_annotated, [cv2.IMWRITE_JPEG_QUALITY, 92])
                    if success:
                        img_bytes = enc_img.tobytes()
                        key = storage_service.save_bytes(
                            job_id=job_id,
                            filename=evidence_filename,
                            data=img_bytes,
                            content_type="image/jpeg",
                        )
                        url = storage_service.get_url(job_id, evidence_filename)
                        ev.evidence_image_key = key
                        ev.evidence_image_url = url

                        local_path = storage_service.get_local_path(job_id, evidence_filename)
                        if local_path:
                            evidence_image_local_paths[ev.track_id] = local_path

                        item = EvidenceItem(
                            evidence_id=f"ev_{job_id}_{ev.track_id}",
                            track_id=ev.track_id,
                            class_name=ev.class_name,
                            confidence=ev.peak_confidence,
                            frame_idx=ev.representative_frame_idx,
                            timestamp_sec=ev.representative_timestamp_sec,
                            url=url,
                            key=key,
                        )
                        evidence_items.append(item)
                        evidence_images_info.append(item.model_dump())

            with self._lock:
                self.evidence_registry[job_id] = evidence_items

            # 8. Compute final performance metrics
            time_artifacts = time.perf_counter() - t_artifacts_start
            actual_processing_duration = time.perf_counter() - overall_start_time
            overall_fps = round(frame_idx / max(0.001, actual_processing_duration), 2)

            perf_metrics = PerformanceMetrics(
                original_resolution=(video_meta.width, video_meta.height),
                processing_resolution=(proc_w, proc_h),
                fps=video_meta.fps,
                total_source_frames=frame_idx,
                frames_processed=processed_count,
                frames_skipped=skipped_count,
                frame_stride=settings.FRAME_STRIDE,
                confidence_threshold=settings.CONFIDENCE_THRESHOLD,
                video_duration_sec=round(video_meta.duration_sec, 2),
                actual_processing_duration_sec=round(actual_processing_duration, 2),
                processing_fps=overall_fps,
                time_breakdown_sec={
                    "decoding_sec": round(time_decoding, 3),
                    "resizing_sec": round(time_resizing, 3),
                    "agent_inspection_and_inference_sec": round(time_agent, 3),
                    "tracking_association_sec": round(time_tracking, 3),
                    "overlay_and_encoding_sec": round(time_overlay_and_write, 3),
                    "report_and_artifacts_sec": round(time_artifacts, 3),
                },
                enhancement_retries=agent.enhancement_retries_count,
                candidate_defect_events_count=len(events),
                processing_limitations=[
                    f"Frame sampling stride={settings.FRAME_STRIDE} active. Skipped frames were not run through inference.",
                    f"Aspect-preserving resize to max {settings.MAX_PROCESSING_DIM}px applied ({video_meta.width}x{video_meta.height} -> {proc_w}x{proc_h}).",
                    "Track events represent candidate occurrences; physical operator validation is required.",
                ],
            )

            # 9. Build structured JSON report
            agent_summary = agent.get_summary()
            report = report_service.build_json_report(
                job_id=job_id,
                created_at_utc=created_at_utc,
                model_name="YOLO26s Sewer Defect Detector",
                class_names=vision_service.class_names,
                device=vision_service.device,
                video_stats=video_meta,
                defect_events=events,
                agent_summary=agent_summary,
                low_quality_count=low_quality_count,
                enhanced_count=enhanced_count,
                raw_detections_count=raw_detections_total,
                evidence_images_info=evidence_images_info,
                performance_metrics=perf_metrics,
            )

            # 10. Generate PDF Report
            report_service.generate_pdf_report(
                report=report,
                evidence_image_paths=evidence_image_local_paths,
            )

            # 11. Save Agent Trace JSON artifact: storage/jobs/<job_id>/agent_trace.json
            agent_trace_data = [t.model_dump() for t in agent.traces]
            storage_service.save_bytes(
                job_id=job_id,
                filename="agent_trace.json",
                data=json.dumps(agent_trace_data, indent=2).encode("utf-8"),
                content_type="application/json",
            )

            # 12. Create self-contained ZIP bundle: storage/jobs/<job_id>/results.zip
            storage_service.create_results_zip(job_id)

            # 13. Persist evidence and report into SQLite database
            db_service.save_evidence(job_id, evidence_items)
            db_service.save_report(job_id, report)

            logger.info(
                f"Completed inspection job {job_id} in {actual_processing_duration:.2f}s "
                f"({overall_fps:.1f} FPS, processed={processed_count}, skipped={skipped_count}). Events: {len(events)}"
            )

            # 14. Update final job status
            with self._lock:
                self.reports[job_id] = report
                if job_id in self.jobs:
                    self.jobs[job_id].status = JobStatus.COMPLETED
                    self.jobs[job_id].progress_pct = 100.0
                    self.jobs[job_id].current_frame = video_meta.total_frames
                    self.jobs[job_id].frames_processed = processed_count
                    self.jobs[job_id].frames_skipped = skipped_count
                    self.jobs[job_id].frame_stride = settings.FRAME_STRIDE
                    self.jobs[job_id].processing_fps = overall_fps
                    self.jobs[job_id].elapsed_sec = round(actual_processing_duration, 1)
                    self.jobs[job_id].estimated_time_remaining_sec = 0.0
                    self.jobs[job_id].report_url = f"{settings.API_PREFIX}/inspect/{job_id}/report"
                    self.jobs[job_id].video_url = f"{settings.API_PREFIX}/inspect/{job_id}/video"
                    self.jobs[job_id].pdf_url = f"{settings.API_PREFIX}/inspect/{job_id}/report.pdf"
                    self.jobs[job_id].zip_url = f"{settings.API_PREFIX}/inspect/{job_id}/zip"
                    self.jobs[job_id].updated_at = datetime.now(timezone.utc).isoformat()
                    db_service.save_job(self.jobs[job_id])

        except Exception as e:
            logger.exception(f"Job {job_id} failed with error: {e}")
            with self._lock:
                if job_id in self.jobs:
                    self.jobs[job_id].status = JobStatus.FAILED
                    self.jobs[job_id].error_message = str(e)
                    self.jobs[job_id].updated_at = datetime.now(timezone.utc).isoformat()
                    db_service.save_job(self.jobs[job_id])

        finally:
            if cap is not None:
                try:
                    cap.release()
                except Exception:
                    pass
            if writer is not None:
                try:
                    writer.release()
                except Exception:
                    pass


video_service = VideoProcessingService()

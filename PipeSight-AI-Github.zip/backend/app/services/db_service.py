"""
Persistent SQLite database service for PipeSight AI inspection jobs, reports, and evidence.
Guarantees job metadata and reports survive backend restarts without requiring external database servers.
"""

from datetime import datetime, timezone, timedelta
import json
import logging
from pathlib import Path
import sqlite3
import threading
from typing import Dict, List, Optional
import shutil

from app.config import settings
from app.schemas import (
    EvidenceItem,
    InspectionReport,
    JobStatus,
    JobStatusResponse,
)

logger = logging.getLogger(__name__)


class DatabaseService:
    """
    SQLite persistent storage manager for inspection jobs, reports, and evidence.
    Thread-safe with an internal reentrant lock.
    """

    def __init__(self, db_path: Optional[str] = None):
        self.db_path = Path(db_path or (Path(settings.LOCAL_STORAGE_DIR) / "pipesight.db")).resolve()
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()
        self._init_db()

    def _get_connection(self) -> sqlite3.Connection:
        conn = sqlite3.connect(str(self.db_path), timeout=20.0, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        return conn

    def _init_db(self) -> None:
        with self._lock, self._get_connection() as conn:
            conn.execute("PRAGMA journal_mode=WAL;")
            conn.execute("PRAGMA synchronous=NORMAL;")
            
            # Jobs table
            conn.execute("""
                CREATE TABLE IF NOT EXISTS jobs (
                    job_id TEXT PRIMARY KEY,
                    status TEXT NOT NULL,
                    filename TEXT NOT NULL,
                    progress_pct REAL DEFAULT 0.0,
                    current_frame INTEGER DEFAULT 0,
                    total_frames INTEGER DEFAULT 0,
                    frames_processed INTEGER DEFAULT 0,
                    frames_skipped INTEGER DEFAULT 0,
                    frame_stride INTEGER DEFAULT 3,
                    processing_fps REAL,
                    elapsed_sec REAL DEFAULT 0.0,
                    estimated_time_remaining_sec REAL,
                    error_message TEXT,
                    report_url TEXT,
                    video_url TEXT,
                    pdf_url TEXT,
                    zip_url TEXT,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );
            """)

            # Safe schema migration for existing databases
            try:
                conn.execute("ALTER TABLE jobs ADD COLUMN zip_url TEXT;")
            except sqlite3.OperationalError:
                pass

            # Reports table (stores full JSON report document)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS reports (
                    job_id TEXT PRIMARY KEY,
                    report_json TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    FOREIGN KEY(job_id) REFERENCES jobs(job_id) ON DELETE CASCADE
                );
            """)

            # Evidence table
            conn.execute("""
                CREATE TABLE IF NOT EXISTS evidence (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    job_id TEXT NOT NULL,
                    evidence_id TEXT NOT NULL,
                    track_id INTEGER,
                    class_name TEXT NOT NULL,
                    confidence REAL NOT NULL,
                    frame_idx INTEGER NOT NULL,
                    timestamp_sec REAL NOT NULL,
                    url TEXT NOT NULL,
                    key TEXT NOT NULL,
                    FOREIGN KEY(job_id) REFERENCES jobs(job_id) ON DELETE CASCADE
                );
            """)
            conn.execute("CREATE INDEX IF NOT EXISTS idx_evidence_job_id ON evidence(job_id);")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_jobs_created_at ON jobs(created_at);")

    def save_job(self, job: JobStatusResponse) -> None:
        with self._lock, self._get_connection() as conn:
            conn.execute("""
                INSERT INTO jobs (
                    job_id, status, filename, progress_pct, current_frame, total_frames,
                    frames_processed, frames_skipped, frame_stride, processing_fps,
                    elapsed_sec, estimated_time_remaining_sec, error_message,
                    report_url, video_url, pdf_url, zip_url, created_at, updated_at
                ) VALUES (
                    ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
                )
                ON CONFLICT(job_id) DO UPDATE SET
                    status=excluded.status,
                    progress_pct=excluded.progress_pct,
                    current_frame=excluded.current_frame,
                    total_frames=excluded.total_frames,
                    frames_processed=excluded.frames_processed,
                    frames_skipped=excluded.frames_skipped,
                    frame_stride=excluded.frame_stride,
                    processing_fps=excluded.processing_fps,
                    elapsed_sec=excluded.elapsed_sec,
                    estimated_time_remaining_sec=excluded.estimated_time_remaining_sec,
                    error_message=excluded.error_message,
                    report_url=excluded.report_url,
                    video_url=excluded.video_url,
                    pdf_url=excluded.pdf_url,
                    zip_url=excluded.zip_url,
                    updated_at=excluded.updated_at;
            """, (
                job.job_id,
                job.status.value if isinstance(job.status, JobStatus) else str(job.status),
                job.job_id,  # fallback if filename not available
                job.progress_pct,
                job.current_frame,
                job.total_frames,
                job.frames_processed or 0,
                job.frames_skipped or 0,
                job.frame_stride or settings.FRAME_STRIDE,
                job.processing_fps,
                job.elapsed_sec,
                job.estimated_time_remaining_sec,
                job.error_message,
                job.report_url,
                job.video_url,
                job.pdf_url,
                job.zip_url,
                job.updated_at,
                job.updated_at,
            ))

    def get_job(self, job_id: str) -> Optional[JobStatusResponse]:
        with self._lock, self._get_connection() as conn:
            row = conn.execute("SELECT * FROM jobs WHERE job_id = ?", (job_id,)).fetchone()
            if not row:
                return None
            return JobStatusResponse(
                job_id=row["job_id"],
                status=JobStatus(row["status"]),
                progress_pct=row["progress_pct"],
                current_frame=row["current_frame"],
                total_frames=row["total_frames"],
                frames_processed=row["frames_processed"],
                frames_skipped=row["frames_skipped"],
                frame_stride=row["frame_stride"],
                processing_fps=row["processing_fps"],
                elapsed_sec=row["elapsed_sec"],
                estimated_time_remaining_sec=row["estimated_time_remaining_sec"],
                error_message=row["error_message"],
                report_url=row["report_url"],
                video_url=row["video_url"],
                pdf_url=row["pdf_url"],
                zip_url=row["zip_url"] if "zip_url" in row.keys() else None,
                updated_at=row["updated_at"],
            )

    def list_jobs(self, limit: int = 50) -> List[JobStatusResponse]:
        with self._lock, self._get_connection() as conn:
            rows = conn.execute(
                "SELECT * FROM jobs ORDER BY updated_at DESC LIMIT ?", (limit,)
            ).fetchall()
            jobs = []
            for r in rows:
                jobs.append(
                    JobStatusResponse(
                        job_id=r["job_id"],
                        status=JobStatus(r["status"]),
                        progress_pct=r["progress_pct"],
                        current_frame=r["current_frame"],
                        total_frames=r["total_frames"],
                        frames_processed=r["frames_processed"],
                        frames_skipped=r["frames_skipped"],
                        frame_stride=r["frame_stride"],
                        processing_fps=r["processing_fps"],
                        elapsed_sec=r["elapsed_sec"],
                        estimated_time_remaining_sec=r["estimated_time_remaining_sec"],
                        error_message=r["error_message"],
                        report_url=r["report_url"],
                        video_url=r["video_url"],
                        pdf_url=r["pdf_url"],
                        zip_url=r["zip_url"] if "zip_url" in r.keys() else None,
                        updated_at=r["updated_at"],
                    )
                )
            return jobs

    def save_report(self, job_id: str, report: InspectionReport) -> None:
        report_json_str = report.model_dump_json()
        now_str = datetime.now(timezone.utc).isoformat()
        with self._lock, self._get_connection() as conn:
            conn.execute("""
                INSERT INTO reports (job_id, report_json, created_at)
                VALUES (?, ?, ?)
                ON CONFLICT(job_id) DO UPDATE SET
                    report_json=excluded.report_json;
            """, (job_id, report_json_str, now_str))

    def get_report(self, job_id: str) -> Optional[InspectionReport]:
        with self._lock, self._get_connection() as conn:
            row = conn.execute("SELECT report_json FROM reports WHERE job_id = ?", (job_id,)).fetchone()
            if not row:
                return None
            try:
                data = json.loads(row["report_json"])
                return InspectionReport.model_validate(data)
            except Exception as e:
                logger.error(f"Failed to parse report JSON from DB for job {job_id}: {e}")
                return None

    def save_evidence(self, job_id: str, items: List[EvidenceItem]) -> None:
        with self._lock, self._get_connection() as conn:
            conn.execute("DELETE FROM evidence WHERE job_id = ?", (job_id,))
            for item in items:
                conn.execute("""
                    INSERT INTO evidence (
                        job_id, evidence_id, track_id, class_name, confidence,
                        frame_idx, timestamp_sec, url, key
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    job_id,
                    item.evidence_id,
                    item.track_id,
                    item.class_name,
                    item.confidence,
                    item.frame_idx,
                    item.timestamp_sec,
                    item.url,
                    item.key,
                ))

    def get_evidence(self, job_id: str) -> List[EvidenceItem]:
        with self._lock, self._get_connection() as conn:
            rows = conn.execute(
                "SELECT * FROM evidence WHERE job_id = ? ORDER BY frame_idx ASC", (job_id,)
            ).fetchall()
            items = []
            for r in rows:
                items.append(
                    EvidenceItem(
                        evidence_id=r["evidence_id"],
                        track_id=r["track_id"],
                        class_name=r["class_name"],
                        confidence=r["confidence"],
                        frame_idx=r["frame_idx"],
                        timestamp_sec=r["timestamp_sec"],
                        url=r["url"],
                        key=r["key"],
                    )
                )
            return items

    def cleanup_old_jobs(self, retention_hours: int = 24, storage_base: Optional[Path] = None) -> int:
        """
        Purge jobs and disk artifacts older than retention_hours.
        Safeguard: Never deletes jobs currently in QUEUED or PROCESSING status.
        """
        cutoff = (datetime.now(timezone.utc) - timedelta(hours=retention_hours)).isoformat()
        cleaned_count = 0

        with self._lock, self._get_connection() as conn:
            # Query eligible jobs
            rows = conn.execute(
                "SELECT job_id FROM jobs WHERE updated_at < ? AND status IN ('completed', 'failed')",
                (cutoff,),
            ).fetchall()
            
            job_ids = [r["job_id"] for r in rows]
            if not job_ids:
                return 0

            target_base = storage_base or Path(settings.LOCAL_STORAGE_DIR)
            jobs_dir = target_base / "jobs"

            for jid in job_ids:
                # Remove disk artifacts
                job_folder = jobs_dir / jid
                if job_folder.is_dir():
                    try:
                        shutil.rmtree(job_folder, ignore_errors=True)
                        logger.info(f"Cleaned up expired inspection directory: {job_folder}")
                    except Exception as e:
                        logger.warning(f"Could not remove expired folder {job_folder}: {e}")

                # Delete from database
                conn.execute("DELETE FROM evidence WHERE job_id = ?", (jid,))
                conn.execute("DELETE FROM reports WHERE job_id = ?", (jid,))
                conn.execute("DELETE FROM jobs WHERE job_id = ?", (jid,))
                cleaned_count += 1

        logger.info(f"Purged {cleaned_count} expired inspection jobs (> {retention_hours}h old).")
        return cleaned_count


db_service = DatabaseService()

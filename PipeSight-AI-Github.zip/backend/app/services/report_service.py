"""
Report generation service producing structured JSON and PDF inspection reports.
"""

from datetime import datetime, timezone
import io
import json
import logging
import os
from pathlib import Path
from typing import Any, Dict, List, Optional
import cv2
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.platypus import (
    HRFlowable,
    Image as RLImage,
    KeepTogether,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)
import ultralytics

from app.config import settings
from app.schemas import (
    AgentDecisionsSummary,
    InspectionReport,
    InspectionSummary,
    ModelIdentity,
    PerformanceMetrics,
    ReportArtifacts,
    TrackEvent,
    VideoMetadata,
)
from app.services.storage_service import StorageService, storage_service

logger = logging.getLogger(__name__)


class ReportService:
    """Service to create JSON and PDF inspection reports."""

    def __init__(self, storage: Optional[StorageService] = None):
        self.storage = storage or storage_service

    def build_json_report(
        self,
        job_id: str,
        created_at_utc: str,
        model_name: str,
        class_names: Dict[int, str],
        device: str,
        video_stats: VideoMetadata,
        defect_events: List[TrackEvent],
        agent_summary: AgentDecisionsSummary,
        low_quality_count: int,
        enhanced_count: int,
        raw_detections_count: int,
        evidence_images_info: List[Dict[str, Any]],
        performance_metrics: Optional[PerformanceMetrics] = None,
        video_filename: str = "annotated_video.mp4",
        pdf_filename: str = "report.pdf",
    ) -> InspectionReport:
        """Construct the complete structured JSON report."""
        completed_at_utc = datetime.now(timezone.utc).isoformat()

        # Class counts
        events_by_class: Dict[str, int] = {}
        for ev in defect_events:
            events_by_class[ev.class_name] = events_by_class.get(ev.class_name, 0) + 1

        summary = InspectionSummary(
            raw_detections_count=raw_detections_count,
            estimated_unique_events_count=len(defect_events),
            events_by_class=events_by_class,
            low_quality_frames_count=low_quality_count,
            enhanced_frames_count=enhanced_count,
        )

        model_identity = ModelIdentity(
            model_name=model_name,
            classes=class_names,
            opencv_version=cv2.__version__,
            ultralytics_version=ultralytics.__version__,
            device=device,
        )

        artifacts = ReportArtifacts(
            annotated_video_url=self.storage.get_url(job_id, video_filename),
            pdf_report_url=self.storage.get_url(job_id, pdf_filename),
            evidence_images=evidence_images_info,
        )

        limitations = {
            "prototype_status": "Experimental Prototype",
            "validation_metric": f"Approx. {settings.MODEL_METRIC_MAP50} mAP@50 on held-out test data",
            "advisory_notice": settings.MODEL_LIMITATIONS_NOTICE,
            "cpu_optimization_notice": (
                f"Optimized for CPU inference: aspect-preserving downscaling (max {settings.MAX_PROCESSING_DIM}px) "
                f"and frame sampling stride={settings.FRAME_STRIDE} applied. Stride=1 available for full inspection."
            ),
            "tracking_disclaimer": (
                "ByteTrack associates detections between consecutive frames. Track IDs do not guarantee "
                "continuous physical defect identity across camera panning, abrupt viewpoint shifts, "
                "or visual occlusions. Track events represent estimated candidate occurrences."
            ),
            "spatial_disclaimer": (
                "Monocular inspection cameras do not yield calibrated linear pipe distances, wall depth, "
                "or physical millimeter measurements without external odometry or laser profilometry."
            ),
            "recommendation": "All flagged defect locations require physical verification by certified CCTV inspection operators.",
        }

        report = InspectionReport(
            job_id=job_id,
            created_at_utc=created_at_utc,
            completed_at_utc=completed_at_utc,
            model_identity=model_identity,
            video_statistics=video_stats,
            summary=summary,
            defect_events=defect_events,
            agent_decisions_summary=agent_summary,
            performance_metrics=performance_metrics,
            artifacts=artifacts,
            limitations_and_disclosures=limitations,
        )

        # Save JSON to storage
        report_json_str = report.model_dump_json(indent=2)
        self.storage.save_bytes(
            job_id=job_id,
            filename="report.json",
            data=report_json_str.encode("utf-8"),
            content_type="application/json",
        )

        return report

    def generate_pdf_report(
        self,
        report: InspectionReport,
        evidence_image_paths: Dict[int, str] = None,
    ) -> bytes:
        """
        Generate a professional PDF inspection report with ReportLab.
        """
        buf = io.BytesIO()
        doc = SimpleDocTemplate(
            buf,
            pagesize=letter,
            leftMargin=36,
            rightMargin=36,
            topMargin=36,
            bottomMargin=36,
        )

        styles = getSampleStyleSheet()

        title_style = ParagraphStyle(
            "DocTitle",
            parent=styles["Heading1"],
            fontSize=22,
            leading=26,
            textColor=colors.HexColor("#1A202C"),
            spaceAfter=6,
        )
        subtitle_style = ParagraphStyle(
            "DocSubtitle",
            parent=styles["Normal"],
            fontSize=10,
            leading=13,
            textColor=colors.HexColor("#4A5568"),
            spaceAfter=12,
        )
        h2_style = ParagraphStyle(
            "Heading2Custom",
            parent=styles["Heading2"],
            fontSize=13,
            leading=16,
            textColor=colors.HexColor("#2B6CB0"),
            spaceBefore=12,
            spaceAfter=6,
        )
        body_style = ParagraphStyle(
            "BodyCustom",
            parent=styles["Normal"],
            fontSize=9,
            leading=12,
            textColor=colors.HexColor("#2D3748"),
        )
        alert_style = ParagraphStyle(
            "AlertText",
            parent=styles["Normal"],
            fontSize=8.5,
            leading=12,
            textColor=colors.HexColor("#9B2C2C"),
        )
        table_cell_style = ParagraphStyle(
            "TableCell",
            parent=styles["Normal"],
            fontSize=8,
            leading=10,
            textColor=colors.HexColor("#1A202C"),
        )
        table_hdr_style = ParagraphStyle(
            "TableHdr",
            parent=styles["Normal"],
            fontSize=8,
            leading=10,
            textColor=colors.white,
            fontName="Helvetica-Bold",
        )

        story = []

        # --- 1. Document Header ---
        story.append(Paragraph("PipeSight AI — Diagnostic Inspection Report", title_style))
        story.append(
            Paragraph(
                f"Inspection Job: <b>{report.job_id}</b> &bull; Processed: {report.completed_at_utc} &bull; OpenCV {report.model_identity.opencv_version}",
                subtitle_style,
            )
        )
        story.append(HRFlowable(width="100%", thickness=1.5, color=colors.HexColor("#2B6CB0"), spaceAfter=10))

        # --- 2. Regulatory & Prototype Advisory Banner ---
        banner_data = [
            [
                Paragraph("<b>WARNING: EXPERIMENTAL PROTOTYPE — HUMAN VERIFICATION REQUIRED</b>", alert_style)
            ],
            [
                Paragraph(
                    f"Model validation accuracy: <b>{report.limitations_and_disclosures.get('validation_metric')}</b>.<br/>"
                    f"{report.limitations_and_disclosures.get('advisory_notice')}<br/>"
                    f"<i>{report.limitations_and_disclosures.get('tracking_disclaimer')}</i>",
                    alert_style,
                )
            ],
        ]
        banner_table = Table(banner_data, colWidths=[540])
        banner_table.setStyle(
            TableStyle(
                [
                    ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#FFF5F5")),
                    ("BOX", (0, 0), (-1, -1), 1.5, colors.HexColor("#E53E3E")),
                    ("PADDING", (0, 0), (-1, -1), 6),
                ]
            )
        )
        story.append(banner_table)
        story.append(Spacer(1, 10))

        # --- 3. Inspection Overview & Video Statistics ---
        story.append(Paragraph("1. Video & Processing Statistics", h2_style))
        stats_data = [
            [
                Paragraph("<b>Video Source</b>", table_cell_style),
                Paragraph(report.video_statistics.filename, table_cell_style),
                Paragraph("<b>Duration / FPS</b>", table_cell_style),
                Paragraph(f"{report.video_statistics.duration_sec}s @ {report.video_statistics.fps} fps", table_cell_style),
            ],
            [
                Paragraph("<b>Resolution</b>", table_cell_style),
                Paragraph(f"{report.video_statistics.width} x {report.video_statistics.height}", table_cell_style),
                Paragraph("<b>Processed Frames</b>", table_cell_style),
                Paragraph(f"{report.video_statistics.processed_frames} / {report.video_statistics.total_frames}", table_cell_style),
            ],
            [
                Paragraph("<b>Processing Engine</b>", table_cell_style),
                Paragraph(f"{report.model_identity.model_name} (CPU)", table_cell_style),
                Paragraph("<b>Processing Resolution</b>", table_cell_style),
                Paragraph(
                    f"{report.performance_metrics.processing_resolution[0]} x {report.performance_metrics.processing_resolution[1]}"
                    if report.performance_metrics else f"{report.video_statistics.width} x {report.video_statistics.height}",
                    table_cell_style,
                ),
            ],
            [
                Paragraph("<b>Low-Light Frames</b>", table_cell_style),
                Paragraph(str(report.summary.low_quality_frames_count), table_cell_style),
                Paragraph("<b>CLAHE Enhanced</b>", table_cell_style),
                Paragraph(str(report.summary.enhanced_frames_count), table_cell_style),
            ],
        ]
        stats_table = Table(stats_data, colWidths=[120, 150, 120, 150])
        stats_table.setStyle(
            TableStyle(
                [
                    ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#F7FAFC")),
                    ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#E2E8F0")),
                    ("PADDING", (0, 0), (-1, -1), 4),
                ]
            )
        )
        story.append(stats_table)
        story.append(Spacer(1, 10))

        # --- CPU Performance & Profiling Metrics ---
        if report.performance_metrics:
            pm = report.performance_metrics
            story.append(Paragraph("2. CPU Processing & Performance Profiling", h2_style))
            perf_data = [
                [
                    Paragraph("<b>Original Resolution</b>", table_cell_style),
                    Paragraph(f"{pm.original_resolution[0]} x {pm.original_resolution[1]}", table_cell_style),
                    Paragraph("<b>Processing Resolution</b>", table_cell_style),
                    Paragraph(f"{pm.processing_resolution[0]} x {pm.processing_resolution[1]}", table_cell_style),
                ],
                [
                    Paragraph("<b>Video Duration</b>", table_cell_style),
                    Paragraph(f"{pm.video_duration_sec}s", table_cell_style),
                    Paragraph("<b>Actual Processing Time</b>", table_cell_style),
                    Paragraph(f"{pm.actual_processing_duration_sec}s", table_cell_style),
                ],
                [
                    Paragraph("<b>Processing Speed</b>", table_cell_style),
                    Paragraph(f"<b>{pm.processing_fps:.1f} FPS</b>", table_cell_style),
                    Paragraph("<b>Frame Sampling</b>", table_cell_style),
                    Paragraph(f"Stride {pm.frame_stride} ({pm.frames_processed} proc / {pm.frames_skipped} skip)", table_cell_style),
                ],
                [
                    Paragraph("<b>Enhancement Retries</b>", table_cell_style),
                    Paragraph(f"{pm.enhancement_retries} CLAHE passes", table_cell_style),
                    Paragraph("<b>Candidate Events</b>", table_cell_style),
                    Paragraph(f"{pm.candidate_defect_events_count} unique defect tracks", table_cell_style),
                ],
            ]
            perf_table = Table(perf_data, colWidths=[130, 140, 130, 140])
            perf_table.setStyle(
                TableStyle(
                    [
                        ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#F0FFF4")),
                        ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#C6F6D5")),
                        ("PADDING", (0, 0), (-1, -1), 4),
                    ]
                )
            )
            story.append(perf_table)
            story.append(Spacer(1, 6))

            if pm.time_breakdown_sec:
                breakdown_cells = [
                    Paragraph(f"<b>{k.replace('_', ' ').title()}:</b> {v:.2f}s", table_cell_style)
                    for k, v in pm.time_breakdown_sec.items()
                ]
                b_rows = []
                for i in range(0, len(breakdown_cells), 2):
                    row = breakdown_cells[i : i + 2]
                    while len(row) < 2:
                        row.append(Paragraph("", table_cell_style))
                    b_rows.append(row)
                b_table = Table(b_rows, colWidths=[270, 270])
                b_table.setStyle(
                    TableStyle(
                        [
                            ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#F7FAFC")),
                            ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#E2E8F0")),
                            ("PADDING", (0, 0), (-1, -1), 3),
                        ]
                    )
                )
                story.append(b_table)
                story.append(Spacer(1, 10))

        # --- Suspected Defect Events ---
        sec_num = 3 if report.performance_metrics else 2
        story.append(Paragraph(f"{sec_num}. Suspected Defect Events (ByteTrack Aggregation)", h2_style))
        if not report.defect_events:
            story.append(Paragraph("<i>No defect events were identified above the confidence threshold.</i>", body_style))
        else:
            event_rows = [
                [
                    Paragraph("Track ID", table_hdr_style),
                    Paragraph("Advisory Defect Class", table_hdr_style),
                    Paragraph("Peak Conf", table_hdr_style),
                    Paragraph("Avg Conf", table_hdr_style),
                    Paragraph("Time Span (s)", table_hdr_style),
                    Paragraph("Frames", table_hdr_style),
                ]
            ]
            for ev in report.defect_events[:30]:  # Limit to 30 events in table for pagination
                event_rows.append(
                    [
                        Paragraph(f"#{ev.track_id}", table_cell_style),
                        Paragraph(f"<b>{ev.advisory_label}</b>", table_cell_style),
                        Paragraph(f"{ev.peak_confidence:.2f}", table_cell_style),
                        Paragraph(f"{ev.avg_confidence:.2f}", table_cell_style),
                        Paragraph(f"{ev.first_seen_sec:.1f}s - {ev.last_seen_sec:.1f}s", table_cell_style),
                        Paragraph(str(ev.observation_count), table_cell_style),
                    ]
                )

            defect_table = Table(event_rows, colWidths=[55, 175, 65, 65, 110, 70])
            defect_table.setStyle(
                TableStyle(
                    [
                        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#2B6CB0")),
                        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#F7FAFC")]),
                        ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#CBD5E0")),
                        ("PADDING", (0, 0), (-1, -1), 4),
                    ]
                )
            )
            story.append(defect_table)
        story.append(Spacer(1, 10))

        # --- Agentic Vision Trace & Decisions ---
        story.append(Paragraph(f"{sec_num + 1}. Agentic Vision Controller Trace", h2_style))
        agent_data = [
            [
                Paragraph("<b>Total Actions Evaluated</b>", table_cell_style),
                Paragraph(str(report.agent_decisions_summary.total_actions), table_cell_style),
                Paragraph("<b>Decisions Breakdown</b>", table_cell_style),
                Paragraph(
                    ", ".join([f"{k}: {v}" for k, v in report.agent_decisions_summary.action_counts.items()]),
                    table_cell_style,
                ),
            ]
        ]
        agent_table = Table(agent_data, colWidths=[140, 60, 140, 200])
        agent_table.setStyle(
            TableStyle(
                [
                    ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#EDF2F7")),
                    ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#CBD5E0")),
                    ("PADDING", (0, 0), (-1, -1), 4),
                ]
            )
        )
        story.append(agent_table)
        story.append(Spacer(1, 10))

        # Sample traces table
        if report.agent_decisions_summary.sample_traces:
            trace_rows = [
                [
                    Paragraph("Frame", table_hdr_style),
                    Paragraph("Time", table_hdr_style),
                    Paragraph("Decision", table_hdr_style),
                    Paragraph("Tool Action", table_hdr_style),
                    Paragraph("Outcome", table_hdr_style),
                ]
            ]
            for tr in report.agent_decisions_summary.sample_traces[:8]:
                trace_rows.append(
                    [
                        Paragraph(str(tr.frame), table_cell_style),
                        Paragraph(f"{tr.timestamp_sec:.2f}s", table_cell_style),
                        Paragraph(f"<b>{tr.decision}</b>", table_cell_style),
                        Paragraph(tr.action, table_cell_style),
                        Paragraph(tr.outcome, table_cell_style),
                    ]
                )
            trace_table = Table(trace_rows, colWidths=[45, 55, 140, 150, 150])
            trace_table.setStyle(
                TableStyle(
                    [
                        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#4A5568")),
                        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#F7FAFC")]),
                        ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#CBD5E0")),
                        ("PADDING", (0, 0), (-1, -1), 3),
                    ]
                )
            )
            story.append(trace_table)
            story.append(Spacer(1, 10))

        # --- Representative Evidence Images ---
        if evidence_image_paths:
            story.append(Paragraph(f"{sec_num + 2}. Representative Defect Evidence", h2_style))
            evidence_cells = []
            for track_id, img_path in list(evidence_image_paths.items())[:4]:  # Top 4 evidence images
                if os.path.isfile(img_path):
                    try:
                        rl_img = RLImage(img_path, width=220, height=130)
                        cap = Paragraph(f"<b>Track #{track_id}</b>", table_cell_style)
                        evidence_cells.append([rl_img, cap])
                    except Exception as e:
                        logger.warning(f"Could not embed image {img_path}: {e}")

            if evidence_cells:
                # Arrange 2 images per row
                grid_rows = []
                for i in range(0, len(evidence_cells), 2):
                    row = []
                    for item in evidence_cells[i : i + 2]:
                        sub_table = Table([[item[0]], [item[1]]], colWidths=[240])
                        sub_table.setStyle(TableStyle([("ALIGN", (0, 0), (-1, -1), "CENTER")]))
                        row.append(sub_table)
                    while len(row) < 2:
                        row.append("")
                    grid_rows.append(row)

                img_table = Table(grid_rows, colWidths=[270, 270])
                story.append(img_table)
                story.append(Spacer(1, 10))

        # --- 7. Final Engineering Sign-off & Limitation Notes ---
        story.append(Spacer(1, 8))
        story.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor("#CBD5E0"), spaceAfter=8))
        story.append(
            Paragraph(
                "<b>Field Verification Sign-off:</b><br/>"
                "Certified CCTV Operator: _______________________ &nbsp;&nbsp;&nbsp;&nbsp; Date: _______________ &nbsp;&nbsp;&nbsp;&nbsp; Action Taken: [ ] Scheduled Flush &nbsp; [ ] Trenchless Repair &nbsp; [ ] Monitor",
                body_style,
            )
        )

        doc.build(story)
        pdf_bytes = buf.getvalue()

        # Save to storage
        self.storage.save_bytes(
            job_id=report.job_id,
            filename="report.pdf",
            data=pdf_bytes,
            content_type="application/pdf",
        )

        return pdf_bytes


report_service = ReportService()

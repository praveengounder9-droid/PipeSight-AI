"""
Vision Service for YOLO26s defect detection and ByteTrack tracking.
"""

import hashlib
import logging
from pathlib import Path
from typing import Dict, List, Optional, Tuple
import numpy as np
import torch
from ultralytics import YOLO

from app.config import settings
from app.schemas import DetectionBox

logger = logging.getLogger(__name__)

# Advisory prefix map for cautious engineering language
ADVISORY_PREFIXES = {
    0: "Suspected Buckling",
    1: "Suspected Crack",
    2: "Model-predicted Debris",
    3: "Suspected Hole",
    4: "Suspected Joint Offset",
    5: "Model-predicted Obstacle",
    6: "Suspected Utility Intrusion",
}


class VisionService:
    """
    Singleton service managing YOLO26s model inference and ByteTrack tracking.
    """

    _instance: Optional["VisionService"] = None

    def __init__(self):
        self.model_path = Path(settings.MODEL_PATH).resolve()
        self.device = settings.DEVICE
        self.model: Optional[YOLO] = None
        self.class_names: Dict[int, str] = {}
        self.checkpoint_hash: str = ""
        self._load_model()

    @classmethod
    def get_instance(cls) -> "VisionService":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def _compute_hash(self, path: Path) -> str:
        if not path.is_file():
            return "unknown"
        sha = hashlib.sha256()
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(65536), b""):
                sha.update(chunk)
        return sha.hexdigest()

    def _load_model(self) -> None:
        if not self.model_path.is_file():
            logger.warning(f"Checkpoint not found at {self.model_path}")
            return

        logger.info(f"Loading YOLO model {self.model_path.name} onto CPU...")
        self.checkpoint_hash = self._compute_hash(self.model_path)
        self.model = YOLO(str(self.model_path))

        # Extract names from model
        if hasattr(self.model, "names") and isinstance(self.model.names, dict):
            self.class_names = {int(k): str(v) for k, v in self.model.names.items()}
        else:
            self.class_names = {
                0: "Buckling",
                1: "Crack",
                2: "Debris",
                3: "Hole",
                4: "Joint offset",
                5: "Obstacle",
                6: "Utility intrusion",
            }
        logger.info(f"Model loaded successfully with {len(self.class_names)} classes.")

    def reset_tracker(self) -> None:
        """
        Reset ByteTrack tracker state to prevent track ID carry-over between videos.
        """
        if self.model and hasattr(self.model, "predictor") and self.model.predictor is not None:
            if hasattr(self.model.predictor, "trackers") and self.model.predictor.trackers:
                for trk in self.model.predictor.trackers:
                    if hasattr(trk, "reset"):
                        try:
                            trk.reset()
                        except Exception as e:
                            logger.debug(f"Tracker reset exception: {e}")
            self.model.predictor = None
            logger.debug("ByteTrack tracker state reset.")

    def track_frame(
        self,
        frame: np.ndarray,
        frame_idx: int,
        timestamp_sec: float,
        conf_thresh: Optional[float] = None,
        enhanced: bool = False,
    ) -> List[DetectionBox]:
        """
        Run ByteTrack tracking on a single frame.

        Args:
            frame: BGR numpy image (pre-sized).
            frame_idx: Current frame index.
            timestamp_sec: Video timestamp in seconds.
            conf_thresh: Optional confidence override.
            enhanced: Whether the frame underwent CLAHE enhancement.

        Returns:
            List of DetectionBox objects with track IDs.
        """
        if self.model is None:
            return []

        conf = conf_thresh if conf_thresh is not None else settings.CONFIDENCE_THRESHOLD

        tracker_config = settings.TRACKER_CONFIG_PATH
        if not Path(tracker_config).is_file():
            tracker_config = "bytetrack.yaml"

        with torch.inference_mode():
            results = self.model.track(
                source=frame,
                persist=True,
                tracker=tracker_config,
                conf=conf,
                iou=settings.IOU_THRESHOLD,
                imgsz=settings.INFERENCE_IMGSZ,
                device="cpu",
                verbose=False,
            )

        detections: List[DetectionBox] = []
        if not results or len(results) == 0:
            return detections

        res = results[0]
        boxes = res.boxes
        if boxes is None or len(boxes) == 0:
            return detections

        # Extract coordinates, classes, scores, and track IDs
        coords = boxes.xyxy.cpu().numpy()
        confs = boxes.conf.cpu().numpy()
        classes = boxes.cls.cpu().numpy().astype(int)

        track_ids = None
        if hasattr(boxes, "id") and boxes.id is not None:
            track_ids = boxes.id.cpu().numpy().astype(int)

        for i in range(len(coords)):
            cls_id = int(classes[i])
            cls_name = self.class_names.get(cls_id, f"Class_{cls_id}")
            track_id = int(track_ids[i]) if track_ids is not None else None

            det = DetectionBox(
                class_id=cls_id,
                class_name=cls_name,
                confidence=round(float(confs[i]), 3),
                bbox=[round(float(c), 1) for c in coords[i]],
                track_id=track_id,
                frame_idx=frame_idx,
                timestamp_sec=round(timestamp_sec, 3),
                enhanced=enhanced,
            )
            detections.append(det)

        return detections

    def detect_single(
        self,
        frame: np.ndarray,
        conf_thresh: Optional[float] = None,
    ) -> List[DetectionBox]:
        """
        Run pure detection without tracking on an image.
        """
        if self.model is None:
            return []

        conf = conf_thresh if conf_thresh is not None else settings.CONFIDENCE_THRESHOLD
        with torch.inference_mode():
            results = self.model(
                source=frame,
                conf=conf,
                iou=settings.IOU_THRESHOLD,
                imgsz=settings.INFERENCE_IMGSZ,
                device="cpu",
                verbose=False,
            )

        detections: List[DetectionBox] = []
        if not results:
            return detections

        boxes = results[0].boxes
        if boxes is None or len(boxes) == 0:
            return detections

        coords = boxes.xyxy.cpu().numpy()
        confs = boxes.conf.cpu().numpy()
        classes = boxes.cls.cpu().numpy().astype(int)

        for i in range(len(coords)):
            cls_id = int(classes[i])
            cls_name = self.class_names.get(cls_id, f"Class_{cls_id}")
            detections.append(
                DetectionBox(
                    class_id=cls_id,
                    class_name=cls_name,
                    confidence=round(float(confs[i]), 3),
                    bbox=[round(float(c), 1) for c in coords[i]],
                    track_id=None,
                    frame_idx=0,
                    timestamp_sec=0.0,
                    enhanced=False,
                )
            )

        return detections


vision_service = VisionService.get_instance()

"""
Agentic Vision Controller: Implements the deterministic perception-decision-action loop.
Uses OpenCV 5 measurements to dynamically drive enhancement, re-inspection,
temporal consistency checks, and human review decisions.
"""

from collections import Counter
import logging
from typing import Any, Dict, List, Optional, Tuple
import numpy as np

from app.config import settings
from app.schemas import (
    AgentDecision,
    AgentDecisionsSummary,
    AgentTraceStep,
    DetectionBox,
    QualityMetrics,
)
from app.services.vision_service import VisionService, vision_service
from app.utils.image_quality import (
    compare_detection_candidates,
    compute_image_quality,
    enhance_frame_luminance,
)

logger = logging.getLogger(__name__)


class AgentVisionController:
    """
    Deterministic Agentic Vision Controller.
    Executes the 5-stage loop:
      A. INSPECT
      B. ASSESS QUALITY
      C. ASSESS DETECTION
      D. DECIDE NEXT ACTION
      E. RECORD ACTION
    """

    def __init__(self, job_id: str, vision_svc: Optional[VisionService] = None):
        self.job_id = job_id
        self.vision_svc = vision_svc or vision_service
        self.traces: List[AgentTraceStep] = []
        self.action_counter: Counter = Counter()
        self.enhancement_retries_count: int = 0

        # Sliding window of recent detections for adjacent frame reasoning
        self.recent_frame_detections: List[Tuple[int, List[DetectionBox]]] = []
        self.window_size = 5

    def step(
        self,
        frame: np.ndarray,
        frame_idx: int,
        timestamp_sec: float,
    ) -> Tuple[np.ndarray, List[DetectionBox], QualityMetrics, bool]:
        """
        Execute one perception-decision-action cycle for a video frame.

        Returns:
            Tuple of:
              - frame_to_render: (original or enhanced image for overlay & video)
              - final_detections: List[DetectionBox]
              - quality: QualityMetrics
              - enhanced_applied: bool
        """
        # --- Stage A: INSPECT ---
        quality = compute_image_quality(frame)
        orig_detections = self.vision_svc.track_frame(
            frame=frame,
            frame_idx=frame_idx,
            timestamp_sec=timestamp_sec,
            enhanced=False,
        )

        final_frame = frame
        final_detections = orig_detections
        enhanced_applied = False
        retry_count = 0

        # --- Stage B: ASSESS QUALITY ---
        # Apply CLAHE only when the quality controller identifies a genuine low-light problem
        # Limit enhancement retries to max 1 additional inference per frame
        if quality.is_too_dark and settings.ENABLE_CLAHE_ENHANCEMENT and retry_count < settings.MAX_RETRIES_PER_FRAME:
            retry_count += 1
            self.enhancement_retries_count += 1

            # Action: Apply CLAHE on luminance channel + bilateral filter
            enhanced_frame, enh_meta = enhance_frame_luminance(frame)

            # Rerun detection/tracking on enhanced frame
            enh_detections = self.vision_svc.track_frame(
                frame=enhanced_frame,
                frame_idx=frame_idx,
                timestamp_sec=timestamp_sec,
                enhanced=True,
            )

            # Compare evidence
            diff = compare_detection_candidates(
                [d.model_dump() for d in orig_detections],
                [d.model_dump() for d in enh_detections],
            )

            # Evaluate whether enhanced frame should be adopted
            if diff["enhanced_count"] > diff["orig_count"] or diff["conf_delta"] > 0.03:
                final_frame = enhanced_frame
                final_detections = enh_detections
                enhanced_applied = True
                outcome = "evidence_improved_clahe_adopted"
            else:
                # Keep original detections if enhancement introduced no gain or noise
                final_detections = orig_detections
                final_frame = frame
                outcome = "original_evidence_retained"

            # Record Agent Trace
            trace = AgentTraceStep(
                frame=frame_idx,
                timestamp_sec=timestamp_sec,
                observations={
                    "brightness_mean": quality.brightness_mean,
                    "blur_score": quality.blur_score,
                    "contrast_score": quality.contrast_score,
                    "flags": quality.quality_flags,
                },
                decision=AgentDecision.ENHANCE_AND_RECHECK.value,
                action="apply_clahe_on_luminance",
                next_action="rerun_detection",
                outcome=outcome,
                details=f"Conf delta: {diff['conf_delta']:+.3f}, Outcome: {diff['outcome']}",
            )
            self._record_trace(trace)

        # --- Stage C: ASSESS DETECTION ---
        has_uncertain_defect = any(
            settings.UNCERTAIN_CONF_LOWER <= d.confidence <= settings.UNCERTAIN_CONF_UPPER
            for d in final_detections
        )

        # Check adjacent frames in temporal sliding window
        recent_tracks = set()
        for _, past_dets in self.recent_frame_detections:
            for d in past_dets:
                if d.track_id is not None:
                    recent_tracks.add(d.track_id)

        current_tracks = {d.track_id for d in final_detections if d.track_id is not None}
        new_unstable_tracks = current_tracks - recent_tracks

        # --- Stage D: DECIDE NEXT ACTION ---
        if quality.is_low_quality and has_uncertain_defect and not enhanced_applied:
            # Low light and ambiguous defect: Request Human Review
            decision = AgentDecision.REQUEST_HUMAN_REVIEW
            action = "flag_for_human_review"
            next_action = "CONTINUE"
            outcome = "evidence_ambiguous_review_flagged"
            details = "Low lighting combined with borderline detection confidence."

            trace = AgentTraceStep(
                frame=frame_idx,
                timestamp_sec=timestamp_sec,
                observations={"low_quality": True, "uncertain_detections": True},
                decision=decision.value,
                action=action,
                next_action=next_action,
                outcome=outcome,
                details=details,
            )
            self._record_trace(trace)

        elif has_uncertain_defect or (new_unstable_tracks and len(self.recent_frame_detections) >= 2):
            decision = AgentDecision.INSPECT_ADJACENT_FRAMES
            action = "corroborate_with_adjacent_frames"
            next_action = "CONTINUE"
            outcome = "track_flagged_for_temporal_smoothing"

            trace = AgentTraceStep(
                frame=frame_idx,
                timestamp_sec=timestamp_sec,
                observations={
                    "candidate_tracks": list(current_tracks),
                    "uncertain_count": sum(1 for d in final_detections if d.confidence <= settings.UNCERTAIN_CONF_UPPER),
                },
                decision=decision.value,
                action=action,
                next_action=next_action,
                outcome=outcome,
                details="Temporal smoothing applied across contiguous frames.",
            )
            self._record_trace(trace)

        elif len(final_detections) > 0:
            decision = AgentDecision.CONTINUE
            action = "record_confident_defect"
            next_action = "CONTINUE"
            outcome = f"tracked_{len(final_detections)}_defects"

            trace = AgentTraceStep(
                frame=frame_idx,
                timestamp_sec=timestamp_sec,
                observations={"detections_count": len(final_detections)},
                decision=decision.value,
                action=action,
                next_action=next_action,
                outcome=outcome,
                details=f"Classes: {[d.class_name for d in final_detections]}",
            )
            self._record_trace(trace)

        else:
            decision = AgentDecision.LOG_AND_CONTINUE
            action = "advance_frame"
            next_action = "CONTINUE"
            outcome = "clear_pipe_wall"

            # To avoid bloating trace logs with 100,000 clear frames, record every 30th clear frame or first
            if frame_idx % 30 == 0 or frame_idx == 0:
                trace = AgentTraceStep(
                    frame=frame_idx,
                    timestamp_sec=timestamp_sec,
                    observations={"brightness_mean": quality.brightness_mean, "blur_score": quality.blur_score},
                    decision=decision.value,
                    action=action,
                    next_action=next_action,
                    outcome=outcome,
                    details=None,
                )
                self._record_trace(trace)

        # Update sliding window
        self.recent_frame_detections.append((frame_idx, final_detections))
        if len(self.recent_frame_detections) > self.window_size:
            self.recent_frame_detections.pop(0)

        return final_frame, final_detections, quality, enhanced_applied

    def _record_trace(self, trace: AgentTraceStep) -> None:
        self.traces.append(trace)
        self.action_counter[trace.decision] += 1

    def get_summary(self, max_sample_traces: int = 15) -> AgentDecisionsSummary:
        """
        Produce a summary of all agentic decisions and actions.
        """
        # Select representative sample traces covering all distinct decisions
        sample_traces: List[AgentTraceStep] = []
        seen_decisions = set()
        for t in self.traces:
            if t.decision not in seen_decisions or len(sample_traces) < max_sample_traces:
                seen_decisions.add(t.decision)
                sample_traces.append(t)
            if len(sample_traces) >= max_sample_traces and len(seen_decisions) >= len(self.action_counter):
                break

        return AgentDecisionsSummary(
            total_actions=len(self.traces),
            action_counts=dict(self.action_counter),
            sample_traces=sample_traces,
        )

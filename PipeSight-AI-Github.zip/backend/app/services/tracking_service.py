"""
Tracking service for ByteTrack defect deduplication and event aggregation.
"""

from collections import defaultdict
from typing import Dict, List, Optional, Tuple
import numpy as np

from app.schemas import DetectionBox, TrackEvent
from app.services.vision_service import ADVISORY_PREFIXES


class TrackingService:
    """
    Aggregates per-frame ByteTrack detections into unique defect-track events.
    Handles track lifecycle, confidence aggregation, representative frame selection,
    and defect deduplication.
    """

    def __init__(self, job_id: str):
        self.job_id = job_id
        # Map: track_id -> List[DetectionBox]
        self.track_observations: Dict[int, List[DetectionBox]] = defaultdict(list)
        # Store representative candidate frames: track_id -> (frame_image, DetectionBox)
        self.representative_frames: Dict[int, Tuple[np.ndarray, DetectionBox]] = {}
        self._untracked_counter = 10000

    def add_detections(self, detections: List[DetectionBox], frame: Optional[np.ndarray] = None) -> None:
        """
        Record detections for the current frame and update representative candidate frames.
        """
        for det in detections:
            # If no track_id was assigned by tracker, assign a synthetic isolated ID
            track_id = det.track_id
            if track_id is None:
                track_id = self._untracked_counter
                self._untracked_counter += 1
                det.track_id = track_id

            self.track_observations[track_id].append(det)

            # Check if this detection is the new peak representative for this track
            if frame is not None:
                current_best = self.representative_frames.get(track_id)
                if current_best is None or det.confidence > current_best[1].confidence:
                    self.representative_frames[track_id] = (frame.copy(), det)

    def aggregate_events(self) -> List[TrackEvent]:
        """
        Aggregate raw frame observations into deduplicated TrackEvent summaries.

        Returns:
            List of TrackEvent objects sorted chronologically by first_seen_sec.
        """
        events: List[TrackEvent] = []

        for track_id, observations in self.track_observations.items():
            if not observations:
                continue

            # Determine dominant class by peak confidence
            best_obs = max(observations, key=lambda o: o.confidence)
            cls_id = best_obs.class_id
            cls_name = best_obs.class_name

            timestamps = [o.timestamp_sec for o in observations]
            confs = [o.confidence for o in observations]

            first_seen = round(min(timestamps), 3)
            last_seen = round(max(timestamps), 3)
            duration = round(last_seen - first_seen, 3)
            peak_conf = round(max(confs), 3)
            avg_conf = round(float(np.mean(confs)), 3)

            # Cautious advisory label
            advisory = ADVISORY_PREFIXES.get(cls_id, f"Suspected {cls_name}")

            event = TrackEvent(
                track_id=track_id,
                class_id=cls_id,
                class_name=cls_name,
                advisory_label=advisory,
                observation_count=len(observations),
                first_seen_sec=first_seen,
                last_seen_sec=last_seen,
                duration_sec=duration,
                peak_confidence=peak_conf,
                avg_confidence=avg_conf,
                representative_frame_idx=best_obs.frame_idx,
                representative_timestamp_sec=best_obs.timestamp_sec,
                representative_bbox=best_obs.bbox,
                evidence_image_key=None,
                evidence_image_url=None,
            )
            events.append(event)

        # Sort events by first appearance in video
        events.sort(key=lambda e: e.first_seen_sec)
        return events

    def get_representative_frame(self, track_id: int) -> Optional[Tuple[np.ndarray, DetectionBox]]:
        """Return the best frame and detection box for a track ID."""
        return self.representative_frames.get(track_id)

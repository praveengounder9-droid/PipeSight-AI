"""
Main FastAPI Application for PipeSight AI.
Agentic Sewer Inspection and Diagnostic Backend using OpenCV 5.
"""

from contextlib import asynccontextmanager
import logging
import cv2
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import torch
import ultralytics

from app.api.routes import router as api_router
from app.config import settings
from app.schemas import HealthResponse
from app.services.vision_service import vision_service
from app.utils.cool_adapter import cool_adapter

# Configure structured logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger("pipesight_ai")


@asynccontextmanager
async def lifespan(app: FastAPI):
    # Configure PyTorch CPU thread count explicitly
    torch.set_num_threads(settings.CPU_NUM_THREADS)

    # Startup validation and diagnostics log
    logger.info("=" * 60)
    logger.info(f"Starting {settings.APP_NAME} v{settings.VERSION}")
    logger.info(f"OpenCV Version: {cv2.__version__}")
    logger.info(f"PyTorch Version: {torch.__version__} | CPU Threads: {torch.get_num_threads()}")
    logger.info(f"Ultralytics Version: {ultralytics.__version__}")
    logger.info(f"Compute Device: {vision_service.device} (CPU Prioritized)")
    logger.info(f"CPU Optimizations: Max Dim {settings.MAX_PROCESSING_DIM}x{settings.MAX_PROCESSING_DIM}, Frame Stride {settings.FRAME_STRIDE}")
    logger.info(f"Model Loaded: {vision_service.model is not None}")
    logger.info(f"Model Classes ({len(vision_service.class_names)}): {vision_service.class_names}")
    logger.info(f"Storage Backend: {settings.STORAGE_BACKEND}")
    logger.info(f"Prototype Metric: ~{settings.MODEL_METRIC_MAP50} mAP@50")
    logger.info("=" * 60)
    yield
    logger.info("PipeSight AI backend shutting down.")


app = FastAPI(
    title=settings.APP_NAME,
    version=settings.VERSION,
    description=(
        "Automated plumbing and sewer inspection assistant using OpenCV 5, "
        "YOLO26s, and ByteTrack. Features an Agentic Vision loop for real-time "
        "adaptive quality assessment and luminance enhancement."
    ),
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc",
)

# CORS Middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get(
    "/health",
    response_model=HealthResponse,
    tags=["System"],
    summary="Service health and capability check",
)
def health_check():
    """
    Returns application status, OpenCV 5 version, PyTorch/Ultralytics status,
    COOL status, device, model status, and system capabilities.
    """
    return HealthResponse(
        status="healthy",
        opencv_version=cv2.__version__,
        torch_version=torch.__version__,
        ultralytics_version=ultralytics.__version__,
        cool_enabled=cool_adapter.is_active,
        cool_status=cool_adapter.status_message,
        model_loaded=vision_service.model is not None,
        model_name="YOLO26s Sewer Defect Detector",
        device=vision_service.device,
        classes_count=len(vision_service.class_names),
        capabilities=[
            "opencv5_video_decoding",
            "opencv5_laplacian_blur_analysis",
            "clahe_luminance_enhancement",
            "bilateral_edge_preserving_filter",
            "yolo26s_defect_detection",
            "bytetrack_persistent_tracking",
            "agentic_perception_action_loop",
            "automated_defect_deduplication",
            "reportlab_pdf_generation",
            "s3_and_local_storage_adapters",
            "cpu_frame_sampling_optimization",
            "resolution_aspect_preserving_resize",
        ],
    )


# Include API v1 routes
app.include_router(api_router, prefix=settings.API_PREFIX, tags=["Inspection"])


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app.main:app", host=settings.HOST, port=settings.PORT, reload=settings.DEBUG)

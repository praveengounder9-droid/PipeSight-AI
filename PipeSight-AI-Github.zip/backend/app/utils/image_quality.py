"""
Image quality analysis and luminance enhancement utilities using OpenCV 5.
"""

from typing import Any, Dict, List, Optional, Tuple
import cv2
import numpy as np

from app.config import settings
from app.schemas import QualityMetrics
from app.utils.cool_adapter import cool_adapter


def compute_image_quality(frame: np.ndarray, precomputed_gray: Optional[np.ndarray] = None) -> QualityMetrics:
    """
    Calculate brightness, Laplacian blur score, and contrast metrics using OpenCV 5.
    Accepts precomputed grayscale array to avoid redundant color-space conversions.

    Args:
        frame: BGR numpy image array.
        precomputed_gray: Optional pre-extracted grayscale array.

    Returns:
        QualityMetrics object with flags.
    """
    if frame is None or frame.size == 0:
        return QualityMetrics(
            brightness_mean=0.0,
            brightness_std=0.0,
            blur_score=0.0,
            contrast_score=0.0,
            is_too_dark=True,
            is_low_quality=True,
            quality_flags=["empty_frame"],
        )

    # Convert to grayscale once if not already provided
    gray = precomputed_gray if precomputed_gray is not None else cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    # 1. Brightness metrics (mean and standard deviation)
    brightness_mean = float(np.mean(gray))
    brightness_std = float(np.std(gray))

    # 2. Contrast score (RMS contrast = standard deviation of pixel intensities)
    contrast_score = brightness_std

    # 3. Blur score via OpenCV 5 Laplacian variance
    laplacian = cv2.Laplacian(gray, cv2.CV_64F)
    blur_score = float(laplacian.var())

    # 4. Assess against thresholds
    is_too_dark = brightness_mean < settings.BRIGHTNESS_MIN_THRESHOLD
    is_too_bright = brightness_mean > settings.BRIGHTNESS_MAX_THRESHOLD
    is_blurry = blur_score < settings.BLUR_THRESHOLD
    is_low_contrast = contrast_score < settings.CONTRAST_MIN_THRESHOLD

    quality_flags: List[str] = []
    if is_too_dark:
        quality_flags.append(f"low_brightness_{brightness_mean:.1f}<{settings.BRIGHTNESS_MIN_THRESHOLD}")
    if is_too_bright:
        quality_flags.append(f"high_brightness_{brightness_mean:.1f}>{settings.BRIGHTNESS_MAX_THRESHOLD}")
    if is_blurry:
        quality_flags.append(f"blurry_{blur_score:.1f}<{settings.BLUR_THRESHOLD}")
    if is_low_contrast:
        quality_flags.append(f"low_contrast_{contrast_score:.1f}<{settings.CONTRAST_MIN_THRESHOLD}")

    is_low_quality = is_too_dark or is_too_bright or is_blurry or is_low_contrast

    return QualityMetrics(
        brightness_mean=round(brightness_mean, 2),
        brightness_std=round(brightness_std, 2),
        blur_score=round(blur_score, 2),
        contrast_score=round(contrast_score, 2),
        is_too_dark=is_too_dark,
        is_too_bright=is_too_bright,
        is_blurry=is_blurry,
        is_low_contrast=is_low_contrast,
        is_low_quality=is_low_quality,
        quality_flags=quality_flags,
    )


def enhance_frame_luminance(
    frame: np.ndarray,
    clip_limit: float = None,
    tile_grid_size: Tuple[int, int] = None,
    apply_bilateral: bool = None,
) -> Tuple[np.ndarray, Dict[str, any]]:
    """
    Configurable luminance enhancement pipeline on poor-quality sewer frames.
    Applies CLAHE specifically on the LAB Luminance (L) channel, followed
    by bilateral filtering to reduce noise while strictly preserving defect edges.

    Args:
        frame: Original BGR image.
        clip_limit: CLAHE clip limit (default from settings).
        tile_grid_size: CLAHE tile grid size (default from settings).
        apply_bilateral: Whether to apply bilateral edge-preserving smoothing.

    Returns:
        Tuple of (enhanced_frame, enhancement_metadata).
    """
    if clip_limit is None:
        clip_limit = settings.CLAHE_CLIP_LIMIT
    if tile_grid_size is None:
        tile_grid_size = settings.CLAHE_GRID_SIZE
    if apply_bilateral is None:
        apply_bilateral = settings.ENABLE_BILATERAL_FILTER

    # 1. Convert BGR to LAB color space
    lab = cv2.cvtColor(frame, cv2.COLOR_BGR2LAB)
    l_channel, a_channel, b_channel = cv2.split(lab)

    # 2. Apply CLAHE on Luminance (L) channel using adapter
    enhanced_l = cool_adapter.apply_clahe(
        l_channel, clip_limit=clip_limit, tile_grid_size=tile_grid_size
    )

    # 3. Merge channels back
    lab_enhanced = cv2.merge((enhanced_l, a_channel, b_channel))
    bgr_enhanced = cv2.cvtColor(lab_enhanced, cv2.COLOR_LAB2BGR)

    # 4. Optional bilateral filter to suppress sensor noise in dark pipe interiors
    if apply_bilateral:
        bgr_enhanced = cool_adapter.apply_bilateral_filter(
            bgr_enhanced,
            d=settings.BILATERAL_DIAMETER,
            sigma_color=settings.BILATERAL_SIGMA_COLOR,
            sigma_space=settings.BILATERAL_SIGMA_SPACE,
        )

    # 5. Measure resulting quality on enhanced frame
    new_quality = compute_image_quality(bgr_enhanced)

    metadata = {
        "clahe_applied": True,
        "clip_limit": clip_limit,
        "tile_grid_size": list(tile_grid_size),
        "bilateral_applied": apply_bilateral,
        "new_brightness": new_quality.brightness_mean,
        "new_blur_score": new_quality.blur_score,
        "new_contrast": new_quality.contrast_score,
        "is_improved": not new_quality.is_too_dark,
    }

    return bgr_enhanced, metadata


def compare_detection_candidates(
    orig_detections: List[Dict],
    enhanced_detections: List[Dict],
) -> Dict[str, any]:
    """
    Compare detection results between original and enhanced frames.
    Determines whether enhancement yielded more confident or new defect candidates.
    """
    orig_count = len(orig_detections)
    enh_count = len(enhanced_detections)

    orig_max_conf = max([d.get("confidence", 0.0) for d in orig_detections], default=0.0)
    enh_max_conf = max([d.get("confidence", 0.0) for d in enhanced_detections], default=0.0)

    conf_delta = round(enh_max_conf - orig_max_conf, 3)

    if enh_count > orig_count:
        outcome = "recovered_additional_defects"
    elif conf_delta > 0.05:
        outcome = "confidence_improved"
    elif enh_count < orig_count:
        outcome = "potential_distortion_suppressed"
    else:
        outcome = "comparable_results"

    return {
        "orig_count": orig_count,
        "enhanced_count": enh_count,
        "orig_max_conf": orig_max_conf,
        "enhanced_max_conf": enh_max_conf,
        "conf_delta": conf_delta,
        "outcome": outcome,
    }

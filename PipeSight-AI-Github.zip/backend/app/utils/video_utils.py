"""
Video decoding, validation, encoding, and overlay utilities using OpenCV 5.
"""

import os
from pathlib import Path
from typing import List, Optional, Tuple
import cv2
import numpy as np

from app.schemas import DetectionBox, QualityMetrics, VideoMetadata

# Distinct, high-contrast BGR colors for each of the 7 sewer defect classes
CLASS_COLORS = {
    0: (255, 180, 0),    # Buckling: Cyan/Amber
    1: (0, 0, 255),      # Crack: Bright Red
    2: (0, 200, 255),    # Debris: Gold/Yellow
    3: (255, 0, 200),    # Hole: Magenta/Purple
    4: (255, 100, 50),   # Joint offset: Blue/Cyan
    5: (50, 160, 255),   # Obstacle: Orange
    6: (0, 140, 255),    # Utility intrusion: Orange/Amber
}
DEFAULT_COLOR = (0, 255, 128)  # Bright Green


def format_timestamp(seconds: float) -> str:
    """Format seconds into HH:MM:SS.mmm string."""
    millis = int((seconds - int(seconds)) * 1000)
    minutes, secs = divmod(int(seconds), 60)
    hours, minutes = divmod(minutes, 60)
    return f"{hours:02d}:{minutes:02d}:{secs:02d}.{millis:03d}"


def validate_video_file(file_path: str, max_size_bytes: int = 500 * 1024 * 1024) -> VideoMetadata:
    """
    Validate that an uploaded video file exists, is within size limits,
    can be opened by OpenCV 5, and decodes actual video frames.

    Args:
        file_path: Path to video file.
        max_size_bytes: Maximum allowed file size.

    Returns:
        VideoMetadata with duration, fps, resolution, frame counts.

    Raises:
        ValueError: If video is missing, oversized, or unreadable by OpenCV 5.
    """
    path = Path(file_path)
    if not path.is_file():
        raise ValueError(f"Video file does not exist: {file_path}")

    file_size = path.stat().st_size
    if file_size == 0:
        raise ValueError("Video file is empty (0 bytes).")
    if file_size > max_size_bytes:
        raise ValueError(f"Video file exceeds maximum size limit of {max_size_bytes // (1024*1024)} MB.")

    cap = cv2.VideoCapture(str(path))
    if not cap.isOpened():
        raise ValueError("Failed to open video. The file is corrupted or encoded in an unsupported codec.")

    fps = cap.get(cv2.CAP_PROP_FPS)
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

    # Read the first frame to confirm real decoding
    ret, test_frame = cap.read()
    cap.release()

    if not ret or test_frame is None or test_frame.size == 0:
        raise ValueError("Failed to decode video frames. Stream may be corrupted or truncated.")

    # Guard against invalid or 0 FPS metadata
    if fps <= 0 or np.isnan(fps):
        fps = 25.0
    if total_frames <= 0:
        total_frames = 1

    duration_sec = total_frames / fps

    return VideoMetadata(
        filename=path.name,
        duration_sec=round(duration_sec, 2),
        fps=round(fps, 2),
        width=width,
        height=height,
        total_frames=total_frames,
        processed_frames=0,
    )


def compute_aspect_preserving_dimensions(
    orig_w: int,
    orig_h: int,
    max_dim: int = 640,
) -> Tuple[int, int, float]:
    """
    Computes dimensions to fit within max_dim x max_dim preserving original aspect ratio.
    If both dimensions are already <= max_dim, returns original dimensions with scale 1.0.
    Dimensions are constrained to even integers for video encoder compatibility.

    Returns:
        Tuple of (target_width, target_height, scale_factor).
    """
    if orig_w <= max_dim and orig_h <= max_dim:
        return orig_w, orig_h, 1.0

    scale = min(max_dim / orig_w, max_dim / orig_h)
    target_w = int(round(orig_w * scale))
    target_h = int(round(orig_h * scale))

    # Video codecs require even widths and heights
    target_w = target_w if target_w % 2 == 0 else target_w - 1
    target_h = target_h if target_h % 2 == 0 else target_h - 1

    actual_scale = target_w / orig_w
    return target_w, target_h, actual_scale


def resize_frame_if_needed(
    frame: np.ndarray,
    target_w: int,
    target_h: int,
) -> np.ndarray:
    """
    Resize frame using cv2.INTER_AREA for efficient downscaling.
    Avoids copying if dimensions already match target.
    """
    h, w = frame.shape[:2]
    if w == target_w and h == target_h:
        return frame
    return cv2.resize(frame, (target_w, target_h), interpolation=cv2.INTER_AREA)


def create_video_writer(
    output_path: str,
    fps: float,
    width: int,
    height: int,
) -> cv2.VideoWriter:
    """
    Create an OpenCV 5 VideoWriter using compatible MP4 codecs.
    Tries mp4v and avc1 codecs.
    """
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)

    # Try preferred codecs in order
    codecs = ["mp4v", "avc1", "H264", "XVID"]
    writer = None

    for codec in codecs:
        fourcc = cv2.VideoWriter_fourcc(*codec)
        writer = cv2.VideoWriter(output_path, fourcc, fps, (width, height))
        if writer.isOpened():
            break

    if writer is None or not writer.isOpened():
        raise RuntimeError(f"Failed to initialize OpenCV VideoWriter for output: {output_path}")

    return writer


def draw_inspection_overlay(
    frame: np.ndarray,
    detections: List[DetectionBox],
    timestamp_sec: float,
    frame_idx: int,
    quality: Optional[QualityMetrics] = None,
    enhanced: bool = False,
    is_skipped: bool = False,
) -> np.ndarray:
    """
    Render clean, professional OpenCV 5 inspection overlays on the frame.
    Includes bounding boxes, class labels, confidence, track IDs, timestamp,
    and quality / enhancement / stride indicators.
    """
    out = frame.copy()
    h, w = out.shape[:2]

    # 1. Top HUD Banner
    banner_height = 42
    cv2.rectangle(out, (0, 0), (w, banner_height), (20, 24, 30), -1)
    cv2.line(out, (0, banner_height), (w, banner_height), (60, 70, 85), 1)

    time_str = format_timestamp(timestamp_sec)
    header_text = f"PipeSight AI | Time: {time_str} | Frame: {frame_idx}"
    cv2.putText(
        out,
        header_text,
        (15, 26),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.65,
        (240, 240, 240),
        2,
        cv2.LINE_AA,
    )

    # Status badge (top right)
    badge_x = max(10, w - 250)
    if is_skipped:
        cv2.rectangle(out, (badge_x, 8), (w - 15, 34), (45, 55, 72), -1)
        cv2.putText(
            out,
            "STRIDE SKIPPED",
            (badge_x + 8, 25),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.48,
            (160, 174, 192),
            1,
            cv2.LINE_AA,
        )
    elif enhanced:
        cv2.rectangle(out, (badge_x, 8), (w - 15, 34), (40, 100, 20), -1)
        cv2.putText(
            out,
            "CLAHE ENHANCED",
            (badge_x + 10, 25),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.50,
            (100, 255, 120),
            1,
            cv2.LINE_AA,
        )
    elif quality and quality.is_too_dark:
        cv2.rectangle(out, (badge_x, 8), (w - 15, 34), (20, 40, 120), -1)
        cv2.putText(
            out,
            "LOW LIGHT WARNING",
            (badge_x + 8, 25),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.48,
            (100, 180, 255),
            1,
            cv2.LINE_AA,
        )

    # 2. Render Detections
    for det in detections:
        color = CLASS_COLORS.get(det.class_id, DEFAULT_COLOR)
        x1, y1, x2, y2 = [int(v) for v in det.bbox]
        x1, y1 = max(0, x1), max(0, y1)
        x2, y2 = min(w, x2), min(h, y2)

        # Bounding box
        cv2.rectangle(out, (x1, y1), (x2, y2), color, 2)

        # Label tag
        track_part = f"Track #{det.track_id} | " if det.track_id is not None else ""
        label = f"{track_part}{det.class_name} {det.confidence:.2f}"

        # Label background
        (lbl_w, lbl_h), baseline = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.50, 1)
        tag_y1 = max(banner_height + 5, y1 - lbl_h - 8)
        tag_y2 = tag_y1 + lbl_h + 8

        cv2.rectangle(out, (x1, tag_y1), (x1 + lbl_w + 10, tag_y2), color, -1)
        cv2.putText(
            out,
            label,
            (x1 + 5, tag_y2 - 4),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.50,
            (255, 255, 255),
            1,
            cv2.LINE_AA,
        )

    return out

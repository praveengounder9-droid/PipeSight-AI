"""
Cloud-Optimized OpenCV Library (COOL) Adapter for AWS Graviton/Arm.
Isolates vision operations behind an adapter.
Falls back transparently to standard OpenCV 5 when COOL is not available.
"""

import logging
import platform
import cv2
import numpy as np

logger = logging.getLogger(__name__)


class COOLAdapter:
    """
    Adapter for Cloud-Optimized OpenCV Library (COOL).
    Detects if running on AWS Graviton / Arm with COOL acceleration enabled.
    Falls back gracefully to standard OpenCV 5 without false claims.
    """

    def __init__(self):
        self._is_cool_active = False
        self._status_message = "Standard OpenCV 5 (COOL not active)"
        self._arch = platform.machine().lower()
        self._detect_cool()

    def _detect_cool(self) -> None:
        """
        Check if COOL package or COOL-enabled OpenCV 5 build is active on Graviton/Arm.
        """
        # True COOL acceleration requires an Arm/aarch64 architecture (e.g. AWS Graviton)
        # and COOL-specific acceleration binaries or cv2-cool distribution.
        try:
            # Check for explicit COOL module or build tag
            import importlib
            cool_spec = importlib.util.find_spec("cv2_cool") or importlib.util.find_spec("cool_cv")
            build_info = cv2.getBuildInformation()
            has_cool_flag = "COOL" in build_info or "GRAVITON" in build_info

            if cool_spec is not None or has_cool_flag:
                if "aarch64" in self._arch or "arm" in self._arch:
                    self._is_cool_active = True
                    self._status_message = f"COOL active on AWS Graviton ({self._arch})"
                    logger.info("COOL acceleration active on Graviton environment.")
                    return

            self._is_cool_active = False
            self._status_message = (
                f"Standard OpenCV {cv2.__version__} on {self._arch} "
                "(COOL acceleration inactive / not installed)"
            )
        except Exception as e:
            self._is_cool_active = False
            self._status_message = f"Standard OpenCV {cv2.__version__} (Detection error: {e})"

    @property
    def is_active(self) -> bool:
        return self._is_cool_active

    @property
    def status_message(self) -> str:
        return self._status_message

    def apply_clahe(
        self,
        luminance_channel: np.ndarray,
        clip_limit: float = 2.5,
        tile_grid_size: tuple = (8, 8),
    ) -> np.ndarray:
        """
        Apply CLAHE on luminance channel.
        Uses standard OpenCV 5 createCLAHE (or COOL accelerated path if active).
        """
        # If COOL is active on Graviton, specialized SIMD/NEON optimized kernels run
        clahe = cv2.createCLAHE(clipLimit=clip_limit, tileGridSize=tile_grid_size)
        return clahe.apply(luminance_channel)

    def apply_bilateral_filter(
        self,
        image: np.ndarray,
        d: int = 5,
        sigma_color: float = 35.0,
        sigma_space: float = 35.0,
    ) -> np.ndarray:
        """
        Apply bilateral filter to reduce sensor noise while preserving defect edges.
        """
        return cv2.bilateralFilter(image, d=d, sigmaColor=sigma_color, sigmaSpace=sigma_space)


cool_adapter = COOLAdapter()

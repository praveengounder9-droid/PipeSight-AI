"""
Utilities for PipeSight AI backend: image quality, enhancement, and video processing.
"""

from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple
from pydantic import BaseModel, Field


class JobStatus(str, Enum):
    QUEUED = "queued"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"


class AgentDecision(str, Enum):
    CONTINUE = "CONTINUE"
    ENHANCE_AND_RECHECK = "ENHANCE_AND_RECHECK"
    INSPECT_ADJACENT_FRAMES = "INSPECT_ADJACENT_FRAMES"
    REQUEST_HUMAN_REVIEW = "REQUEST_HUMAN_REVIEW"
    LOG_AND_CONTINUE = "LOG_AND_CONTINUE"


class HealthResponse(BaseModel):
    status: str = "healthy"
    opencv_version: str
    torch_version: str
    ultralytics_version: str
    cool_enabled: bool = False
    cool_status: str = "Standard OpenCV 5 (COOL not active)"
    model_loaded: bool
    model_name: str = "YOLO26s Sewer Defect Detector"
    device: str
    classes_count: int
    capabilities: List[str]


class SystemInfoResponse(BaseModel):
    model_name: str
    class_names: Dict[int, str]
    class_count: int
    confidence_threshold: float
    iou_threshold: float
    frame_stride: int = 3
    max_processing_dim: int = 640
    supported_file_types: List[str]
    supported_processing_modes: List[str]
    storage_backend: str
    model_metric_map50: str
    model_limitations_notice: str
    retention_hours: int = 24
    storage_notice: Optional[str] = None


class QualityMetrics(BaseModel):
    brightness_mean: float
    brightness_std: float
    blur_score: float
    contrast_score: float
    is_too_dark: bool = False
    is_too_bright: bool = False
    is_blurry: bool = False
    is_low_contrast: bool = False
    is_low_quality: bool = False
    quality_flags: List[str] = Field(default_factory=list)


class DetectionBox(BaseModel):
    class_id: int
    class_name: str
    confidence: float
    bbox: List[float]  # [x1, y1, x2, y2]
    track_id: Optional[int] = None
    frame_idx: int
    timestamp_sec: float
    enhanced: bool = False


class TrackEvent(BaseModel):
    track_id: int
    class_id: int
    class_name: str
    advisory_label: str  # e.g. "Suspected Crack" or "Model-predicted Root Intrusion"
    observation_count: int
    first_seen_sec: float
    last_seen_sec: float
    duration_sec: float
    peak_confidence: float
    avg_confidence: float
    representative_frame_idx: int
    representative_timestamp_sec: float
    representative_bbox: List[float]
    evidence_image_key: Optional[str] = None
    evidence_image_url: Optional[str] = None


class AgentTraceStep(BaseModel):
    frame: int
    timestamp_sec: float
    observations: Dict[str, Any]
    decision: str
    action: str
    next_action: str
    outcome: str
    details: Optional[str] = None


class VideoMetadata(BaseModel):
    filename: str
    duration_sec: float
    fps: float
    width: int
    height: int
    total_frames: int
    processed_frames: int


class InspectionSummary(BaseModel):
    raw_detections_count: int
    estimated_unique_events_count: int
    events_by_class: Dict[str, int]
    low_quality_frames_count: int
    enhanced_frames_count: int


class AgentDecisionsSummary(BaseModel):
    total_actions: int
    action_counts: Dict[str, int]
    sample_traces: List[AgentTraceStep]


class ReportArtifacts(BaseModel):
    annotated_video_url: Optional[str] = None
    pdf_report_url: Optional[str] = None
    evidence_images: List[Dict[str, Any]] = Field(default_factory=list)


class ModelIdentity(BaseModel):
    model_name: str
    classes: Dict[int, str]
    opencv_version: str
    ultralytics_version: str
    device: str


class PerformanceMetrics(BaseModel):
    original_resolution: Tuple[int, int]         # (width, height)
    processing_resolution: Tuple[int, int]       # (width, height)
    fps: float
    total_source_frames: int
    frames_processed: int
    frames_skipped: int
    frame_stride: int
    confidence_threshold: float
    video_duration_sec: float
    actual_processing_duration_sec: float
    processing_fps: float
    time_breakdown_sec: Dict[str, float] = Field(default_factory=dict)
    enhancement_retries: int = 0
    candidate_defect_events_count: int = 0
    processing_limitations: List[str] = Field(default_factory=list)


class InspectionReport(BaseModel):
    job_id: str
    created_at_utc: str
    completed_at_utc: Optional[str] = None
    model_identity: ModelIdentity
    video_statistics: VideoMetadata
    summary: InspectionSummary
    defect_events: List[TrackEvent]
    agent_decisions_summary: AgentDecisionsSummary
    performance_metrics: Optional[PerformanceMetrics] = None
    artifacts: ReportArtifacts
    limitations_and_disclosures: Dict[str, Any]


class JobCreationResponse(BaseModel):
    job_id: str
    status: JobStatus
    filename: str
    file_size_bytes: int
    message: str
    created_at: str
    status_url: str


class JobStatusResponse(BaseModel):
    job_id: str
    status: JobStatus
    progress_pct: float
    current_frame: int
    total_frames: int
    frames_processed: Optional[int] = 0
    frames_skipped: Optional[int] = 0
    frame_stride: Optional[int] = 3
    processing_fps: Optional[float] = None
    elapsed_sec: float
    estimated_time_remaining_sec: Optional[float] = None
    error_message: Optional[str] = None
    report_url: Optional[str] = None
    video_url: Optional[str] = None
    pdf_url: Optional[str] = None
    zip_url: Optional[str] = None
    updated_at: str


class EvidenceItem(BaseModel):
    evidence_id: str
    track_id: Optional[int]
    class_name: str
    confidence: float
    frame_idx: int
    timestamp_sec: float
    url: str
    key: str


class EvidenceListResponse(BaseModel):
    job_id: str
    count: int
    evidence_items: List[EvidenceItem]


class ImageInspectionResponse(BaseModel):
    filename: str
    quality_metrics: QualityMetrics
    agent_decision: str
    agent_action: str
    detections: List[DetectionBox]
    annotated_image_url: Optional[str] = None
    notice: str

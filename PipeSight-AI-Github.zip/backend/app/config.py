import os
import sys
from pathlib import Path
from typing import List, Optional, Tuple
import torch
from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


def _resolve_model_path() -> str:
    """Find the best.pt checkpoint from common local paths."""
    env_path = os.getenv("MODEL_PATH")
    if env_path and Path(env_path).is_file():
        return str(Path(env_path).resolve())

    # Candidate locations
    candidates = [
        Path(__file__).resolve().parent.parent / "models" / "best.pt",
        Path(__file__).resolve().parent.parent.parent / "best.pt",
        Path("models/best.pt"),
        Path("best.pt"),
        Path("../best.pt"),
    ]
    for c in candidates:
        if c.is_file():
            return str(c.resolve())
    return "models/best.pt"


def _resolve_tracker_path() -> str:
    """Find the bytetrack.yaml tracker config."""
    env_path = os.getenv("TRACKER_CONFIG_PATH")
    if env_path and Path(env_path).is_file():
        return str(Path(env_path).resolve())

    candidates = [
        Path(__file__).resolve().parent.parent / "trackers" / "bytetrack.yaml",
        Path("trackers/bytetrack.yaml"),
        Path("../trackers/bytetrack.yaml"),
    ]
    for c in candidates:
        if c.is_file():
            return str(c.resolve())
    return "bytetrack.yaml"


def _detect_device() -> str:
    """Detect available compute device (cuda if available, else cpu)."""
    env_dev = os.getenv("DEVICE")
    if env_dev:
        return env_dev
    return "cuda:0" if torch.cuda.is_available() else "cpu"


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # General API Configuration
    APP_NAME: str = "PipeSight AI - Agentic Sewer Inspection Backend"
    API_PREFIX: str = "/api/v1"
    VERSION: str = "1.0.0"
    DEBUG: bool = False
    HOST: str = "0.0.0.0"
    PORT: int = 8000
    CORS_ORIGINS: List[str] = ["*"]

    # Model & Inference Settings (Explicit CPU Performance)
    MODEL_PATH: str = Field(default_factory=_resolve_model_path)
    TRACKER_CONFIG_PATH: str = Field(default_factory=_resolve_tracker_path)
    CONFIDENCE_THRESHOLD: float = 0.25
    IOU_THRESHOLD: float = 0.45
    INFERENCE_IMGSZ: int = 640
    MAX_PROCESSING_DIM: int = 640            # Fit inside 640x640 bounding box preserving aspect ratio
    DEVICE: str = "cpu"                      # Explicitly use CPU; avoid CUDA initialization
    CPU_NUM_THREADS: int = Field(default_factory=lambda: max(1, min(os.cpu_count() or 4, 8)))

    # Image Quality Thresholds (OpenCV 5 analysis)
    BRIGHTNESS_MIN_THRESHOLD: float = 40.0   # Genuine low-light threshold (<40 = genuinely dark)
    BRIGHTNESS_MAX_THRESHOLD: float = 220.0  # Above this, frame is flagged overexposed
    BLUR_THRESHOLD: float = 45.0             # Laplacian variance threshold
    CONTRAST_MIN_THRESHOLD: float = 25.0     # Standard deviation threshold

    # Enhancement Settings (Luminance CLAHE + Bilateral)
    ENABLE_CLAHE_ENHANCEMENT: bool = True
    ENABLE_BILATERAL_FILTER: bool = True
    CLAHE_CLIP_LIMIT: float = 2.5
    CLAHE_GRID_SIZE: Tuple[int, int] = (8, 8)
    BILATERAL_DIAMETER: int = 5
    BILATERAL_SIGMA_COLOR: float = 35.0
    BILATERAL_SIGMA_SPACE: float = 35.0

    # Agentic Vision Controller Settings
    MAX_RETRIES_PER_FRAME: int = 1           # Strict limit: at most 1 additional inference per selected frame
    UNCERTAIN_CONF_LOWER: float = 0.25
    UNCERTAIN_CONF_UPPER: float = 0.42
    FRAME_STRIDE: int = 3                    # Default: process every 3rd frame on CPU (set to 1 for full inspection)

    # Video Upload & Limits
    MAX_UPLOAD_SIZE_MB: int = 500
    ALLOWED_EXTENSIONS: List[str] = [".mp4", ".avi", ".mov", ".mkv", ".webm"]

    # Storage Backend & Temporary Retention Settings
    STORAGE_BACKEND: str = "local"  # "local" or "s3"
    LOCAL_STORAGE_DIR: str = str(Path(__file__).resolve().parent.parent / "storage")
    S3_BUCKET_NAME: str = "pipesight-ai-inspections"
    AWS_REGION: str = "us-east-1"
    PRESIGNED_URL_EXPIRY_SEC: int = 3600
    RETENTION_HOURS: int = 24                # Automatic purge cutoff for completed/failed jobs
    MIN_FREE_DISK_MB: int = 500              # Safeguard: minimum required disk space for video uploads
    STORAGE_NOTICE: str = (
        "Notice: Inspection artifacts are stored temporarily on the server and will be automatically "
        "purged after 24 hours. Please download your reports (PDF, JSON, MP4, or ZIP) before cleanup."
    )

    # Model Prototype Metrics and Clear Disclosure Notice
    MODEL_METRIC_MAP50: str = "42.6%"
    MODEL_LIMITATIONS_NOTICE: str = (
        "PipeSight AI is an experimental prototype. The current sewer defect detection model "
        "achieved approximately 42.6% mAP@50 on the held-out test dataset. Predictions are model-assisted "
        "advisory detections and may be subject to false positives, missed defects, or identity switches. "
        "Frame sampling (stride > 1) optimizes CPU throughput but may miss small or short-lived defects; "
        "full-frame inspection (stride = 1) is available when exhaustive analysis is required. "
        "Ordinary monocular camera video does not provide calibrated physical dimensions or pipe distances. "
        "All findings require manual engineering verification by certified pipeline inspection personnel."
    )


settings = Settings()

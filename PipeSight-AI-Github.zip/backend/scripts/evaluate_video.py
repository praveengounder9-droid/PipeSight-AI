"""
PipeSight AI - Video Evaluation and Diagnostic Benchmark Script.
Evaluates model throughput, ByteTrack tracking stability, agent enhancement decisions,
and exports machine-readable evaluation results.

Usage:
    python scripts/evaluate_video.py --video path/to/inspection.mp4 --output evaluation_results.json
"""

import argparse
from datetime import datetime, timezone
import json
import logging
from pathlib import Path
import sys
import time
import cv2
import numpy as np

# Ensure backend root is in python path
backend_dir = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(backend_dir))

from app.config import settings
from app.schemas import DetectionBox
from app.services.agent_service import AgentVisionController
from app.services.tracking_service import TrackingService
from app.services.vision_service import vision_service
from app.utils.video_utils import draw_inspection_overlay, validate_video_file

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger("evaluate_video")


def evaluate_video(
    video_path: str,
    output_json_path: str = "evaluation_report.json",
    conf_threshold: float = None,
    save_failure_cases: bool = True,
    sample_rate: int = 1,
) -> dict:
    """
    Run the PipeSight AI vision and agentic tracking pipeline on a benchmark video.
    """
    path = Path(video_path).resolve()
    if not path.is_file():
        raise FileNotFoundError(f"Video file not found: {video_path}")

    logger.info(f"Validating video stream: {path.name}")
    meta = validate_video_file(str(path))
    logger.info(
        f"Video specs: {meta.width}x{meta.height} @ {meta.fps:.1f} fps, "
        f"{meta.total_frames} frames ({meta.duration_sec:.1f}s)"
    )

    # Initialize services
    vision_service.reset_tracker()
    job_id = f"eval_{int(time.time())}"
    agent = AgentVisionController(job_id=job_id, vision_svc=vision_service)
    tracker = TrackingService(job_id=job_id)

    cap = cv2.VideoCapture(str(path))
    processed_frames = 0
    raw_detections_count = 0
    low_light_frames = 0
    enhanced_frames = 0
    inference_durations = []

    # Failure / challenging cases tracking
    failure_cases = []
    output_dir = Path(output_json_path).parent / f"failure_cases_{job_id}"
    if save_failure_cases:
        output_dir.mkdir(parents=True, exist_ok=True)

    start_wall_time = time.time()
    frame_idx = 0

    while cap.isOpened():
        ret, frame = cap.read()
        if not ret or frame is None:
            break

        if frame_idx % sample_rate != 0:
            frame_idx += 1
            continue

        timestamp_sec = frame_idx / meta.fps
        t0 = time.perf_counter()

        # Step agent perception-decision-action loop
        rendered_frame, detections, quality, enhanced = agent.step(
            frame=frame,
            frame_idx=frame_idx,
            timestamp_sec=timestamp_sec,
        )
        t_infer = time.perf_counter() - t0
        inference_durations.append(t_infer)

        if quality.is_low_quality:
            low_light_frames += 1
        if enhanced:
            enhanced_frames += 1

        raw_detections_count += len(detections)
        tracker.add_detections(detections, frame=rendered_frame)

        # Flag challenging cases (e.g. low blur score, high noise, or low confidence detections)
        if save_failure_cases and quality.is_low_quality and len(failure_cases) < 10:
            failure_filename = f"failure_frame_{frame_idx}.jpg"
            failure_path = output_dir / failure_filename
            cv2.imwrite(str(failure_path), rendered_frame)
            failure_cases.append({
                "frame": frame_idx,
                "timestamp_sec": round(timestamp_sec, 2),
                "quality_flags": quality.quality_flags,
                "brightness": quality.brightness_mean,
                "blur_score": quality.blur_score,
                "saved_image": str(failure_path.name),
            })

        processed_frames += 1
        frame_idx += 1

    cap.release()
    total_elapsed = time.time() - start_wall_time
    avg_fps = round(processed_frames / max(0.001, total_elapsed), 2)
    avg_latency_ms = round(float(np.mean(inference_durations) * 1000), 2) if inference_durations else 0.0

    # Aggregate tracking events
    events = tracker.aggregate_events()
    agent_summary = agent.get_summary()

    # Track ID stability analysis
    track_ids = [e.track_id for e in events]
    duplicate_tracks_warning = len(track_ids) != len(set(track_ids))

    evaluation_report = {
        "evaluation_timestamp_utc": datetime.now(timezone.utc).isoformat(),
        "video_path": str(path),
        "video_metadata": meta.model_dump(),
        "performance_metrics": {
            "total_wall_time_sec": round(total_elapsed, 2),
            "processed_frames": processed_frames,
            "average_processing_fps": avg_fps,
            "average_frame_latency_ms": avg_latency_ms,
            "device": vision_service.device,
        },
        "quality_and_agent_metrics": {
            "low_light_frames_count": low_light_frames,
            "enhanced_frames_count": enhanced_frames,
            "total_agent_decisions": agent_summary.total_actions,
            "agent_action_breakdown": agent_summary.action_counts,
        },
        "detection_and_tracking_metrics": {
            "total_raw_detections": raw_detections_count,
            "unique_tracked_events_count": len(events),
            "duplicate_tracks_flag": duplicate_tracks_warning,
            "events_summary": [e.model_dump() for e in events],
        },
        "failure_cases": failure_cases,
        "model_limitations_notice": settings.MODEL_LIMITATIONS_NOTICE,
    }

    out_file = Path(output_json_path)
    out_file.parent.mkdir(parents=True, exist_ok=True)
    with open(out_file, "w", encoding="utf-8") as f:
        json.dump(evaluation_report, f, indent=2)

    logger.info(f"Evaluation complete! Results exported to: {out_file.resolve()}")
    logger.info(f"Summary: {processed_frames} frames @ {avg_fps} FPS | {len(events)} defect events")

    return evaluation_report


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="PipeSight AI Video Evaluation Benchmark")
    parser.add_argument("--video", type=str, required=True, help="Path to inspection video")
    parser.add_argument("--output", type=str, default="evaluation_report.json", help="Path to output JSON")
    parser.add_argument("--conf", type=float, default=None, help="Confidence threshold")
    parser.add_argument("--sample-rate", type=int, default=1, help="Process every Nth frame")
    parser.add_argument("--no-failure-cases", action="store_true", help="Disable saving failure case images")

    args = parser.parse_args()
    evaluate_video(
        video_path=args.video,
        output_json_path=args.output,
        conf_threshold=args.conf,
        save_failure_cases=not args.no_failure_cases,
        sample_rate=args.sample_rate,
    )

import time
import requests

from pathlib import Path

base_url = "http://127.0.0.1:8000"
video_file = Path("test_sewer_pipe.mp4")
if not video_file.is_file():
    video_file = Path("sample_evaluation_video.mp4")
if not video_file.is_file():
    video_file = Path(__file__).resolve().parent.parent / "test_sewer_pipe.mp4"
if not video_file.is_file():
    video_file = Path(__file__).resolve().parent.parent / "sample_evaluation_video.mp4"

# 1. Health check
r = requests.get(f"{base_url}/health")
health = r.json()
print("[1/4] Health Check OK:", health["status"], "| OpenCV:", health["opencv_version"], "| Model:", health["model_name"])

# 2. Upload video
with open(video_file, "rb") as f:
    r = requests.post(f"{base_url}/api/v1/inspect/video", files={"file": (video_file.name, f, "video/mp4")})

job = r.json()
job_id = job["job_id"]
print(f"[2/4] Upload Accepted: Job ID = {job_id}, Status = {job['status']}")

# 3. Poll progress
print("[3/4] Polling job execution...")
start = time.time()
while time.time() - start < 30:
    st = requests.get(f"{base_url}/api/v1/inspect/{job_id}").json()
    fps_str = f"{st.get('processing_fps'):.1f}" if st.get("processing_fps") else "N/A"
    print(f"   -> Status: {st['status']} ({st['progress_pct']:.1f}%), Frame: {st['current_frame']}/{st['total_frames']}, FPS: {fps_str}")
    if st["status"] in ("completed", "failed"):
        break
    time.sleep(0.6)

# 4. Check outputs
if st["status"] == "completed":
    print("[4/4] Inspection Completed Successfully!")
    print("   -> Annotated Video URL:", st.get("video_url"))
    print("   -> PDF Report URL:     ", st.get("pdf_url"))
    print("   -> Results ZIP URL:    ", st.get("zip_url"))
    
    zip_r = requests.get(f"{base_url}/api/v1/inspect/{job_id}/zip")
    print(f"   -> Downloaded ZIP Size : {len(zip_r.content) / 1024:.1f} KB (Magic: {zip_r.content[:2]})")
    
    pdf_r = requests.get(f"{base_url}/api/v1/inspect/{job_id}/report.pdf")
    print(f"   -> Downloaded PDF Size : {len(pdf_r.content) / 1024:.1f} KB (Magic: {pdf_r.content[:4]})")
else:
    print("Job did not complete:", st.get("error_message"))

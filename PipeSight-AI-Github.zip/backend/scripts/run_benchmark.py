"""
Benchmark test comparing optimized pipeline against baseline.
Uploads test_sewer_pipe.mp4 to live backend, polls status, prints performance metrics,
and validates report and artifacts.
"""

import json
import time
from pathlib import Path
import requests

API_URL = "http://127.0.0.1:8000/api/v1"
VIDEO_PATH = Path(__file__).resolve().parent.parent / "test_sewer_pipe.mp4"

def run_benchmark():
    assert VIDEO_PATH.is_file(), f"Test video not found: {VIDEO_PATH}"
    print(f"Uploading {VIDEO_PATH.name} ({VIDEO_PATH.stat().st_size} bytes) to {API_URL}/inspect/video...")

    t0 = time.perf_counter()
    with open(VIDEO_PATH, "rb") as f:
        resp = requests.post(f"{API_URL}/inspect/video", files={"file": (VIDEO_PATH.name, f, "video/mp4")})

    assert resp.status_code == 202, f"Failed: {resp.status_code} {resp.text}"
    job_id = resp.json()["job_id"]
    print(f"Job registered: {job_id}")

    # Poll status
    while True:
        status_resp = requests.get(f"{API_URL}/inspect/{job_id}")
        assert status_resp.status_code == 200
        data = status_resp.json()
        status = data["status"]
        progress = data.get("progress_pct", 0)
        cur_fps = data.get("processing_fps")
        print(f"Status: {status} | Progress: {progress}% | Current FPS: {cur_fps}")

        if status in ("completed", "failed"):
            break
        time.sleep(0.5)

    total_wall_time = time.perf_counter() - t0
    assert status == "completed", f"Job failed: {data.get('error_message')}"

    # Fetch report
    report_resp = requests.get(f"{API_URL}/inspect/{job_id}/report")
    assert report_resp.status_code == 200
    report = report_resp.json()

    # Fetch PDF
    pdf_resp = requests.get(f"{API_URL}/inspect/{job_id}/report.pdf")
    assert pdf_resp.status_code == 200
    assert len(pdf_resp.content) > 1000

    # Fetch Video
    vid_resp = requests.get(f"{API_URL}/inspect/{job_id}/video", headers={"Range": "bytes=0-1024"})
    assert vid_resp.status_code in (200, 206)

    # Fetch Evidence
    ev_resp = requests.get(f"{API_URL}/inspect/{job_id}/evidence")
    assert ev_resp.status_code == 200

    perf = report.get("performance_metrics", {})

    print("\n" + "=" * 60)
    print("           BENCHMARK EXECUTION RESULTS")
    print("=" * 60)
    print(f"Total Source Frames:     {report['video_statistics']['total_frames']}")
    print(f"Original Resolution:     {perf.get('original_resolution')}")
    print(f"Processing Resolution:   {perf.get('processing_resolution')}")
    print(f"Frame Stride:            {perf.get('frame_stride')}")
    print(f"Frames Processed:        {perf.get('frames_processed')}")
    print(f"Frames Skipped:          {perf.get('frames_skipped')}")
    print(f"Enhancement Retries:     {perf.get('enhancement_retries')}")
    print(f"Candidate Defect Events: {perf.get('candidate_defect_events_count')}")
    print(f"Video Duration:          {perf.get('video_duration_sec')}s")
    print(f"Actual Processing Time:  {perf.get('actual_processing_duration_sec')}s")
    print(f"Processing Speed:        {perf.get('processing_fps')} FPS")
    print(f"Total Wall Clock Time:   {total_wall_time:.2f}s")
    print("\nStage Time Breakdown:")
    for k, v in perf.get("time_breakdown_sec", {}).items():
        print(f"  - {k:35s}: {v:.3f}s")

    print("\nVerification Checklist:")
    print(f"  [x] JSON Report available: {len(report)} root keys")
    print(f"  [x] PDF Report size:       {len(pdf_resp.content)} bytes")
    print(f"  [x] Annotated Video:       playable stream verified")
    print(f"  [x] Evidence Items:        {ev_resp.json()['count']} items registered")
    print("=" * 60)

if __name__ == "__main__":
    run_benchmark()

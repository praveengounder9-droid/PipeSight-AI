# PipeSight AI — Model Weights Directory

This directory hosts the trained YOLO26s defect detection weights (`best.pt`) for PipeSight AI.

---

## 1. Model Checkpoint Policy

- **Do Not Commit Large Weights to Git**: The `best.pt` weights file (~20 MB) is excluded from version control via `.gitignore` to keep git history lightweight and secure.
- **Model Checkpoint**: `best.pt` (YOLO26s fine-tuned on CCTV sewer defect inspections).
- **Classes Detected**:
  - Class 0: `Crack`
  - Class 1: `Debris`
  - Class 2: `Joint_Fault`
  - Class 3: `Root_Intrusion`
  - Class 4: `Surface_Damage`

---

## 2. Secure Model Transfer to AWS EC2

When deploying to your AWS EC2 instance, copy your local `best.pt` model directly and securely to the remote instance using `scp` (SSH secure copy).

### Option A: Using `scp` from your local machine (Linux / macOS / Windows PowerShell)

Run this command from your local machine (replace `<PATH_TO_KEY.pem>` and `<EC2_PUBLIC_IP>` with your actual key path and EC2 public IP):

```bash
scp -i "<PATH_TO_KEY.pem>" backend/models/best.pt ubuntu@<EC2_PUBLIC_IP>:/var/www/pipesight/backend/models/best.pt
```

### Option B: Using SFTP / FileZilla / WinSCP

1. Connect to `<EC2_PUBLIC_IP>` via SFTP using port `22` and user `ubuntu`.
2. Provide your private key (`.pem` or `.ppk`).
3. Upload `best.pt` to `/var/www/pipesight/backend/models/best.pt`.
4. Ensure correct file permissions on EC2:
   ```bash
   sudo chown -R ubuntu:www-data /var/www/pipesight/backend/models
   chmod 644 /var/www/pipesight/backend/models/best.pt
   ```

---

## 3. Local Verification

To verify that the backend finds and loads `best.pt`:

```bash
# From backend directory
python -c "from app.services.vision_service import vision_service; print('Model loaded successfully:', vision_service.is_loaded())"
```

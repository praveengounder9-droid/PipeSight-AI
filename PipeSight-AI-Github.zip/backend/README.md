# PipeSight AI — Agentic Sewer Inspection and Diagnostic Backend

> **Autonomous CCTV Sewer Inspection Assistant Powered by OpenCV 5, Ultralytics YOLO26s, and ByteTrack**

---

## 1. System Architecture

PipeSight AI decouples perception, deterministic agentic decision-making, and diagnostic reporting into a modular, production-ready backend designed for high reliability on **AWS EC2** and **Amazon S3**.

```mermaid
flowchart TD
    subgraph ClientLayer [Client & Ingestion]
        Upload[Upload Sewer CCTV Video\nMultipart MP4/AVI/MOV]
        Upload -->|POST /api/v1/inspect/video| APIGateway[FastAPI Application Server\nUvicorn / Reverse Proxy]
    end

    subgraph ValidationLayer [OpenCV 5 Validation & Storage]
        APIGateway -->|Validate Headers & Codecs| VideoVal[OpenCV 5 VideoCapture Validator]
        VideoVal -->|Generate Unique Job ID| JobRegistry[In-Memory Job Registry\nStatus: QUEUED]
        VideoVal -->|Save Source Stream| StorageAdapter[Storage Service Adapter\nLocal Disk / Amazon S3]
    end

    subgraph AgenticPipeline [OpenCV 5 Agentic Vision Loop]
        JobRegistry -->|Worker Thread| AgentController[Deterministic Agent Controller]
        AgentController --> FrameDecode[OpenCV 5 Sequential Frame Decode]
        FrameDecode --> QualityCheck[Compute Brightness, Contrast & Laplacian Blur Score]
        QualityCheck -->|Low-Light Detected| CLAHE[Luminance Enhancement\nCLAHE on LAB L-Channel + Bilateral Filter]
        QualityCheck -->|Adequate Illumination| ModelInfer[YOLO26s Defect Detection\n7 Trained Sewer Classes]
        CLAHE --> ModelInfer
        ModelInfer --> ByteTrack[ByteTrack Tracking\nKalman Filter + IoU Association]
        ByteTrack --> TrackAggregator[Defect Event Aggregator\nDeduplication & Peak Frame Selection]
        TrackAggregator --> OverlayHUD[OpenCV 5 Diagnostic HUD Overlay\nAnnotated VideoWriter]
    end

    subgraph ArtifactGeneration [Diagnostic Reporting & Storage]
        OverlayHUD --> JSONReport[Structured JSON Report\nMetrics, Agent Trace, Events]
        OverlayHUD --> PDFReport[ReportLab Diagnostic PDF\nTables, Evidence Thumbnails, Limitations]
        OverlayHUD --> EvidenceImgs[Representative Defect Evidence JPEGs]
        JSONReport --> StorageAdapter
        PDFReport --> StorageAdapter
        EvidenceImgs --> StorageAdapter
        OverlayHUD --> S3Upload[Upload Annotated MP4\nAmazon S3 / Local Storage]
        S3Upload --> StorageAdapter
    end

    subgraph RetrievalLayer [RESTful Retrieval Endpoints]
        StorageAdapter --> StatusEP[GET /api/v1/inspect/{job_id}\nProgress, Frame Count, Status]
        StorageAdapter --> ReportEP[GET /api/v1/inspect/{job_id}/report\nFull JSON Report]
        StorageAdapter --> VideoEP[GET /api/v1/inspect/{job_id}/video\nAnnotated MP4 Stream / Presigned URL]
        StorageAdapter --> PDFEP[GET /api/v1/inspect/{job_id}/report.pdf\nDownload Signed PDF]
        StorageAdapter --> EvidenceEP[GET /api/v1/inspect/{job_id}/evidence\nList Evidence Images]
    end
```

---

## 2. Agentic Vision: Perception-Decision-Action Workflow

Unlike static computer vision pipelines that execute fixed detection routines, PipeSight AI employs a **deterministic, observable agent controller** where OpenCV 5 perceptual measurements change subsequent processing actions in real-time.

```mermaid
stateDiagram-v2
    [*] --> INSPECT: Read Frame & Compute Metrics

    state INSPECT {
        direction TB
        f1: Decode frame with OpenCV 5
        f2: Compute Brightness Mean & RMS Contrast
        f3: Compute Laplacian Blur Variance
        f4: Initial YOLO26s Detection & ByteTrack
        f1 --> f2 --> f3 --> f4
    }

    INSPECT --> ASSESS_QUALITY: Evaluate Quality Metrics

    state ASSESS_QUALITY {
        direction TB
        q1: Brightness < 40.0 OR Blur < 45.0?
    }

    ASSESS_QUALITY --> ENHANCE_AND_RECHECK: Yes (Low Quality Detected)
    ASSESS_QUALITY --> ASSESS_DETECTION: No (Quality Satisfactory)

    state ENHANCE_AND_RECHECK {
        direction TB
        e1: Tool Invoked - CLAHE on LAB L-Channel
        e2: Tool Invoked - Edge-Preserving Bilateral Filter
        e3: Rerun YOLO26s Inference on Enhanced Frame
        e4: Compare Detection Candidates & Score Delta
        e1 --> e2 --> e3 --> e4
    }

    ENHANCE_AND_RECHECK --> ASSESS_DETECTION: Evidence Compared

    state ASSESS_DETECTION {
        direction TB
        d1: Defect Confidence in Borderline Range [0.25, 0.42]?
        d2: Ambiguous Evidence after Enhancement?
    }

    ASSESS_DETECTION --> INSPECT_ADJACENT_FRAMES: Borderline / Track Instability
    ASSESS_DETECTION --> REQUEST_HUMAN_REVIEW: Low Light & Indeterminate Defect
    ASSESS_DETECTION --> CONTINUE: Confident Detections (>0.42)
    ASSESS_DETECTION --> LOG_AND_CONTINUE: Clean Pipe Wall

    state RECORD_ACTION {
        direction TB
        r1: Record Frame Index & Timestamp
        r2: Record OpenCV Observations (Brightness, Blur)
        r3: Record Decision, Tool Invoked & Outcome
        r4: Append to Machine-Readable Agent Trace
        r1 --> r2 --> r3 --> r4
    }

    INSPECT_ADJACENT_FRAMES --> RECORD_ACTION
    REQUEST_HUMAN_REVIEW --> RECORD_ACTION
    CONTINUE --> RECORD_ACTION
    LOG_AND_CONTINUE --> RECORD_ACTION

    RECORD_ACTION --> [*]: Advance to Next Frame
```

### Verified Agent Trace Example (from real execution)
```json
{
  "frame": 14,
  "timestamp_sec": 1.4,
  "observations": {
    "brightness_mean": 24.3,
    "blur_score": 38.6,
    "contrast_score": 19.2,
    "flags": ["low_brightness_24.3<40.0", "blurry_38.6<45.0"]
  },
  "decision": "ENHANCE_AND_RECHECK",
  "action": "apply_clahe_on_luminance",
  "next_action": "rerun_detection",
  "outcome": "evidence_improved_clahe_adopted",
  "details": "Conf delta: +0.210, Outcome: recovered_additional_defects"
}
```

---

## 3. ByteTrack & Defect Deduplication

PipeSight AI uses **ByteTrack** (`bytetrack.yaml`) to associate candidate detections across video frames using a combination of Kalman filter state estimation and high/low confidence association matrices:

- **Classes Preserved (`best.pt`)**:
  - `0: Buckling`
  - `1: Crack`
  - `2: Debris`
  - `3: Hole`
  - `4: Joint offset`
  - `5: Obstacle`
  - `6: Utility intrusion`
- **Deduplication Logic**:
  - Raw detections across frames are aggregated into distinct track events by `track_id`.
  - For each defect track, the system calculates `first_seen_sec`, `last_seen_sec`, `duration_sec`, `observation_count`, `peak_confidence`, and `avg_confidence`.
  - The frame exhibiting peak confidence is selected as the **representative evidence snapshot** and saved as a high-resolution JPEG.
- **Tracker Reset**: Tracker internal state and Kalman filters are reset between videos (`vision_service.reset_tracker()`), preventing track ID bleed across independent inspections.

---

## 4. Local Quickstart & Verification

### Prerequisites
- Python 3.11
- OpenCV 5 (`cv2==5.0.0`)
- PyTorch & Ultralytics

### Installation
```bash
# Clone or navigate to backend directory
cd backend

# Create and activate virtual environment
python -m venv venv
# Windows:
venv\Scripts\activate
# Linux/macOS:
source venv/bin/activate

# Install pinned dependencies
pip install -r requirements.txt
```

### Checkpoint Setup
Place `best.pt` in `backend/models/best.pt` (or set `MODEL_PATH` in `.env`). The SHA256 hash is computed on startup:
```
SHA256: 7df160aafa98fd06efb478f49c8616014c648822124932060eb1187a7dbaf61d
```

### Launch the Service
```bash
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```
- Interactive Swagger UI: `http://localhost:8000/docs`
- Service Health Check: `http://localhost:8000/health`

### Run Automated Tests
```bash
python -m pytest tests/ -v
```
All 19 unit and integration tests pass, covering:
- Health and info endpoints
- Corrupt video & invalid extension handling
- Clean pipe video (0 detections)
- Pipe video with defect tracking, evidence images, and PDF download
- Low-light video triggering agent CLAHE enhancement
- Single image inspection
- Local and S3 storage adapters

### Run Benchmark Video Evaluation
```bash
python scripts/evaluate_video.py --video path/to/inspection.mp4 --output evaluation_results.json
```

---

## 5. API Reference

| Method | Endpoint | Description |
|---|---|---|
| `GET` | `/health` | System health, OpenCV version, model hash, and device |
| `GET` | `/api/v1/info` | Defect classes, thresholds, and model prototype notice |
| `POST` | `/api/v1/inspect/video` | Upload video; returns `job_id` (202 Accepted) |
| `GET` | `/api/v1/inspect/{job_id}` | Poll inspection status, progress %, and frame count |
| `GET` | `/api/v1/inspect/{job_id}/report` | Get completed diagnostic JSON report |
| `GET` | `/api/v1/inspect/{job_id}/video` | Download or stream OpenCV 5 annotated MP4 video |
| `GET` | `/api/v1/inspect/{job_id}/evidence` | List representative evidence image URLs |
| `GET` | `/api/v1/inspect/{job_id}/evidence/{file}` | Download specific evidence image |
| `GET` | `/api/v1/inspect/{job_id}/report.pdf` | Download formal PDF inspection report |
| `POST` | `/api/v1/inspect/image` | Inspect single image with quality analysis and YOLO |

---

## 6. AWS Production Deployment Guide

### Architecture on AWS
- **Compute**: Amazon EC2 (`t3.xlarge` or `c7g.xlarge` Graviton for CPU; `g4dn.xlarge` for CUDA acceleration).
- **Storage**: Amazon S3 private bucket for source videos, annotated videos, JSON reports, and evidence.
- **Security**: EC2 IAM Role (no hardcoded credentials) + time-limited S3 Presigned URLs.
- **Reverse Proxy**: Nginx with Let's Encrypt TLS.

### Step 1: Create S3 Bucket & IAM Policy
Create an S3 bucket with default server-side encryption and block public access:
```bash
aws s3api create-bucket --bucket pipesight-ai-inspections --region us-east-1
aws s3api put-public-access-block --bucket pipesight-ai-inspections \
    --public-access-block-configuration "BlockPublicAcls=true,IgnorePublicAcls=true,BlockPublicPolicy=true,RestrictPublicBuckets=true"
```

Attach this least-privilege IAM Policy to the EC2 Instance Profile:
```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "s3:PutObject",
        "s3:GetObject",
        "s3:ListBucket"
      ],
      "Resource": [
        "arn:aws:s3:::pipesight-ai-inspections",
        "arn:aws:s3:::pipesight-ai-inspections/*"
      ]
    }
  ]
}
```

### Step 2: Launch EC2 Instance & Install Docker
```bash
# Update and install Docker
sudo apt update && sudo apt install -y docker.io docker-compose-v2 git
sudo usermod -aG docker ubuntu
newgrp docker
```

### Step 3: Deploy via Docker
```bash
# Clone project and enter backend
git clone <repo-url> pipesight && cd pipesight/backend

# Configure production environment
cp .env.example .env
nano .env
# Set:
# STORAGE_BACKEND=s3
# S3_BUCKET_NAME=pipesight-ai-inspections
# AWS_REGION=us-east-1
# MODEL_PATH=models/best.pt

# Build and start container
docker build -t pipesight-ai-backend .
docker run -d \
    --name pipesight-backend \
    --restart unless-stopped \
    -p 8000:8000 \
    --env-file .env \
    pipesight-ai-backend
```

### Step 4: Configure Nginx & Let's Encrypt TLS
```nginx
# /etc/nginx/sites-available/pipesight.conf
server {
    server_name api.pipesight.yourdomain.com;

    client_max_body_size 500M;

    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_read_timeout 600s;
        proxy_connect_timeout 600s;
        proxy_send_timeout 600s;
    }
}
```
Enable site and obtain SSL certificate:
```bash
sudo ln -s /etc/nginx/sites-available/pipesight.conf /etc/nginx/sites-enabled/
sudo certbot --nginx -d api.pipesight.yourdomain.com
```

---

## 7. Cloud-Optimized OpenCV Library (COOL) on Graviton

PipeSight AI isolates vision operations behind `app/utils/cool_adapter.py`:
- **Transparent Fallback**: On x86_64 or environments without COOL, standard OpenCV 5 is utilized with full feature fidelity.
- **No False Claims**: `/health` reports `cool_enabled: false` and `Standard OpenCV 5.0.0 on amd64 (COOL acceleration inactive / not installed)` unless executed on an AWS Graviton (aarch64) system with verified COOL binaries.
- When COOL is active, luminance enhancement routines route through Graviton SIMD/NEON optimized assembly kernels for higher throughput.

---

## 8. Limitations & Responsible Use

> **CRITICAL NOTICE: EXPERIMENTAL PROTOTYPE — HUMAN VERIFICATION REQUIRED**
>
> 1. **Model Accuracy Disclosure**: PipeSight AI is an experimental computer vision prototype. The defect detection model achieved approximately **42.6% mAP@50** on the held-out test dataset.
> 2. **Advisory Classifications**: All model predictions are strictly advisory. Defect classifications are labeled with cautionary prefixes (e.g., *"Suspected Crack"*, *"Model-predicted Debris"*).
> 3. **ByteTrack Identity Limits**: ByteTrack associates candidate bounding boxes between contiguous frames using Kalman filters and IoU cost matching. A track ID does not prove a unique physical defect and is vulnerable to track fragmentation during camera rotations, sudden lighting transitions, or severe visual occlusions.
> 4. **No Calibrated Spatial Dimensions**: Ordinary monocular camera video does not provide calibrated physical dimensions (defect width in millimeters) or linear pipe distance (meters along sewer run). Validated distance requires dedicated distance odometry sensors or laser profilometry.
> 5. **Human Sign-off**: PipeSight AI must never be used as the sole basis for autonomous excavation, structural safety certification, or municipal repair decisions. All diagnostic outputs require manual engineering review by certified pipeline inspection personnel.

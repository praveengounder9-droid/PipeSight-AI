# PipeSight AI — Judge & Evaluator Testing Guide 🛠️

Welcome to **PipeSight AI**, an autonomous CCTV sewer and stormwater pipe inspection platform combining **OpenCV 5**, a trained **YOLO26s** defect detection model (`best.pt`), **ByteTrack** multi-object tracking, and a deterministic **Agentic Vision controller**.

This guide is designed to help you set up, evaluate, and test the entire platform from this zip archive in under **3 minutes**.

---

## 📋 What's in This Zip Package

```
PipeSight-AI/
├── backend/
│   ├── app/                      # FastAPI REST application (Perception, Agent, Storage)
│   ├── models/best.pt            # Trained YOLO26s defect model checkpoint (~20 MB)
│   ├── trackers/bytetrack.yaml   # ByteTrack multi-object tracker configuration
│   ├── tests/                    # Pytest test suite (30 unit & integration tests)
│   ├── scripts/                  # Automated verification and evaluation scripts
│   │   ├── demo_test.py          # 1-command end-to-end automated testing client
│   │   ├── live_test.py          # Quick smoke test script
│   │   └── evaluate_video.py     # Batch video diagnostic benchmark tool
│   ├── sample_evaluation_video.mp4 # Sample CCTV inspection video ready for testing
│   ├── test_sewer_pipe.mp4       # Real-world CCTV inspection video
│   ├── requirements.txt          # Python dependencies
│   └── .env.example              # Backend environment template
├── frontend/
│   ├── src/                      # React 19 + TypeScript + Vite Dashboard
│   ├── package.json              # Frontend dependencies
│   └── .env.example              # Frontend environment template
├── best.pt                       # Backup copy of model checkpoint
└── TESTING_INSTRUCTIONS_FOR_JUDGES.md  # This guide!
```

---

## ⚡ Quick Evaluation Options

Depending on your preferred evaluation method, you can test PipeSight AI in two ways:

| Evaluation Method | Time Required | Description |
|---|---|---|
| **Option 1: Interactive Web Dashboard (Recommended)** | ~3 minutes | Full interactive UI: video upload, live HUD playback, defect event timeline, evidence lightbox, and PDF report export. |
| **Option 2: 1-Command CLI Demo** | ~45 seconds | Zero-UI terminal test: automatically uploads sample video, processes pipeline, logs metrics, and downloads PDF + annotated video. |
| **Option 3: Automated Test Suite** | ~15 seconds | Runs 30 pytest unit & integration tests covering edge cases, quality filters, and tracking. |

---

## 🔧 Prerequisites

- **Python**: 3.10 or 3.11 installed (`python --version`)
- **Node.js**: v18+ and npm installed (`node -v` and `npm -v`)
- **Compute**: Works 100% on **standard CPU** (no GPU required; CUDA is automatically utilized if available).
- **Operating System**: Windows, macOS, or Linux (Ubuntu 20.04/22.04/24.04).

---

## 🚀 Option 1: Interactive Web Dashboard (Recommended)

### Step 1: Start the Backend (Terminal 1)

1. Open a terminal and navigate to the `backend/` directory:
   ```bash
   cd backend
   ```

2. Create and activate a Python virtual environment:
   - **Windows (PowerShell)**:
     ```powershell
     python -m venv venv
     .\venv\Scripts\Activate.ps1
     ```
     *(If PowerShell blocks activation, run `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass` first, or use Command Prompt `venv\Scripts\activate.bat`)*
   - **macOS / Linux**:
     ```bash
     python3 -m venv venv
     source venv/bin/activate
     ```

3. Install the dependencies:
   ```bash
   pip install -r requirements.txt
   ```

4. *(Optional)* Copy the environment template:
   ```bash
   cp .env.example .env
   ```
   *(The backend defaults to CPU execution and automatically detects `best.pt` in `models/` or root).*

5. Launch the FastAPI server:
   ```bash
   uvicorn app.main:app --host 127.0.0.1 --port 8000 --reload
   ```

   ✅ Backend will be live at **`http://127.0.0.1:8000`**  
   📖 Interactive Swagger API Docs: **`http://127.0.0.1:8000/docs`**  
   🩺 Health Diagnostics: **`http://127.0.0.1:8000/health`**

---

### Step 2: Start the Frontend Dashboard (Terminal 2)

1. Open a **second terminal** and navigate to the `frontend/` directory:
   ```bash
   cd frontend
   ```

2. Install dependencies:
   - **macOS / Linux / Windows CMD**:
     ```bash
     npm install
     ```
   - **Windows PowerShell**:
     ```powershell
     npm.cmd install
     ```

3. Launch the Vite development server:
   ```bash
   npm run dev
   # or on Windows PowerShell:
   npm.cmd run dev
   ```

   ✅ Frontend will be live at **`http://localhost:5173`**

---

### Step 3: Run an Inspection via the UI

1. Open your browser and navigate to **`http://localhost:5173`**.
2. Notice the **Live Backend Telemetry** badge in the header confirming OpenCV version, PyTorch device (CPU/CUDA), and model status.
3. In the **Upload CCTV Video** area, click to browse or drag & drop one of the sample test videos provided in this zip:
   - `backend/test_sewer_pipe.mp4` (or `backend/sample_evaluation_video.mp4`)
4. Click **Start Inspection**.
5. **Watch the live processing**:
   - **Live Progress Bar**: Displays completion percentage, frame counts (`current/total`), and processing FPS.
   - **Agentic Vision Audit Log**: Shows real-time perception decisions (e.g. OpenCV blur/brightness assessment, adaptive CLAHE enhancement on low-light frames).
   - **Defect Events Table**: Tracks deduplicated defect events (Crack, Debris, Joint Fault, Root Intrusion, Surface Damage) with start/end timestamps and peak confidence.
   - **Interactive Video Player**: Play the annotated CCTV video with bounding box overlays; clicking any timestamp in the defect table seeks directly to that defect!
   - **Evidence Image Lightbox**: Click any defect snapshot to view full-resolution evidence.
   - **Export Buttons**: Download the formal **Engineering PDF Report**, **Annotated MP4 Video**, or complete **Results ZIP**.

---

## ⚡ Option 2: 1-Command CLI End-to-End Demo

If you prefer testing directly in the terminal without opening a browser:

1. Ensure the backend is running (`uvicorn app.main:app --host 127.0.0.1 --port 8000` in Terminal 1).
2. In a separate terminal in `backend/`, run:
   ```bash
   python scripts/demo_test.py
   ```
3. What happens automatically:
   - Checks `/health` endpoint and verifies OpenCV runtime.
   - Uploads `test_sewer_pipe.mp4` to `POST /api/v1/inspect/video`.
   - Polls progress in real-time until completion.
   - Prints the summary metrics, agent decisions, and ByteTrack deduplicated defect events.
   - Automatically downloads and saves `downloaded_report.pdf` and `downloaded_annotated_video.mp4` right into `backend/`.

---

## 🧪 Option 3: Automated Pytest Test Suite

To verify the test suite (30 automated unit and integration tests):

1. In the `backend/` directory (with your virtual environment active):
   ```bash
   python -m pytest tests -v
   ```
2. **Result**: All 30 tests pass in ~11 seconds, testing:
   - OpenCV image quality metrics (Laplacian variance, brightness, contrast)
   - CLAHE luminance enhancement and frame filtering
   - Deterministic Agentic Vision controller decisions and human review flags
   - ByteTrack multi-object tracking deduplication across frames
   - API endpoints (`/health`, `/info`, `/inspect/video`, `/inspect/image`, `/report.pdf`, `/zip`)
   - Edge cases: corrupt video rejection, non-video mime validation, aspect-preserving downscaling.

---

## 🔍 Key Technical Features to Inspect

When reviewing PipeSight AI, look for these architectural highlights:

1. **OpenCV 5 Quality Analysis & Enhancement**:
   - Before inference, frames are assessed for brightness, contrast, and Laplacian blur.
   - Low-light frames automatically trigger adaptive CLAHE on the L-channel of the LAB color space, recovering defect details without washing out edges.
2. **ByteTrack Multi-Object Tracking**:
   - Raw frame-by-frame detections are deduplicated into persistent defect tracks. A crack visible across 40 consecutive frames is correctly reported as **1 unique defect event** with duration and peak confidence.
3. **Agentic Vision Controller**:
   - A deterministic perception-action loop that logs every quality inspection, triggers enhancement retries when needed, and flags uncertain detections (confidence 0.25 – 0.42) for human engineering review.
4. **ReportLab Engineering PDF**:
   - Generates a ready-to-sign civil engineering inspection report complete with summary statistics, defect distribution charts, and high-resolution evidence snapshots.
5. **Pure CPU Optimization**:
   - Aspect-preserving bounding box downscaling (max 640px) and frame stride sampling enable fast, responsive inference even on budget CPU hardware without requiring an expensive GPU instance.

---

## ❓ Troubleshooting & FAQs for Judges

### Q1: On Windows PowerShell, `activate.ps1` or `npm` gives an ExecutionPolicy error.
**Solution**: Run PowerShell as Administrator or bypass execution policy for the current terminal session:
```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
```
Alternatively, use Command Prompt (`cmd.exe`), or run npm commands using `npm.cmd` (e.g. `npm.cmd install` and `npm.cmd run dev`).

### Q2: On Linux, I get an error about `libGL.so.1` or `libgomp.so.1`.
**Solution**: Install standard headless OpenCV system libraries:
```bash
sudo apt-get update && sudo apt-get install -y libgl1 libglib2.0-0 libgomp1 ffmpeg
```

### Q3: Where is the model file `best.pt`?
**Solution**: `best.pt` is located in `backend/models/best.pt` (and a backup is also at the root). The backend's config automatically locates it in either path.

### Q4: Port 8000 or 5173 is already in use.
**Solution**:
- To run the backend on a different port (e.g. 8001):
  ```bash
  uvicorn app.main:app --port 8001 --reload
  ```
- Then update `frontend/.env`:
  ```
  VITE_API_BASE_URL=http://127.0.0.1:8001
  ```

"""
PipeSight AI - Interactive Test Demo Client.
Uploads test_sewer_pipe.mp4 to the running backend, streams progress,
and downloads the annotated video and PDF diagnostic report.
"""

from pathlib import Path
import time
import requests

BASE_URL = "http://127.0.0.1:8000"


def run_demo():
    print("=" * 65)
    print("[*] PipeSight AI -- Backend End-to-End Test Client")
    print("=" * 65)

    # 1. Check Health
    print("\n[1/5] Checking backend health at /health...")
    health_resp = requests.get(f"{BASE_URL}/health")
    if health_resp.status_code != 200:
        print(f"[FAIL] Server health check failed: {health_resp.status_code}")
        return
    health = health_resp.json()
    print(f"   [OK] Server Status : {health['status']}")
    print(f"   [OK] OpenCV Version: {health['opencv_version']}")
    print(f"   [OK] Model Loaded  : {health['model_loaded']} ({health['classes_count']} classes)")
    print(f"   [OK] Compute Device: {health['device']}")

    # 2. Upload video
    video_path = Path(__file__).resolve().parent.parent / "test_sewer_pipe.mp4"
    print(f"\n[2/5] Uploading sample video '{video_path.name}' to POST /api/v1/inspect/video...")
    with open(video_path, "rb") as f:
        upload_resp = requests.post(
            f"{BASE_URL}/api/v1/inspect/video",
            files={"file": (video_path.name, f, "video/mp4")},
        )

    if upload_resp.status_code != 202:
        print(f"[FAIL] Upload failed ({upload_resp.status_code}): {upload_resp.text}")
        return

    job_data = upload_resp.json()
    job_id = job_data["job_id"]
    print(f"   [OK] Job Created! ID: {job_id}")

    # 3. Poll for progress
    print(f"\n[3/5] Polling job progress at GET /api/v1/inspect/{job_id}...")
    completed = False
    start_time = time.time()
    while time.time() - start_time < 60:
        status_resp = requests.get(f"{BASE_URL}/api/v1/inspect/{job_id}")
        if status_resp.status_code == 200:
            status_data = status_resp.json()
            pct = status_data["progress_pct"]
            curr = status_data["current_frame"]
            total = status_data["total_frames"]
            st = status_data["status"]
            print(f"   [PROGRESS] Status: {st.upper()} | Progress: {pct}% ({curr}/{total} frames)")

            if st == "completed":
                completed = True
                break
            elif st == "failed":
                print(f"[FAIL] Job processing failed: {status_data.get('error_message')}")
                return
        time.sleep(1.0)

    if not completed:
        print("[FAIL] Processing timed out.")
        return

    # 4. Fetch JSON Report
    print(f"\n[4/5] Fetching Diagnostic Report at GET /api/v1/inspect/{job_id}/report...")
    report_resp = requests.get(f"{BASE_URL}/api/v1/inspect/{job_id}/report")
    report = report_resp.json()
    summary = report["summary"]
    agent_summary = report["agent_decisions_summary"]
    events = report["defect_events"]

    perf = report.get("performance_metrics", {})
    print("\n   [SUMMARY] Inspection Report Metrics:")
    print(f"      - Source Frames Analyzed  : {perf.get('frames_processed', report['video_statistics']['processed_frames'])} processed / {perf.get('frames_skipped', 0)} skipped (Stride {perf.get('frame_stride', 3)})")
    print(f"      - Actual Processing Speed : {perf.get('processing_fps', 'N/A')} FPS ({perf.get('actual_processing_duration_sec', 'N/A')}s duration)")
    print(f"      - Raw Detections Found    : {summary['raw_detections_count']}")
    print(f"      - Unique Defect Events    : {summary['estimated_unique_events_count']}")
    print(f"      - Low-Light Frames Flagged: {summary['low_quality_frames_count']}")
    print(f"      - CLAHE Enhancement Runs  : {summary['enhanced_frames_count']} (Retries: {perf.get('enhancement_retries', 0)})")
    print(f"      - Agent Decision Breakdown: {agent_summary['action_counts']}")

    if events:
        print("\n   [DEFECT EVENTS] ByteTrack Aggregated Events:")
        for ev in events:
            print(f"      * Track #{ev['track_id']} | {ev['advisory_label']} | Peak Conf: {ev['peak_confidence']:.2f} | Time: {ev['first_seen_sec']}s - {ev['last_seen_sec']}s ({ev['observation_count']} frames)")

    # 5. Download Artifacts
    print("\n[5/5] Downloading Generated Inspection Artifacts:")
    # PDF
    pdf_resp = requests.get(f"{BASE_URL}/api/v1/inspect/{job_id}/report.pdf")
    if pdf_resp.status_code == 200:
        with open("downloaded_report.pdf", "wb") as f_pdf:
            f_pdf.write(pdf_resp.content)
        print(f"   [DOWNLOAD] Saved PDF Report: downloaded_report.pdf ({len(pdf_resp.content):,} bytes)")

    # Annotated Video
    vid_resp = requests.get(f"{BASE_URL}/api/v1/inspect/{job_id}/video")
    if vid_resp.status_code == 200:
        with open("downloaded_annotated_video.mp4", "wb") as f_vid:
            f_vid.write(vid_resp.content)
        print(f"   [DOWNLOAD] Saved Annotated Video: downloaded_annotated_video.mp4 ({len(vid_resp.content):,} bytes)")

    # Evidence list
    ev_resp = requests.get(f"{BASE_URL}/api/v1/inspect/{job_id}/evidence")
    if ev_resp.status_code == 200:
        ev_items = ev_resp.json().get("evidence_items", [])
        print(f"   [DOWNLOAD] Evidence Images Available: {len(ev_items)}")

    print("\n" + "=" * 65)
    print("[SUCCESS] Test Complete! All endpoints responded successfully.")
    print("=" * 65)


if __name__ == "__main__":
    run_demo()
